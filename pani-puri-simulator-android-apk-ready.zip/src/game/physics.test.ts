import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createInitialPlayerState,
  resolveHorizontalCollisions,
  stepPlayerPhysics,
  WALK_SPEED,
  SPRINT_SPEED,
} from './physics';
import {
  CITY_BUILDINGS,
  PLAYER_RADIUS,
  STALL_POSITION,
  WORLD_COLLIDERS,
  WORLD_HALF_SIZE,
} from './worldData';
import { sanitizeSettings, DEFAULT_SETTINGS } from '../utils/settings';
import { isSocialUrlConfigured } from '../config/socialLinks';
import { evaluateViewportOrientation } from '../utils/orientation';

test('initial player spawn is on open ground and not colliding with any building or stall', () => {
  const state = createInitialPlayerState();
  const check = resolveHorizontalCollisions(state.x, state.z, PLAYER_RADIUS, WORLD_COLLIDERS);
  assert.equal(check.collided, false);
  assert.equal(state.y, 0);
  assert.equal(state.isGrounded, true);
});

test('forward movement and sprint multiplier move the player faster when sprinting', () => {
  const walkState = createInitialPlayerState();
  const sprintState = createInitialPlayerState();

  for (let i = 0; i < 15; i++) {
    stepPlayerPhysics(
      walkState,
      {
        moveX: 0,
        moveZ: 1,
        sprintHeld: false,
        jumpHeld: false,
        jumpJustPressed: false,
        lookDeltaX: 0,
        lookDeltaY: 0,
      },
      0.016,
      []
    );
    stepPlayerPhysics(
      sprintState,
      {
        moveX: 0,
        moveZ: 1,
        sprintHeld: true,
        jumpHeld: false,
        jumpJustPressed: false,
        lookDeltaX: 0,
        lookDeltaY: 0,
      },
      0.016,
      []
    );
  }

  const walkDist = Math.abs(walkState.z - createInitialPlayerState().z);
  const sprintDist = Math.abs(sprintState.z - createInitialPlayerState().z);
  assert.ok(walkDist > 0.4, 'Player should move forward when moveZ = 1');
  assert.ok(sprintDist > walkDist * 1.4, 'Sprinting should cover significantly more distance than walking');
  assert.ok(SPRINT_SPEED > WALK_SPEED);
});

test('jump impulse lifts player off the ground and gravity lands player cleanly at y = 0 without falling through', () => {
  const state = createInitialPlayerState();

  const jumpStep = stepPlayerPhysics(
    state,
    {
      moveX: 0,
      moveZ: 0,
      sprintHeld: false,
      jumpHeld: true,
      jumpJustPressed: true,
      lookDeltaX: 0,
      lookDeltaY: 0,
    },
    0.016,
    []
  );

  assert.equal(jumpStep.jumped, true);
  assert.equal(state.isGrounded, false);
  assert.ok(state.y > 0, 'Player height should increase after jumping');

  let landedDetected = false;
  for (let i = 0; i < 120; i++) {
    const res = stepPlayerPhysics(
      state,
      {
        moveX: 0,
        moveZ: 0,
        sprintHeld: false,
        jumpHeld: false,
        jumpJustPressed: false,
        lookDeltaX: 0,
        lookDeltaY: 0,
      },
      0.02,
      []
    );
    if (res.landed) landedDetected = true;
    assert.ok(state.y >= 0, 'Player must never fall below y = 0');
  }

  assert.equal(landedDetected, true);
  assert.equal(state.y, 0);
  assert.equal(state.isGrounded, true);
});

test('building and stall collisions prevent walking through solid obstacles', () => {
  const firstBuilding = CITY_BUILDINGS[0];
  const res = resolveHorizontalCollisions(
    firstBuilding.x,
    firstBuilding.z,
    PLAYER_RADIUS,
    WORLD_COLLIDERS
  );
  assert.equal(res.collided, true);

  const halfW = firstBuilding.width / 2;
  const halfD = firstBuilding.depth / 2;
  const outsideX =
    res.x <= firstBuilding.x - halfW - PLAYER_RADIUS + 1e-4 ||
    res.x >= firstBuilding.x + halfW + PLAYER_RADIUS - 1e-4;
  const outsideZ =
    res.z <= firstBuilding.z - halfD - PLAYER_RADIUS + 1e-4 ||
    res.z >= firstBuilding.z + halfD + PLAYER_RADIUS + 1e-4;
  assert.ok(outsideX || outsideZ, 'Player must be pushed outside building bounds');

  const stallRes = resolveHorizontalCollisions(
    STALL_POSITION.x,
    STALL_POSITION.z,
    PLAYER_RADIUS,
    WORLD_COLLIDERS
  );
  assert.equal(stallRes.collided, true);
});

test('world boundary collision prevents leaving the 30x30 city block', () => {
  const maxAllowed = WORLD_HALF_SIZE - PLAYER_RADIUS;
  const farOut = resolveHorizontalCollisions(999, -999, PLAYER_RADIUS, WORLD_COLLIDERS);
  assert.equal(farOut.collided, true);
  assert.ok(Math.abs(farOut.x - maxAllowed) < 1e-5);
  assert.ok(Math.abs(farOut.z - -maxAllowed) < 1e-5);
});

test('settings sanitization and social link placeholder validation work reliably', () => {
  const sanitized = sanitizeSettings({
    volume: 150,
    muted: true,
    lookSensitivity: 0.05,
    graphicsQuality: 'high',
  });
  assert.equal(sanitized.volume, 100);
  assert.equal(sanitized.muted, true);
  assert.equal(sanitized.lookSensitivity, 0.2);
  assert.equal(sanitized.graphicsQuality, 'high');

  const lowQuality = sanitizeSettings({ graphicsQuality: 'low' });
  assert.equal(lowQuality.graphicsQuality, 'low');

  const defaults = sanitizeSettings(null);
  assert.deepEqual(defaults, DEFAULT_SETTINGS);
  assert.equal(defaults.graphicsQuality, 'medium');

  assert.equal(isSocialUrlConfigured(''), false);
  assert.equal(isSocialUrlConfigured('YOUR_YOUTUBE_URL'), false);
  assert.equal(isSocialUrlConfigured('https://www.youtube.com/@panipurisim3d'), true);
});

test('viewport orientation evaluation shows rotate overlay on portrait mobile and hides on landscape or desktop', () => {
  const mobilePortrait = evaluateViewportOrientation(390, 844);
  assert.equal(mobilePortrait.isPortrait, true);
  assert.equal(mobilePortrait.shouldShowRotateOverlay, true);

  const mobileLandscape = evaluateViewportOrientation(844, 390);
  assert.equal(mobileLandscape.isPortrait, false);
  assert.equal(mobileLandscape.shouldShowRotateOverlay, false);

  const narrowLandscape = evaluateViewportOrientation(667, 375);
  assert.equal(narrowLandscape.isPortrait, false);
  assert.equal(narrowLandscape.shouldShowRotateOverlay, false);

  const desktopBrowser = evaluateViewportOrientation(1440, 900);
  assert.equal(desktopBrowser.isPortrait, false);
  assert.equal(desktopBrowser.shouldShowRotateOverlay, false);
});

test('Phase 4.5: City map is expanded 2x (60x60 grid / 72m x 72m) with clear roads and 1.5x stall bounds', () => {
  assert.equal(WORLD_HALF_SIZE, 36.0);
  assert.ok(CITY_BUILDINGS.length >= 28, 'Expanded city should contain at least 28 buildings across inner and outer districts');

  const stallCollider = WORLD_COLLIDERS.find((c) => c.id === 'pani-puri-stall');
  assert.ok(stallCollider);
  const stallWidth = stallCollider.maxX - stallCollider.minX;
  const stallDepth = stallCollider.maxZ - stallCollider.minZ;
  assert.ok(stallWidth >= 3.9, `Expanded stall collider width (${stallWidth}m) should be ~1.5x original`);
  assert.ok(stallDepth >= 1.9, `Expanded stall collider depth (${stallDepth}m) should be ~1.5x original`);

  // Verify main avenues (x=0, z=0) and inner/outer ring streets (±10m, ±22m) are completely free of building colliders
  const roadSamples = [
    { x: 0, z: 0 },
    { x: 0, z: -28 },
    { x: 0, z: 28 },
    { x: -28, z: 0 },
    { x: 28, z: 0 },
    { x: 10, z: -10 },
    { x: -10, z: 10 },
    { x: 22, z: -22 },
    { x: -22, z: 22 },
  ];
  for (const pt of roadSamples) {
    const check = resolveHorizontalCollisions(pt.x, pt.z, PLAYER_RADIUS, WORLD_COLLIDERS);
    assert.equal(check.collided, false, `Road sample (${pt.x}, ${pt.z}) must be obstacle-free`);
  }
});

