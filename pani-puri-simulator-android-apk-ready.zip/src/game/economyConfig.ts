import type { IngredientInventory } from './foodPrepEngine';

/**
 * Centralized Phase 4 Economy Configuration
 * Single source of truth for all ingredient prices, batch sizes, star rewards, and upgrade costs.
 */

export const SHOP_UNITS_PER_PURCHASE = 10;

export const DEFAULT_INITIAL_COINS = 50;
export const DEFAULT_CUSTOMER_LIMIT = 5;
export const UPGRADED_CUSTOMER_LIMIT = 10;

export type ShopItemId =
  | 'sukhi_puri'
  | 'aloo'
  | 'sev'
  | 'curd'
  | 'jeera_jal'
  | 'sweet_chatni'
  | 'plate';

export const INGREDIENT_BASE_PRICES: Record<ShopItemId, number> = {
  sukhi_puri: 8,
  aloo: 15,
  sev: 12,
  curd: 18,
  jeera_jal: 12,
  sweet_chatni: 14,
  plate: 5,
};

export type StarRatingTier = 1 | 2 | 3 | 4 | 5;

export const STAR_RATING_REWARDS: Record<StarRatingTier, number> = {
  5: 35,
  4: 25,
  3: 15,
  2: 8,
  1: 3,
};

export type ShopUpgradeId = 'more_customers' | 'discount_50';

export const UPGRADE_PRICES: Record<ShopUpgradeId, number> = {
  more_customers: 250,
  discount_50: 500,
};

export const DISCOUNT_MULTIPLIER = 0.5;

export interface ShopItemDefinition {
  id: ShopItemId;
  inventoryKey: keyof IngredientInventory;
  name: string;
  basePrice: number;
  unitsPerPurchase: number;
  accentColor: string;
  description: string;
}

export const SHOP_ITEMS: ShopItemDefinition[] = [
  {
    id: 'sukhi_puri',
    inventoryKey: 'sukhi_puri',
    name: 'Sukhi Puri',
    basePrice: INGREDIENT_BASE_PRICES.sukhi_puri,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#fbbf24',
    description: 'Crispy hollow golden puris (+10 units)',
  },
  {
    id: 'aloo',
    inventoryKey: 'aloo',
    name: 'Aloo',
    basePrice: INGREDIENT_BASE_PRICES.aloo,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#facc15',
    description: 'Spiced mashed potato filling (+10 units)',
  },
  {
    id: 'sev',
    inventoryKey: 'sev',
    name: 'Sev',
    basePrice: INGREDIENT_BASE_PRICES.sev,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#f59e0b',
    description: 'Crunchy gram-flour noodles (+10 units)',
  },
  {
    id: 'curd',
    inventoryKey: 'curd',
    name: 'Curd',
    basePrice: INGREDIENT_BASE_PRICES.curd,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#f8fafc',
    description: 'Chilled whipped sweet yogurt (+10 units)',
  },
  {
    id: 'jeera_jal',
    inventoryKey: 'jeera_jal',
    name: 'Jeera Jal',
    basePrice: INGREDIENT_BASE_PRICES.jeera_jal,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#4ade80',
    description: 'Mint & roasted cumin spiced water (+10 units)',
  },
  {
    id: 'sweet_chatni',
    inventoryKey: 'sweet_chatni',
    name: 'Sweet Chatni',
    basePrice: INGREDIENT_BASE_PRICES.sweet_chatni,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#fb923c',
    description: 'Tangy tamarind & jaggery glaze (+10 units)',
  },
  {
    id: 'plate',
    inventoryKey: 'emptyPlates',
    name: 'Plate',
    basePrice: INGREDIENT_BASE_PRICES.plate,
    unitsPerPurchase: SHOP_UNITS_PER_PURCHASE,
    accentColor: '#38bdf8',
    description: 'Stainless-steel serving plates (+10 units)',
  },
];

export interface ShopUpgradesState {
  moreCustomers: boolean;
  discount50: boolean;
}

export interface ShopUpgradeDefinition {
  id: ShopUpgradeId;
  name: string;
  price: number;
  description: string;
}

export const SHOP_UPGRADES: ShopUpgradeDefinition[] = [
  {
    id: 'more_customers',
    name: 'More Customers',
    price: UPGRADE_PRICES.more_customers,
    description: 'Increases the stall customer limit from 5 to 10.',
  },
  {
    id: 'discount_50',
    name: '50% Discount',
    price: UPGRADE_PRICES.discount_50,
    description: 'Reduces all ingredient and plate restock prices by 50%.',
  },
];

/**
 * Returns the effective coin price for an eligible shop item (ingredients & plates),
 * applying the 50% discount upgrade exactly once per transaction with consistent 2-decimal rounding.
 * Note: Upgrades themselves are never discounted.
 */
export function getShopItemEffectivePrice(
  basePrice: number,
  discount50Active: boolean
): number {
  const safeBase = Number.isFinite(basePrice) && basePrice >= 0 ? basePrice : 0;
  if (!discount50Active) {
    return Number(safeBase.toFixed(2));
  }
  return Number((safeBase * DISCOUNT_MULTIPLIER).toFixed(2));
}

/**
 * Returns the coin reward for a completed customer order given a 1..5 star rating.
 */
export function getStarRatingCoinReward(stars: number): number {
  const clamped = Math.max(1, Math.min(5, Math.round(stars))) as StarRatingTier;
  return STAR_RATING_REWARDS[clamped];
}
