import * as THREE from 'three';
import {
  ALL_POURABLE_IDS,
  ContainerItemId,
  HeldItemId,
  InteractiveTargetId,
  PlateState,
  PourableIngredientId,
  POURABLE_INGREDIENTS,
} from './recipes';
import {
  FoodPrepSessionState,
  PLATE_STACK_POSITION,
  PREP_COUNTER_POSITION,
  SERVING_AREA_POSITION,
  STALL_HOME_POSITIONS,
} from './foodPrepEngine';
import { createPbrTextureLibrary, PbrTextureLibrary } from './pbrMaterials';

export interface StallInteractiveRig {
  rootGroup: THREE.Group;
  cameraHeldGroup: THREE.Group;
  raycastTargets: THREE.Object3D[];
  syncWithState: (state: FoodPrepSessionState, dt: number, elapsedTime: number) => void;
  dispose: () => void;
}

function createLabelTexture(
  title: string,
  accentHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#1c1917';
    ctx.fillRect(0, 0, 256, 64);
    ctx.strokeStyle = accentHex;
    ctx.lineWidth = 5;
    ctx.strokeRect(4, 4, 248, 56);
    ctx.fillStyle = '#fef3c7';
    ctx.font = '800 24px "Outfit", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, 128, 33);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.needsUpdate = true;
  return tex;
}

function tagInteractiveHierarchy(obj: THREE.Object3D, id: InteractiveTargetId) {
  obj.userData.interactiveId = id;
  obj.traverse((child) => {
    child.userData.interactiveId = id;
  });
}

interface PlateVisualNodes {
  group: THREE.Group;
  puriNodes: THREE.Group[];
  ingredientNodes: Record<PourableIngredientId, THREE.Object3D>;
}

/**
 * Phase 5 — Builds a detailed medium-poly 3D Pani Puri Plate with:
 * - Pressed stainless-steel lip, beveled rim & recessed inner well (`brushedSteelBump`)
 * - 6 hollow golden-brown crispy Sukhi Puris (`puriCrustMap` + `puriCrustBump`)
 * - 5 appetizing PBR ingredient fill layers (Aloo, Sev, Curd, Jeera Jal, Sweet Chatni)
 */
function buildDetailedPlateVisual(
  pbr: PbrTextureLibrary,
  geometries: THREE.BufferGeometry[],
  materials: THREE.Material[]
): PlateVisualNodes {
  const group = new THREE.Group();

  const steelRimMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.2,
    metalness: 0.88,
  });
  const steelInnerMat = new THREE.MeshStandardMaterial({
    color: 0xcbd5e1,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.003,
    roughness: 0.24,
    metalness: 0.84,
  });
  const puriShellMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.puriCrustMap,
    bumpMap: pbr.puriCrustBump,
    bumpScale: 0.012,
    roughness: 0.62,
    metalness: 0.03,
  });
  const puriHoleMat = new THREE.MeshStandardMaterial({
    color: 0x3b1504,
    roughness: 0.92,
  });

  materials.push(steelRimMat, steelInnerMat, puriShellMat, puriHoleMat);

  const rimGeo = new THREE.CylinderGeometry(0.235, 0.175, 0.032, 24);
  const lipRingGeo = new THREE.TorusGeometry(0.228, 0.01, 8, 24);
  lipRingGeo.rotateX(Math.PI / 2);
  const innerGeo = new THREE.CylinderGeometry(0.188, 0.16, 0.035, 24);
  geometries.push(rimGeo, lipRingGeo, innerGeo);

  const rimMesh = new THREE.Mesh(rimGeo, steelRimMat);
  rimMesh.position.y = 0.016;
  const lipMesh = new THREE.Mesh(lipRingGeo, steelRimMat);
  lipMesh.position.y = 0.031;
  const innerMesh = new THREE.Mesh(innerGeo, steelInnerMat);
  innerMesh.position.y = 0.02;
  group.add(rimMesh, lipMesh, innerMesh);

  // 6 Sukhi Puris arranged in a circular ring on the plate with crisp cracked rim
  const puriShellGeo = new THREE.SphereGeometry(0.045, 16, 12);
  puriShellGeo.scale(1.04, 0.78, 0.98);
  const puriCrackRimGeo = new THREE.TorusGeometry(0.024, 0.0045, 6, 14);
  puriCrackRimGeo.rotateX(Math.PI / 2);
  const puriOpeningGeo = new THREE.CylinderGeometry(0.024, 0.019, 0.018, 12);
  geometries.push(puriShellGeo, puriCrackRimGeo, puriOpeningGeo);

  const puriNodes: THREE.Group[] = [];
  const ringRadius = 0.112;
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const pNode = new THREE.Group();
    pNode.position.set(
      Math.cos(angle) * ringRadius,
      0.053,
      Math.sin(angle) * ringRadius
    );
    pNode.rotation.y = angle * 0.7;
    const shell = new THREE.Mesh(puriShellGeo, puriShellMat);
    const crackRim = new THREE.Mesh(puriCrackRimGeo, puriShellMat);
    crackRim.position.y = 0.029;
    const opening = new THREE.Mesh(puriOpeningGeo, puriHoleMat);
    opening.position.y = 0.026;
    pNode.add(shell, crackRim, opening);
    pNode.visible = false;
    group.add(pNode);
    puriNodes.push(pNode);
  }

  // Dynamic Ingredient Fillings inside/across the plate
  const ingredientNodes = {} as Record<PourableIngredientId, THREE.Object3D>;

  // 1. Aloo (spiced mashed potato mounds with coriander & cumin flecks in each puri + center)
  const alooGroup = new THREE.Group();
  const alooMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.alooMashMap,
    bumpMap: pbr.alooMashBump,
    bumpScale: 0.014,
    roughness: 0.84,
    metalness: 0.02,
  });
  const alooMoundGeo = new THREE.SphereGeometry(0.026, 12, 10);
  alooMoundGeo.scale(1.05, 0.68, 0.96);
  geometries.push(alooMoundGeo);
  materials.push(alooMat);
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const m = new THREE.Mesh(alooMoundGeo, alooMat);
    m.position.set(Math.cos(angle) * ringRadius, 0.069, Math.sin(angle) * ringRadius);
    m.rotation.y = i * 1.1;
    alooGroup.add(m);
  }
  const centerAloo = new THREE.Mesh(alooMoundGeo, alooMat);
  centerAloo.position.set(0, 0.052, 0);
  centerAloo.scale.set(1.25, 0.85, 1.25);
  alooGroup.add(centerAloo);
  alooGroup.visible = false;
  group.add(alooGroup);
  ingredientNodes.aloo = alooGroup;

  // 2. Jeera Jal (translucent-looking spiced emerald-mint liquid inside each puri + plate well)
  const jeeraGroup = new THREE.Group();
  const jeeraMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.jeeraLiquidMap,
    roughness: 0.12,
    metalness: 0.14,
    transparent: true,
    opacity: 0.92,
  });
  const liquidDiskGeo = new THREE.CylinderGeometry(0.16, 0.15, 0.012, 20);
  const puriLiquidCapGeo = new THREE.CircleGeometry(0.022, 12);
  puriLiquidCapGeo.rotateX(-Math.PI / 2);
  geometries.push(liquidDiskGeo, puriLiquidCapGeo);
  materials.push(jeeraMat);
  const jeeraDisk = new THREE.Mesh(liquidDiskGeo, jeeraMat);
  jeeraDisk.position.y = 0.042;
  jeeraGroup.add(jeeraDisk);
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const cap = new THREE.Mesh(puriLiquidCapGeo, jeeraMat);
    cap.position.set(Math.cos(angle) * ringRadius, 0.075, Math.sin(angle) * ringRadius);
    jeeraGroup.add(cap);
  }
  jeeraGroup.visible = false;
  group.add(jeeraGroup);
  ingredientNodes.jeera_jal = jeeraGroup;

  // 3. Sweet Chatni (glossy tamarind-date brown glaze inside puris + plate well)
  const chatniGroup = new THREE.Group();
  const chatniMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.chatniLiquidMap,
    roughness: 0.14,
    metalness: 0.1,
  });
  const chatniDiskGeo = new THREE.CylinderGeometry(0.148, 0.14, 0.014, 20);
  geometries.push(chatniDiskGeo);
  materials.push(chatniMat);
  const chatniDisk = new THREE.Mesh(chatniDiskGeo, chatniMat);
  chatniDisk.position.y = 0.046;
  chatniGroup.add(chatniDisk);
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const glaze = new THREE.Mesh(puriLiquidCapGeo, chatniMat);
    glaze.position.set(Math.cos(angle) * ringRadius, 0.077, Math.sin(angle) * ringRadius);
    glaze.scale.setScalar(0.86);
    chatniGroup.add(glaze);
  }
  chatniGroup.visible = false;
  group.add(chatniGroup);
  ingredientNodes.sweet_chatni = chatniGroup;

  // 4. Curd (creamy white yogurt swirls with soft glossy specular response)
  const curdGroup = new THREE.Group();
  const curdMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.curdSwirlMap,
    roughness: 0.22,
    metalness: 0.04,
  });
  const curdBlobGeo = new THREE.SphereGeometry(0.023, 12, 8);
  curdBlobGeo.scale(1.12, 0.46, 1.12);
  geometries.push(curdBlobGeo);
  materials.push(curdMat);
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const c = new THREE.Mesh(curdBlobGeo, curdMat);
    c.position.set(Math.cos(angle) * ringRadius, 0.08, Math.sin(angle) * ringRadius);
    curdGroup.add(c);
  }
  curdGroup.visible = false;
  group.add(curdGroup);
  ingredientNodes.curd = curdGroup;

  // 5. Sev (golden-yellow crispy gram-flour strands + ring garnish on top)
  const sevGroup = new THREE.Group();
  const sevMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.sevStrandMap,
    bumpMap: pbr.sevStrandBump,
    bumpScale: 0.012,
    roughness: 0.58,
    metalness: 0.04,
  });
  const sevSprinkleGeo = new THREE.TorusGeometry(0.108, 0.013, 8, 22);
  sevSprinkleGeo.rotateX(Math.PI / 2);
  const sevStrandStickGeo = new THREE.CylinderGeometry(0.0032, 0.0032, 0.042, 6);
  sevStrandStickGeo.rotateZ(Math.PI / 2);
  geometries.push(sevSprinkleGeo, sevStrandStickGeo);
  materials.push(sevMat);

  const sevRing = new THREE.Mesh(sevSprinkleGeo, sevMat);
  sevRing.position.y = 0.087;
  sevGroup.add(sevRing);

  // Individual criss-crossing 3D Sev strands atop each puri for close-up realism
  for (let i = 0; i < 12; i++) {
    const angle = (i * Math.PI * 2) / 12;
    const strand = new THREE.Mesh(sevStrandStickGeo, sevMat);
    strand.position.set(
      Math.cos(angle) * ringRadius,
      0.092 + (i % 2) * 0.003,
      Math.sin(angle) * ringRadius
    );
    strand.rotation.y = i * 1.15;
    sevGroup.add(strand);
  }

  sevGroup.visible = false;
  group.add(sevGroup);
  ingredientNodes.sev = sevGroup;

  return { group, puriNodes, ingredientNodes };
}

function syncPlateVisualNodes(nodes: PlateVisualNodes, plate: PlateState | null) {
  if (!plate) {
    nodes.group.visible = false;
    return;
  }
  nodes.group.visible = true;
  for (let i = 0; i < 6; i++) {
    nodes.puriNodes[i].visible = plate.puris > i;
  }
  for (const ingId of ALL_POURABLE_IDS) {
    const qty = plate.ingredients[ingId] || 0;
    const node = nodes.ingredientNodes[ingId];
    node.visible = qty > 0;
    if (qty > 0) {
      const s = Math.min(1.25, 0.45 + (qty / 50) * 0.65);
      node.scale.set(s, Math.min(1.3, 0.5 + (qty / 50) * 0.7), s);
    }
  }
}

/**
 * Phase 5 — Builds a detailed medium-poly 3D container mesh for each of the 6 ingredients + plate,
 * complete with hammered brass/copper textures, brushed steel, serving ladles/spoons, and realistic contents.
 */
function buildContainerVisual(
  id: HeldItemId,
  pbr: PbrTextureLibrary,
  geometries: THREE.BufferGeometry[],
  materials: THREE.Material[],
  textures: THREE.Texture[],
  maxAnisotropy: number,
  includeSignPlaque: boolean
): THREE.Group {
  const group = new THREE.Group();

  const steelMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.22,
    metalness: 0.86,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    bumpMap: pbr.hammeredMetalBump,
    bumpScale: 0.008,
    roughness: 0.26,
    metalness: 0.84,
  });
  const copperMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    bumpMap: pbr.hammeredMetalBump,
    bumpScale: 0.008,
    roughness: 0.28,
    metalness: 0.8,
  });
  const ceramicMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    roughness: 0.28,
    metalness: 0.06,
  });
  materials.push(steelMat, brassMat, copperMat, ceramicMat);

  if (id === 'plate') {
    const rimGeo = new THREE.CylinderGeometry(0.205, 0.155, 0.03, 22);
    const lipGeo = new THREE.TorusGeometry(0.2, 0.008, 8, 22);
    lipGeo.rotateX(Math.PI / 2);
    geometries.push(rimGeo, lipGeo);
    const mesh = new THREE.Mesh(rimGeo, steelMat);
    mesh.position.y = 0.018;
    const lip = new THREE.Mesh(lipGeo, steelMat);
    lip.position.y = 0.032;
    group.add(mesh, lip);
    return group;
  }

  let plaqueTitle = '';
  let plaqueAccent = '#f59e0b';

  if (id === 'jeera_jal' || id === 'sweet_chatni') {
    // Traditional Indian Hammered Brass/Copper Matka Pot for Liquid Pani / Chatni + Resting Steel Ladle
    const isJeera = id === 'jeera_jal';
    plaqueTitle = isJeera ? 'JEERA JAL' : 'SWEET CHATNI';
    plaqueAccent = isJeera ? '#4ade80' : '#fb923c';

    const potGeo = new THREE.SphereGeometry(0.172, 20, 14);
    potGeo.scale(1, 0.9, 1);
    const neckGeo = new THREE.CylinderGeometry(0.106, 0.132, 0.072, 20);
    const lipRingGeo = new THREE.TorusGeometry(0.108, 0.012, 8, 20);
    lipRingGeo.rotateX(Math.PI / 2);
    const fillGeo = new THREE.CircleGeometry(0.098, 18);
    fillGeo.rotateX(-Math.PI / 2);
    const ladleHandleGeo = new THREE.CylinderGeometry(0.006, 0.006, 0.22, 8);
    const fillMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: isJeera ? pbr.jeeraLiquidMap : pbr.chatniLiquidMap,
      roughness: 0.12,
      metalness: 0.12,
    });
    geometries.push(potGeo, neckGeo, lipRingGeo, fillGeo, ladleHandleGeo);
    materials.push(fillMat);

    const potMat = isJeera ? brassMat : copperMat;
    const pot = new THREE.Mesh(potGeo, potMat);
    pot.position.y = 0.15;
    pot.castShadow = true;
    const neck = new THREE.Mesh(neckGeo, potMat);
    neck.position.y = 0.30;
    const lipRing = new THREE.Mesh(lipRingGeo, potMat);
    lipRing.position.y = 0.336;
    const fill = new THREE.Mesh(fillGeo, fillMat);
    fill.position.y = 0.334;
    const ladleHandle = new THREE.Mesh(ladleHandleGeo, steelMat);
    ladleHandle.position.set(0.04, 0.39, -0.02);
    ladleHandle.rotation.z = -0.32;
    group.add(pot, neck, lipRing, fill, ladleHandle);
  } else if (id === 'aloo' || id === 'curd' || id === 'sev') {
    const bowlGeo = new THREE.CylinderGeometry(0.165, 0.122, 0.132, 20);
    const bowlLipGeo = new THREE.TorusGeometry(0.164, 0.009, 8, 20);
    bowlLipGeo.rotateX(Math.PI / 2);
    const domeGeo = new THREE.SphereGeometry(0.148, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2);
    domeGeo.scale(1, 0.56, 1);
    const spoonHandleGeo = new THREE.BoxGeometry(0.016, 0.16, 0.005);

    plaqueTitle = id === 'aloo' ? 'ALOO' : id === 'curd' ? 'CURD' : 'SEV';
    plaqueAccent =
      id === 'aloo' ? '#facc15' : id === 'curd' ? '#f8fafc' : '#f59e0b';

    const fillMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map:
        id === 'aloo'
          ? pbr.alooMashMap
          : id === 'curd'
            ? pbr.curdSwirlMap
            : pbr.sevStrandMap,
      bumpMap:
        id === 'aloo'
          ? pbr.alooMashBump
          : id === 'sev'
            ? pbr.sevStrandBump
            : undefined,
      bumpScale: 0.014,
      roughness: id === 'curd' ? 0.22 : id === 'sev' ? 0.58 : 0.82,
      metalness: 0.03,
    });
    geometries.push(bowlGeo, bowlLipGeo, domeGeo, spoonHandleGeo);
    materials.push(fillMat);

    const outerMat =
      id === 'curd' ? ceramicMat : id === 'sev' ? brassMat : steelMat;
    const bowl = new THREE.Mesh(bowlGeo, outerMat);
    bowl.position.y = 0.066;
    bowl.castShadow = true;
    const bowlLip = new THREE.Mesh(bowlLipGeo, outerMat);
    bowlLip.position.y = 0.131;
    const dome = new THREE.Mesh(domeGeo, fillMat);
    dome.position.y = 0.126;
    const spoon = new THREE.Mesh(spoonHandleGeo, steelMat);
    spoon.position.set(0.08, 0.19, -0.03);
    spoon.rotation.z = -0.45;
    group.add(bowl, bowlLip, dome, spoon);
  } else if (id === 'sukhi_puri') {
    plaqueTitle = 'SUKHI PURI';
    plaqueAccent = '#fbbf24';

    const basketGeo = new THREE.CylinderGeometry(0.185, 0.142, 0.132, 20);
    const basketRimGeo = new THREE.TorusGeometry(0.184, 0.01, 8, 20);
    basketRimGeo.rotateX(Math.PI / 2);
    const puriGeo = new THREE.SphereGeometry(0.045, 14, 10);
    puriGeo.scale(1.04, 0.78, 0.98);
    const puriMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: pbr.puriCrustMap,
      bumpMap: pbr.puriCrustBump,
      bumpScale: 0.012,
      roughness: 0.62,
      metalness: 0.03,
    });
    geometries.push(basketGeo, basketRimGeo, puriGeo);
    materials.push(puriMat);

    const basket = new THREE.Mesh(basketGeo, copperMat);
    basket.position.y = 0.066;
    basket.castShadow = true;
    const basketRim = new THREE.Mesh(basketRimGeo, brassMat);
    basketRim.position.y = 0.132;
    group.add(basket, basketRim);

    const offsets = [
      [0, 0.14, 0],
      [-0.082, 0.132, 0.052],
      [0.082, 0.132, 0.052],
      [-0.072, 0.132, -0.062],
      [0.072, 0.132, -0.062],
      [0, 0.192, 0.012],
      [-0.044, 0.182, -0.032],
      [0.044, 0.182, -0.032],
      [0, 0.175, 0.068],
    ];
    for (let idx = 0; idx < offsets.length; idx++) {
      const [ox, oy, oz] = offsets[idx];
      const p = new THREE.Mesh(puriGeo, puriMat);
      p.position.set(ox, oy, oz);
      p.rotation.set((idx % 3) * 0.2, idx * 0.8, 0);
      group.add(p);
    }
  }

  if (includeSignPlaque && plaqueTitle) {
    const tex = createLabelTexture(plaqueTitle, plaqueAccent, maxAnisotropy);
    textures.push(tex);
    const plaqueGeo = new THREE.PlaneGeometry(0.34, 0.085);
    const plaqueMat = new THREE.MeshBasicMaterial({ map: tex });
    geometries.push(plaqueGeo);
    materials.push(plaqueMat);
    const plaque = new THREE.Mesh(plaqueGeo, plaqueMat);
    plaque.position.set(0, 0.42, 0.08);
    group.add(plaque);
  }

  return group;
}

/**
 * Creates the complete 3D interactive food preparation rig on the Pani Puri stall,
 * the first-person held item rig on the camera, and the 3D pouring particle stream.
 */
export function createStallInteractiveRig(
  maxAnisotropy: number
): StallInteractiveRig {
  const rootGroup = new THREE.Group();
  rootGroup.name = 'StallInteractiveRig';

  const cameraHeldGroup = new THREE.Group();
  cameraHeldGroup.name = 'CameraHeldItemRig';
  // Positioned naturally in front of the first-person camera, slightly below & right of the crosshair
  cameraHeldGroup.position.set(0.27, -0.22, -0.52);

  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];
  const textures: THREE.Texture[] = [];
  const raycastTargets: THREE.Object3D[] = [];

  // Shared PBR Texture Library for food, containers & workstation surfaces
  const pbr = createPbrTextureLibrary(maxAnisotropy, textures);

  const hitboxMat = new THREE.MeshBasicMaterial({
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  materials.push(hitboxMat);

  // 1. Dedicated Plate & Puri Preparation Area on the Left-Front of the Expanded Counter
  const plateStackGroup = new THREE.Group();
  plateStackGroup.position.set(
    PLATE_STACK_POSITION.x,
    PLATE_STACK_POSITION.y,
    PLATE_STACK_POSITION.z
  );
  const stackTrayGeo = new THREE.BoxGeometry(0.66, 0.018, 0.52);
  const stackTrayMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.003,
    roughness: 0.38,
    metalness: 0.72,
  });
  const stackPlateGeo = new THREE.CylinderGeometry(0.195, 0.152, 0.024, 22);
  const stackPlateMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.2,
    metalness: 0.88,
  });
  geometries.push(stackTrayGeo, stackPlateGeo);
  materials.push(stackTrayMat, stackPlateMat);

  const stackTrayMesh = new THREE.Mesh(stackTrayGeo, stackTrayMat);
  stackTrayMesh.position.y = 0.009;
  plateStackGroup.add(stackTrayMesh);

  const stackPlateMeshes: THREE.Mesh[] = [];
  for (let i = 0; i < 6; i++) {
    const pm = new THREE.Mesh(stackPlateGeo, stackPlateMat);
    pm.position.y = 0.024 + i * 0.022;
    plateStackGroup.add(pm);
    stackPlateMeshes.push(pm);
  }

  const stackTex = createLabelTexture('EMPTY PLATES', '#38bdf8', maxAnisotropy);
  textures.push(stackTex);
  const stackPlaqueGeo = new THREE.PlaneGeometry(0.40, 0.09);
  const stackPlaqueMat = new THREE.MeshBasicMaterial({ map: stackTex });
  geometries.push(stackPlaqueGeo);
  materials.push(stackPlaqueMat);
  const stackPlaque = new THREE.Mesh(stackPlaqueGeo, stackPlaqueMat);
  stackPlaque.position.set(0, 0.05, 0.27);
  plateStackGroup.add(stackPlaque);

  const stackHitGeo = new THREE.BoxGeometry(0.56, 0.22, 0.52);
  geometries.push(stackHitGeo);
  const stackHitMesh = new THREE.Mesh(stackHitGeo, hitboxMat);
  stackHitMesh.position.y = 0.10;
  plateStackGroup.add(stackHitMesh);
  tagInteractiveHierarchy(plateStackGroup, 'plate_stack');
  rootGroup.add(plateStackGroup);
  raycastTargets.push(plateStackGroup);

  // 2. Wider Teak-Wood Preparation Counter Board & Active Plate Slot in Center-Front (~1.53x wider)
  const prepCounterGroup = new THREE.Group();
  prepCounterGroup.position.set(
    PREP_COUNTER_POSITION.x,
    PREP_COUNTER_POSITION.y,
    PREP_COUNTER_POSITION.z
  );
  const boardGeo = new THREE.BoxGeometry(0.86, 0.026, 0.56);
  const boardMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.woodMap,
    bumpMap: pbr.woodBump,
    bumpScale: 0.008,
    roughness: 0.62,
    metalness: 0.04,
  });
  const boardRimGeo = new THREE.RingGeometry(0.20, 0.245, 28);
  boardRimGeo.rotateX(-Math.PI / 2);
  const boardRimMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    roughness: 0.28,
    metalness: 0.85,
  });
  geometries.push(boardGeo, boardRimGeo);
  materials.push(boardMat, boardRimMat);

  const boardMesh = new THREE.Mesh(boardGeo, boardMat);
  boardMesh.position.y = 0.013;
  const boardRing = new THREE.Mesh(boardRimGeo, boardRimMat);
  boardRing.position.y = 0.027;
  prepCounterGroup.add(boardMesh, boardRing);

  const prepTex = createLabelTexture('PREP COUNTER', '#fbbf24', maxAnisotropy);
  textures.push(prepTex);
  const prepPlaque = new THREE.Mesh(stackPlaqueGeo, new THREE.MeshBasicMaterial({ map: prepTex }));
  materials.push(prepPlaque.material as THREE.Material);
  prepPlaque.position.set(0, 0.05, 0.29);
  prepCounterGroup.add(prepPlaque);

  const prepHitGeo = new THREE.BoxGeometry(0.84, 0.14, 0.56);
  geometries.push(prepHitGeo);
  const prepHitMesh = new THREE.Mesh(prepHitGeo, hitboxMat);
  prepHitMesh.position.y = 0.065;
  prepCounterGroup.add(prepHitMesh);
  tagInteractiveHierarchy(prepCounterGroup, 'prep_counter');
  rootGroup.add(prepCounterGroup);
  raycastTargets.push(prepCounterGroup);

  // Active Plate Visual on Prep Counter
  const activePlateVisual = buildDetailedPlateVisual(pbr, geometries, materials);
  activePlateVisual.group.position.set(
    PREP_COUNTER_POSITION.x,
    PREP_COUNTER_POSITION.y + 0.026,
    PREP_COUNTER_POSITION.z
  );
  const activePlateHitGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.14, 16);
  geometries.push(activePlateHitGeo);
  const activePlateHit = new THREE.Mesh(activePlateHitGeo, hitboxMat);
  activePlateHit.position.y = 0.065;
  activePlateVisual.group.add(activePlateHit);
  tagInteractiveHierarchy(activePlateVisual.group, 'active_plate');
  activePlateVisual.group.visible = false;
  rootGroup.add(activePlateVisual.group);
  raycastTargets.push(activePlateVisual.group);

  // Expanded Raised Brushed Stainless-Steel Ingredient Shelf along the back row (~3.78m wide x 0.56m deep)
  const shelfGeo = new THREE.BoxGeometry(3.78, 0.10, 0.56);
  const shelfFrontLipGeo = new THREE.CylinderGeometry(0.018, 0.018, 3.8, 12);
  shelfFrontLipGeo.rotateZ(Math.PI / 2);
  const shelfMat = new THREE.MeshStandardMaterial({
    color: 0xdbe2ea,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.22,
    metalness: 0.86,
  });
  const holderRingGeo = new THREE.RingGeometry(0.145, 0.185, 24);
  holderRingGeo.rotateX(-Math.PI / 2);
  const holderRingMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.28,
    metalness: 0.82,
  });
  geometries.push(shelfGeo, shelfFrontLipGeo, holderRingGeo);
  materials.push(shelfMat, holderRingMat);

  const shelfMesh = new THREE.Mesh(shelfGeo, shelfMat);
  shelfMesh.position.set(
    PREP_COUNTER_POSITION.x,
    1.11,
    STALL_HOME_POSITIONS.aloo.z
  );
  const shelfFrontLip = new THREE.Mesh(shelfFrontLipGeo, shelfMat);
  shelfFrontLip.position.set(
    PREP_COUNTER_POSITION.x,
    1.158,
    STALL_HOME_POSITIONS.aloo.z + 0.28
  );
  rootGroup.add(shelfMesh, shelfFrontLip);

  // 3. Dedicated Serving Counter Area on the Right-Front of the Counter
  const servingGroup = new THREE.Group();
  servingGroup.position.set(
    SERVING_AREA_POSITION.x,
    SERVING_AREA_POSITION.y,
    SERVING_AREA_POSITION.z
  );
  const servePadGeo = new THREE.BoxGeometry(0.76, 0.026, 0.56);
  geometries.push(servePadGeo);
  const serveMatMesh = new THREE.Mesh(
    servePadGeo,
    new THREE.MeshStandardMaterial({
      color: 0x065f46,
      bumpMap: pbr.canopyFabricBump,
      bumpScale: 0.005,
      roughness: 0.62,
      metalness: 0.06,
    })
  );
  materials.push(serveMatMesh.material as THREE.Material);
  serveMatMesh.position.y = 0.013;
  const serveRing = new THREE.Mesh(boardRimGeo, boardRimMat);
  serveRing.position.y = 0.027;
  servingGroup.add(serveMatMesh, serveRing);

  const serveHitGeo = new THREE.BoxGeometry(0.76, 0.15, 0.56);
  geometries.push(serveHitGeo);
  const serveHitMesh = new THREE.Mesh(serveHitGeo, hitboxMat);
  serveHitMesh.position.y = 0.07;
  servingGroup.add(serveHitMesh);

  const serveTex = createLabelTexture('SERVING AREA', '#34d399', maxAnisotropy);
  textures.push(serveTex);
  const servePlaque = new THREE.Mesh(
    stackPlaqueGeo,
    new THREE.MeshBasicMaterial({ map: serveTex })
  );
  materials.push(servePlaque.material as THREE.Material);
  servePlaque.position.set(0, 0.06, 0.29);
  servingGroup.add(servePlaque);
  tagInteractiveHierarchy(servingGroup, 'serving_area');
  rootGroup.add(servingGroup);
  raycastTargets.push(servingGroup);

  const servedPlateVisual = buildDetailedPlateVisual(pbr, geometries, materials);
  servedPlateVisual.group.position.set(0, 0.026, 0);
  servedPlateVisual.group.visible = false;
  servingGroup.add(servedPlateVisual.group);

  // 4. Dropped Plate in the World (when dropped off-counter)
  const droppedPlateVisual = buildDetailedPlateVisual(pbr, geometries, materials);
  const droppedHit = new THREE.Mesh(activePlateHitGeo, hitboxMat);
  droppedHit.position.y = 0.1;
  droppedPlateVisual.group.add(droppedHit);
  tagInteractiveHierarchy(droppedPlateVisual.group, 'dropped_plate');
  droppedPlateVisual.group.visible = false;
  rootGroup.add(droppedPlateVisual.group);
  raycastTargets.push(droppedPlateVisual.group);

  // 5. Six Properly Spaced Interactive Ingredient Containers on the Stall Counter
  const containerIds: ContainerItemId[] = [
    'jeera_jal',
    'sweet_chatni',
    'aloo',
    'curd',
    'sev',
    'sukhi_puri',
  ];
  const worldContainerGroups = {} as Record<ContainerItemId, THREE.Group>;
  const containerHitGeo = new THREE.BoxGeometry(0.46, 0.52, 0.46);
  geometries.push(containerHitGeo);

  for (const cid of containerIds) {
    const home = STALL_HOME_POSITIONS[cid];

    // Add brass placement ring on the raised shelf for each container home slot
    const slotRing = new THREE.Mesh(holderRingGeo, holderRingMat);
    slotRing.position.set(home.x, 1.162, home.z);
    rootGroup.add(slotRing);

    const cGroup = buildContainerVisual(
      cid,
      pbr,
      geometries,
      materials,
      textures,
      maxAnisotropy,
      true
    );
    const hitMesh = new THREE.Mesh(containerHitGeo, hitboxMat);
    hitMesh.position.y = 0.24;
    cGroup.add(hitMesh);

    cGroup.position.set(home.x, home.y, home.z);
    tagInteractiveHierarchy(cGroup, cid);
    worldContainerGroups[cid] = cGroup;
    rootGroup.add(cGroup);
    raycastTargets.push(cGroup);
  }

  // 6. Camera-Held Item Models (one for each HeldItemId)
  const heldItemModels = {} as Record<HeldItemId, THREE.Group>;
  const allHeldIds: HeldItemId[] = ['plate', ...containerIds];
  for (const hid of allHeldIds) {
    const model = buildContainerVisual(
      hid,
      pbr,
      geometries,
      materials,
      textures,
      maxAnisotropy,
      false
    );
    model.scale.setScalar(0.72);
    model.visible = false;
    cameraHeldGroup.add(model);
    heldItemModels[hid] = model;
  }

  // 7. Lightweight Pooled 3D Pouring Droplets (8 droplets)
  const pourStreamGroup = new THREE.Group();
  pourStreamGroup.visible = false;
  rootGroup.add(pourStreamGroup);

  const dropGeo = new THREE.SphereGeometry(0.024, 10, 8);
  const dropMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    roughness: 0.22,
    metalness: 0.08,
  });
  geometries.push(dropGeo);
  materials.push(dropMat);

  const droplets: THREE.Mesh[] = [];
  for (let i = 0; i < 8; i++) {
    const d = new THREE.Mesh(dropGeo, dropMat);
    pourStreamGroup.add(d);
    droplets.push(d);
  }

  return {
    rootGroup,
    cameraHeldGroup,
    raycastTargets,
    syncWithState: (state: FoodPrepSessionState, _dt: number, elapsedTime: number) => {
      // 1. Update Empty Plate Stack visibility based on remaining stock
      const visibleStackCount = Math.min(
        stackPlateMeshes.length,
        Math.ceil(state.inventory.emptyPlates / 2)
      );
      stackPlateMeshes.forEach((m, idx) => {
        m.visible = idx < visibleStackCount;
      });

      // 2. Sync Active Plate on Preparation Counter
      syncPlateVisualNodes(activePlateVisual, state.activePlate);

      // 3. Sync Served Plate on Serving Area
      syncPlateVisualNodes(
        servedPlateVisual,
        state.lastServedPlate ? state.lastServedPlate.plate : null
      );

      // 4. Sync Dropped Plate in World
      if (state.droppedPlate && state.heldItem !== 'plate') {
        droppedPlateVisual.group.position.set(
          state.droppedPlate.x,
          state.droppedPlate.y,
          state.droppedPlate.z
        );
        syncPlateVisualNodes(droppedPlateVisual, state.droppedPlate.plate);
      } else {
        droppedPlateVisual.group.visible = false;
      }

      // 5. Sync 6 Ingredient Containers (hide world container when held to prevent duplicates)
      for (const cid of containerIds) {
        const grp = worldContainerGroups[cid];
        if (state.heldItem === cid) {
          grp.visible = false;
        } else {
          grp.visible = true;
          const loc = state.containerPlacements[cid];
          grp.position.set(loc.x, loc.y, loc.z);
        }
      }

      // 6. Sync First-Person Held Object & Pouring Tilt
      for (const hid of allHeldIds) {
        const m = heldItemModels[hid];
        const isCurrentHeld = state.heldItem === hid;
        m.visible = isCurrentHeld;
        if (isCurrentHeld) {
          if (state.isPouring) {
            m.rotation.set(0.45, 0.2, 0.55);
            m.position.set(-0.06, 0.04 + Math.sin(elapsedTime * 14) * 0.008, -0.04);
          } else {
            m.rotation.set(0.12, -0.25, 0);
            m.position.set(0, Math.sin(elapsedTime * 3.2) * 0.008, 0);
          }
        }
      }

      // 7. Sync 3D Pouring Stream above the Active Plate
      if (state.isPouring && state.pouringIngredient && state.activePlate) {
        pourStreamGroup.visible = true;
        dropMat.color.setHex(
          POURABLE_INGREDIENTS[state.pouringIngredient].colorHex
        );
        const baseX = PREP_COUNTER_POSITION.x;
        const baseZ = PREP_COUNTER_POSITION.z;
        const startY = PREP_COUNTER_POSITION.y + 0.42;
        const endY = PREP_COUNTER_POSITION.y + 0.06;

        for (let i = 0; i < droplets.length; i++) {
          const phase = (elapsedTime * 3.4 + i / droplets.length) % 1;
          const y = startY - phase * (startY - endY);
          const spread = Math.sin(phase * Math.PI) * 0.045;
          const angle = i * 1.9 + elapsedTime * 5;
          droplets[i].position.set(
            baseX + Math.cos(angle) * spread,
            y,
            baseZ + Math.sin(angle) * spread
          );
        }
      } else {
        pourStreamGroup.visible = false;
      }
    },
    dispose: () => {
      for (const g of geometries) g.dispose();
      for (const m of materials) m.dispose();
      for (const t of textures) t.dispose();
    },
  };
}
