import {
  ALL_POURABLE_IDS,
  ContainerItemId,
  createEmptyPlate,
  hasAnyPlateContents,
  HeldItemId,
  InteractiveTargetId,
  ITEM_DISPLAY_NAMES,
  PlateState,
  PourableIngredientId,
  POURABLE_INGREDIENTS,
  RecipeAccuracyResult,
  RecipeId,
  RECIPES,
  REQUIRED_PURIS_PER_PLATE,
  calculateRecipeAccuracy,
} from './recipes';
import { STALL_POSITION, WORLD_HALF_SIZE } from './worldData';
import {
  createInitialCustomerSystemState,
  CustomerServeResult,
  CustomerSystemState,
  evaluateAndServeCustomerOrder,
  getActiveCustomer,
  getServableActiveCustomer,
  setCustomerSystemLimit,
} from './customerSystem';
import {
  DEFAULT_CUSTOMER_LIMIT,
  DEFAULT_INITIAL_COINS,
  getShopItemEffectivePrice,
  getStarRatingCoinReward,
  INGREDIENT_BASE_PRICES,
  SHOP_ITEMS,
  SHOP_UNITS_PER_PURCHASE,
  SHOP_UPGRADES,
  ShopItemDefinition,
  ShopItemId,
  ShopUpgradeDefinition,
  ShopUpgradeId,
  ShopUpgradesState,
  STAR_RATING_REWARDS,
  UPGRADE_PRICES,
  UPGRADED_CUSTOMER_LIMIT,
} from './economyConfig';
import {
  LEGACY_SAVE_STORAGE_KEY,
  loadVersionedSaveBundle,
  MASTER_SAVE_STORAGE_KEY,
  sanitizeSavedProgress,
  writeVersionedSaveBundle,
} from './saveSystem';

export {
  DEFAULT_CUSTOMER_LIMIT,
  DEFAULT_INITIAL_COINS,
  getShopItemEffectivePrice,
  getStarRatingCoinReward,
  INGREDIENT_BASE_PRICES,
  SHOP_ITEMS,
  SHOP_UNITS_PER_PURCHASE,
  SHOP_UPGRADES,
  STAR_RATING_REWARDS,
  UPGRADE_PRICES,
  UPGRADED_CUSTOMER_LIMIT,
};
export type {
  ShopItemDefinition,
  ShopItemId,
  ShopUpgradeDefinition,
  ShopUpgradeId,
  ShopUpgradesState,
};

export interface IngredientInventory {
  emptyPlates: number;
  sukhi_puri: number;
  aloo: number;
  sev: number;
  curd: number;
  jeera_jal: number;
  sweet_chatni: number;
}

export const DEFAULT_INITIAL_INVENTORY: IngredientInventory = {
  emptyPlates: 12,
  sukhi_puri: 36,
  aloo: 300,
  sev: 200,
  curd: 200,
  jeera_jal: 250,
  sweet_chatni: 250,
};

export const POUR_RATE_PER_SECOND = 40; // 40 quantity units per second

export interface WorldItemPlacement {
  onStallCounter: boolean;
  x: number;
  y: number;
  z: number;
}

export const STALL_HOME_POSITIONS: Record<ContainerItemId, { x: number; y: number; z: number }> = {
  jeera_jal: {
    x: STALL_POSITION.x - 1.55,
    y: 1.16,
    z: STALL_POSITION.z - 0.28,
  },
  sweet_chatni: {
    x: STALL_POSITION.x - 0.93,
    y: 1.16,
    z: STALL_POSITION.z - 0.28,
  },
  aloo: {
    x: STALL_POSITION.x - 0.31,
    y: 1.16,
    z: STALL_POSITION.z - 0.28,
  },
  curd: {
    x: STALL_POSITION.x + 0.31,
    y: 1.16,
    z: STALL_POSITION.z - 0.28,
  },
  sev: {
    x: STALL_POSITION.x + 0.93,
    y: 1.16,
    z: STALL_POSITION.z - 0.28,
  },
  sukhi_puri: {
    x: STALL_POSITION.x + 1.55,
    y: 1.16,
    z: STALL_POSITION.z - 0.24,
  },
};

export const PLATE_STACK_POSITION = {
  x: STALL_POSITION.x - 1.32,
  y: 1.06,
  z: STALL_POSITION.z + 0.48,
};

export const PREP_COUNTER_POSITION = {
  x: STALL_POSITION.x + 0.0,
  y: 1.06,
  z: STALL_POSITION.z + 0.50,
};

export const SERVING_AREA_POSITION = {
  x: STALL_POSITION.x + 1.32,
  y: 1.06,
  z: STALL_POSITION.z + 0.48,
};

export const SAVE_PROGRESS_STORAGE_KEY = MASTER_SAVE_STORAGE_KEY;

export interface SavedGameProgress {
  coins: number;
  customerLimit: number;
  upgrades: ShopUpgradesState;
  inventory: IngredientInventory;
  completedPlatesCount: number;
}

export interface FoodPrepSessionState {
  selectedRecipeId: RecipeId;
  pendingRecipeSwitch: RecipeId | null;
  discardConfirmOpen: boolean;
  heldItem: HeldItemId | null;
  heldPlateData: PlateState | null;
  activePlate: PlateState | null;
  droppedPlate: {
    plate: PlateState;
    x: number;
    y: number;
    z: number;
  } | null;
  lastServedPlate: {
    plate: PlateState;
    recipeId: RecipeId;
    accuracy: number;
    isWithinTolerance: boolean;
    starRating?: number;
    coinsAwarded?: number;
    customerName?: string;
    reactionText?: string;
    servedAt?: number;
  } | null;
  completedPlatesCount: number;
  coins: number;
  customerLimit: number;
  upgrades: ShopUpgradesState;
  inventory: IngredientInventory;
  containerPlacements: Record<ContainerItemId, WorldItemPlacement>;
  aimedTarget: InteractiveTargetId | null;
  contextualPrompt: string | null;
  isPouring: boolean;
  pouringIngredient: PourableIngredientId | null;
  statusBanner: string | null;
  plateSequence: number;
  customerSystem: CustomerSystemState;
}

export type FoodPrepSoundCue =
  | 'pickup'
  | 'drop'
  | 'add_puri'
  | 'pour_tick'
  | 'target_reached'
  | 'empty_stock'
  | 'recipe_complete'
  | 'serving'
  | 'eating'
  | 'rating'
  | 'purchase'
  | 'coin_reward'
  | 'discard'
  | 'notice';

export interface FoodPrepActionOutcome {
  soundCue?: FoodPrepSoundCue;
  message?: string;
  changed: boolean;
}

export function saveGameProgress(state: FoodPrepSessionState): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  const payload: SavedGameProgress = sanitizeSavedProgress({
    coins: state.coins,
    customerLimit: state.customerLimit,
    upgrades: { ...state.upgrades },
    inventory: { ...state.inventory },
    completedPlatesCount: state.completedPlatesCount,
  });
  writeVersionedSaveBundle({ progress: payload });
}

export function loadSavedGameProgress(): SavedGameProgress | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  const bundle = loadVersionedSaveBundle();
  if (!bundle) return null;
  return bundle.progress;
}

export function clearSavedGameProgress(): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.removeItem(MASTER_SAVE_STORAGE_KEY);
    window.localStorage.removeItem(LEGACY_SAVE_STORAGE_KEY);
  } catch {
    // Ignore storage removal errors
  }
}

export function createInitialFoodPrepState(
  customInventory?: Partial<IngredientInventory>,
  initialCoins: number = DEFAULT_INITIAL_COINS,
  options?: { loadFromStorage?: boolean }
): FoodPrepSessionState {
  const containerPlacements = {} as Record<ContainerItemId, WorldItemPlacement>;
  (Object.keys(STALL_HOME_POSITIONS) as ContainerItemId[]).forEach((id) => {
    const home = STALL_HOME_POSITIONS[id];
    containerPlacements[id] = {
      onStallCounter: true,
      x: home.x,
      y: home.y,
      z: home.z,
    };
  });

  const saved = options?.loadFromStorage ? loadSavedGameProgress() : null;
  const upgrades: ShopUpgradesState = saved
    ? { ...saved.upgrades }
    : { moreCustomers: false, discount50: false };
  const customerLimit = upgrades.moreCustomers
    ? UPGRADED_CUSTOMER_LIMIT
    : DEFAULT_CUSTOMER_LIMIT;
  const coins = saved ? saved.coins : initialCoins;
  const inventory: IngredientInventory = {
    ...(saved ? saved.inventory : DEFAULT_INITIAL_INVENTORY),
    ...customInventory,
  };

  const customerSystem = createInitialCustomerSystemState(customerLimit, true);
  const firstActive = getActiveCustomer(customerSystem);

  return {
    selectedRecipeId: firstActive ? firstActive.orderRecipeId : 'sweet_puri',
    pendingRecipeSwitch: null,
    discardConfirmOpen: false,
    heldItem: null,
    heldPlateData: null,
    activePlate: null,
    droppedPlate: null,
    lastServedPlate: null,
    completedPlatesCount: saved ? saved.completedPlatesCount : 0,
    coins,
    customerLimit,
    upgrades,
    inventory,
    containerPlacements,
    aimedTarget: null,
    contextualPrompt: null,
    isPouring: false,
    pouringIngredient: null,
    statusBanner: null,
    plateSequence: 1,
    customerSystem,
  };
}

export function isPourableIngredient(id: HeldItemId | null): id is PourableIngredientId {
  if (!id) return false;
  return (ALL_POURABLE_IDS as string[]).includes(id);
}

export function isContainerItem(id: HeldItemId | null): id is ContainerItemId {
  if (!id) return false;
  return id === 'sukhi_puri' || isPourableIngredient(id);
}

/**
 * Computes the contextual crosshair label based on what the player is currently holding
 * and what interactive 3D object the center crosshair is pointing at.
 */
export function computeContextualPrompt(
  state: FoodPrepSessionState,
  target: InteractiveTargetId | null
): string | null {
  if (!target) return null;

  const held = state.heldItem;
  const activeCustomer = getServableActiveCustomer(state.customerSystem);

  if (!held) {
    switch (target) {
      case 'plate_stack':
        return state.inventory.emptyPlates > 0
          ? 'Pick Up Plate'
          : 'No Empty Plates Remaining';
      case 'active_plate':
        if (
          state.activePlate &&
          calculateRecipeAccuracy(state.activePlate, state.selectedRecipeId).isComplete
        ) {
          return 'Pick Up Prepared Plate';
        }
        return 'Pick Up Plate';
      case 'dropped_plate':
        return 'Pick Up Plate';
      case 'sukhi_puri':
        return 'Pick Up Sukhi Puri';
      case 'aloo':
        return 'Pick Up Aloo';
      case 'sev':
        return 'Pick Up Sev';
      case 'curd':
        return 'Pick Up Curd';
      case 'jeera_jal':
        return 'Pick Up Jeera Jal';
      case 'sweet_chatni':
        return 'Pick Up Sweet Chatni';
      case 'prep_counter':
        return state.activePlate
          ? `Active Plate (Puris: ${state.activePlate.puris}/${REQUIRED_PURIS_PER_PLATE})`
          : 'Preparation Counter (Place a Plate Here)';
      case 'serving_area':
        if (state.activePlate && hasAnyPlateContents(state.activePlate) && activeCustomer) {
          return `Serve ${RECIPES[activeCustomer.orderRecipeId].name} to ${activeCustomer.name}`;
        }
        return activeCustomer
          ? `Serving Area (${activeCustomer.name}: ${RECIPES[activeCustomer.orderRecipeId].name})`
          : 'Serving Area';
      default:
        return null;
    }
  }

  // Player is holding a Plate
  if (held === 'plate') {
    if (target === 'serving_area') {
      return activeCustomer
        ? `Serve Plate to ${activeCustomer.name}`
        : 'Serve Plate at Serving Area';
    }
    if (target === 'prep_counter' || target === 'active_plate') {
      return state.activePlate
        ? 'Preparation Counter Occupied'
        : 'Place Plate on Counter';
    }
    return 'Drop Plate';
  }

  // Player is holding Sukhi Puri container
  if (held === 'sukhi_puri') {
    if ((target === 'active_plate' || target === 'prep_counter') && state.activePlate) {
      if (state.activePlate.puris >= REQUIRED_PURIS_PER_PLATE) {
        return 'All 6 puris added!';
      }
      if (state.inventory.sukhi_puri <= 0) {
        return 'Out of Sukhi Puri Stock!';
      }
      return `Add Sukhi Puri (Puris: ${state.activePlate.puris}/${REQUIRED_PURIS_PER_PLATE})`;
    }
    return 'Place Down Sukhi Puri';
  }

  // Player is holding a pourable ingredient container
  if (isPourableIngredient(held)) {
    const ingName = ITEM_DISPLAY_NAMES[held];
    if ((target === 'active_plate' || target === 'prep_counter') && state.activePlate) {
      if (state.inventory[held] <= 0) {
        return `${ingName} Empty!`;
      }
      const currentAmt = state.activePlate.ingredients[held];
      const targetAmt = RECIPES[state.selectedRecipeId].targetIngredients[held];
      return targetAmt > 0
        ? `Hold Pour: ${ingName} (${currentAmt}/${targetAmt})`
        : `Hold Pour: ${ingName} (${currentAmt})`;
    }
    return `Place Down ${ingName}`;
  }

  return null;
}

/**
 * Computes a safe world drop position in front of the player that does not fall through
 * the ground or overlap inside the stall counter body.
 */
export function computeSafeDropPosition(
  playerX: number,
  playerZ: number,
  playerYaw: number
): { onStallCounter: boolean; x: number; y: number; z: number } {
  const forwardX = -Math.sin(playerYaw);
  const forwardZ = -Math.cos(playerYaw);
  const candidateX = playerX + forwardX * 1.15;
  const candidateZ = playerZ + forwardZ * 1.15;

  // Check if drop point is over or very near the expanded 1.5x stall counter
  const nearCounterX = Math.abs(candidateX - STALL_POSITION.x) <= 2.15;
  const nearCounterZ = Math.abs(candidateZ - STALL_POSITION.z) <= 1.25;

  if (nearCounterX && nearCounterZ) {
    return {
      onStallCounter: true,
      x: Math.max(STALL_POSITION.x - 1.75, Math.min(STALL_POSITION.x + 1.75, candidateX)),
      y: 1.06,
      z: Math.max(STALL_POSITION.z - 0.55, Math.min(STALL_POSITION.z + 0.55, candidateZ)),
    };
  }

  // Clamp within expanded world bounds on the ground surface
  const boundLimit = WORLD_HALF_SIZE - 1.5;
  return {
    onStallCounter: false,
    x: Math.max(-boundLimit, Math.min(boundLimit, candidateX)),
    y: 0.02,
    z: Math.max(-boundLimit, Math.min(boundLimit, candidateZ)),
  };
}

/**
 * Handles the Pick/Drop button (and keyboard interaction) based on current held item and aimed target.
 */
export function performPickOrDrop(
  state: FoodPrepSessionState,
  playerX: number,
  playerZ: number,
  playerYaw: number
): FoodPrepActionOutcome {
  // Always stop any active pouring when Pick/Drop is pressed
  state.isPouring = false;
  state.pouringIngredient = null;

  const held = state.heldItem;
  const target = state.aimedTarget;

  // CASE 1: Player is NOT holding anything -> try to pick up the aimed object or serve at serving_area
  if (!held) {
    if (!target) {
      const msg = 'Aim at a plate or ingredient container on the stall counter.';
      state.statusBanner = msg;
      return { soundCue: 'notice', message: msg, changed: true };
    }

    if (target === 'serving_area' && state.activePlate && hasAnyPlateContents(state.activePlate)) {
      return completeActivePlate(state);
    }

    if (target === 'plate_stack') {
      if (state.inventory.emptyPlates <= 0) {
        const msg = 'No empty plates remaining in stock!';
        state.statusBanner = msg;
        return { soundCue: 'empty_stock', message: msg, changed: true };
      }
      state.inventory.emptyPlates -= 1;
      saveGameProgress(state);
      const newPlate = createEmptyPlate(`plate-${state.plateSequence}`);
      state.plateSequence += 1;
      state.heldItem = 'plate';
      state.heldPlateData = newPlate;
      const msg = 'Picked up an empty plate. Aim at the Preparation Counter and press Pick/Drop to place it.';
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'pickup', message: msg, changed: true };
    }

    if (target === 'active_plate' && state.activePlate) {
      const isPlateComplete = calculateRecipeAccuracy(
        state.activePlate,
        state.selectedRecipeId
      ).isComplete;
      if (hasAnyPlateContents(state.activePlate) && !isPlateComplete) {
        const msg = 'Plate is in preparation! Add remaining ingredients, Serve, or Discard it.';
        state.statusBanner = msg;
        return { soundCue: 'notice', message: msg, changed: true };
      }
      state.heldItem = 'plate';
      state.heldPlateData = state.activePlate;
      state.activePlate = null;
      const msg = isPlateComplete
        ? 'Picked up prepared plate. Aim at the Serving Area or Active Customer and press Pick/Drop to serve!'
        : 'Picked up the empty plate from the counter.';
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'pickup', message: msg, changed: true };
    }

    if (target === 'dropped_plate' && state.droppedPlate) {
      state.heldItem = 'plate';
      state.heldPlateData = state.droppedPlate.plate;
      state.droppedPlate = null;
      const msg = 'Picked up the plate.';
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'pickup', message: msg, changed: true };
    }

    if (isContainerItem(target as HeldItemId)) {
      const containerId = target as ContainerItemId;
      state.heldItem = containerId;
      const label = ITEM_DISPLAY_NAMES[containerId];
      const msg =
        containerId === 'sukhi_puri'
          ? 'Holding Sukhi Puri. Aim at the active plate and press Pick/Drop to add puris (up to 6).'
          : `Holding ${label}. Aim at the active plate and hold Pour to add ${label}.`;
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'pickup', message: msg, changed: true };
    }

    if (target === 'prep_counter') {
      const msg = state.activePlate
        ? 'Pick up Sukhi Puri or an ingredient container to prepare the active plate.'
        : 'Pick up an empty plate from the Plate Stack on the left first.';
      state.statusBanner = msg;
      return { soundCue: 'notice', message: msg, changed: true };
    }

    if (target === 'serving_area') {
      const activeCustomer = getServableActiveCustomer(state.customerSystem);
      const msg = activeCustomer
        ? `${activeCustomer.name} ordered ${RECIPES[activeCustomer.orderRecipeId].name}. Prepare a plate on the counter and serve it here!`
        : 'Wait for a customer to arrive at the stall counter.';
      state.statusBanner = msg;
      return { soundCue: 'notice', message: msg, changed: true };
    }

    return { changed: false };
  }

  // CASE 2: Player is holding a Plate
  if (held === 'plate') {
    const plateToPlace = state.heldPlateData || createEmptyPlate(`plate-${state.plateSequence++}`);

    // Serving a held plate directly at the Serving Area or Active Customer
    if (target === 'serving_area') {
      if (!state.activePlate) {
        state.activePlate = plateToPlace;
        state.heldItem = null;
        state.heldPlateData = null;
      }
      return completeActivePlate(state);
    }

    const distToPrep = Math.hypot(
      playerX - PREP_COUNTER_POSITION.x,
      playerZ - PREP_COUNTER_POSITION.z
    );
    const aimingAtCounter =
      target === 'prep_counter' ||
      target === 'active_plate' ||
      (distToPrep <= 4.2 && !state.activePlate);

    if (aimingAtCounter) {
      if (state.activePlate) {
        const msg = 'Preparation counter already has an active plate!';
        state.statusBanner = msg;
        return { soundCue: 'notice', message: msg, changed: true };
      }
      state.activePlate = plateToPlace;
      state.heldItem = null;
      state.heldPlateData = null;
      const msg = 'Plate placed on Preparation Counter! Pick up Sukhi Puri to add 6 puris.';
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'drop', message: msg, changed: true };
    }

    // Otherwise drop the plate at a safe position in the world
    if (state.droppedPlate) {
      if (!state.activePlate) {
        state.activePlate = plateToPlace;
        state.heldItem = null;
        state.heldPlateData = null;
        const msg = 'Plate placed on Preparation Counter.';
        state.statusBanner = msg;
        return { soundCue: 'drop', message: msg, changed: true };
      }
      const msg = 'Place this plate on the Preparation Counter first.';
      state.statusBanner = msg;
      return { soundCue: 'notice', message: msg, changed: true };
    }

    const dropPos = computeSafeDropPosition(playerX, playerZ, playerYaw);
    if (dropPos.onStallCounter && !state.activePlate) {
      state.activePlate = plateToPlace;
      state.heldItem = null;
      state.heldPlateData = null;
      const msg = 'Plate placed on Preparation Counter! Pick up Sukhi Puri to add 6 puris.';
      state.statusBanner = msg;
      state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
      return { soundCue: 'drop', message: msg, changed: true };
    }

    state.droppedPlate = {
      plate: plateToPlace,
      x: dropPos.x,
      y: dropPos.y,
      z: dropPos.z,
    };
    state.heldItem = null;
    state.heldPlateData = null;
    const msg = 'Dropped plate in front of you.';
    state.statusBanner = msg;
    state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
    return { soundCue: 'drop', message: msg, changed: true };
  }

  // CASE 3: Player is holding Sukhi Puri and aiming at the Active Plate -> Add 1 Sukhi Puri!
  if (
    held === 'sukhi_puri' &&
    (target === 'active_plate' || target === 'prep_counter') &&
    state.activePlate
  ) {
    return addSinglePuriToActivePlate(state);
  }

  // CASE 4: Player is holding a container and presses Pick/Drop to place/drop it
  if (isContainerItem(held)) {
    return returnOrDropHeldContainer(state, playerX, playerZ, playerYaw);
  }

  return { changed: false };
}

/**
 * Adds exactly 1 Sukhi Puri to the active plate (up to 6).
 * Prevents adding more than 6 puris and never wastes inventory when full.
 */
export function addSinglePuriToActivePlate(
  state: FoodPrepSessionState
): FoodPrepActionOutcome {
  if (state.heldItem !== 'sukhi_puri') {
    const msg = 'Pick up the Sukhi Puri container first.';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }
  if (!state.activePlate) {
    const msg = 'Place an empty plate on the Preparation Counter first!';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }
  if (state.activePlate.puris >= REQUIRED_PURIS_PER_PLATE) {
    const msg = 'All 6 puris added!';
    state.statusBanner = msg;
    state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
    return { soundCue: 'notice', message: msg, changed: true };
  }
  if (state.inventory.sukhi_puri <= 0) {
    const msg = 'Out of Sukhi Puri stock!';
    state.statusBanner = msg;
    return { soundCue: 'empty_stock', message: msg, changed: true };
  }

  state.inventory.sukhi_puri -= 1;
  state.activePlate.puris += 1;
  state.activePlate.status = 'in_progress';
  saveGameProgress(state);

  const count = state.activePlate.puris;
  const msg =
    count >= REQUIRED_PURIS_PER_PLATE
      ? 'All 6 puris added!'
      : `Puris: ${count}/${REQUIRED_PURIS_PER_PLATE}`;
  state.statusBanner = msg;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);

  return {
    soundCue: count >= REQUIRED_PURIS_PER_PLATE ? 'target_reached' : 'add_puri',
    message: msg,
    changed: true,
  };
}

/**
 * Places the currently held ingredient container back onto its stall counter home slot
 * (if near the stall) or drops it at a safe world position in front of the player.
 */
export function returnOrDropHeldContainer(
  state: FoodPrepSessionState,
  playerX: number,
  playerZ: number,
  playerYaw: number
): FoodPrepActionOutcome {
  const held = state.heldItem;
  if (!isContainerItem(held)) {
    return { changed: false };
  }

  state.isPouring = false;
  state.pouringIngredient = null;

  const distToStall = Math.hypot(
    playerX - STALL_POSITION.x,
    playerZ - STALL_POSITION.z
  );

  const label = ITEM_DISPLAY_NAMES[held];

  if (distToStall <= 5.5) {
    const home = STALL_HOME_POSITIONS[held];
    state.containerPlacements[held] = {
      onStallCounter: true,
      x: home.x,
      y: home.y,
      z: home.z,
    };
    state.heldItem = null;
    const msg = `Placed ${label} back on the stall counter.`;
    state.statusBanner = msg;
    state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
    return { soundCue: 'drop', message: msg, changed: true };
  }

  const dropPos = computeSafeDropPosition(playerX, playerZ, playerYaw);
  if (dropPos.onStallCounter) {
    const home = STALL_HOME_POSITIONS[held];
    state.containerPlacements[held] = {
      onStallCounter: true,
      x: home.x,
      y: home.y,
      z: home.z,
    };
  } else {
    state.containerPlacements[held] = {
      onStallCounter: false,
      x: dropPos.x,
      y: dropPos.y,
      z: dropPos.z,
    };
  }

  state.heldItem = null;
  const msg = `Dropped ${label}.`;
  state.statusBanner = msg;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
  return { soundCue: 'drop', message: msg, changed: true };
}

/**
 * Starts pouring when the player presses and holds the Pour button.
 */
export function startIngredientPour(
  state: FoodPrepSessionState
): FoodPrepActionOutcome {
  const held = state.heldItem;

  if (!held) {
    const msg = 'Pick up an ingredient container before pouring.';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  if (held === 'plate') {
    const msg = 'Place the plate on the Preparation Counter first.';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  if (held === 'sukhi_puri') {
    const msg = 'Sukhi Puri is placed one at a time using Pick/Drop while aiming at the plate.';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  if (!state.activePlate) {
    const msg = 'Place an empty plate on the Preparation Counter before pouring!';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  const aimingAtPlate =
    state.aimedTarget === 'active_plate' || state.aimedTarget === 'prep_counter';
  if (!aimingAtPlate) {
    const msg = 'Aim the crosshair at the active plate on the counter to pour.';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  if (state.inventory[held] <= 0) {
    const msg = `Out of ${ITEM_DISPLAY_NAMES[held]} stock!`;
    state.statusBanner = msg;
    state.isPouring = false;
    state.pouringIngredient = null;
    return { soundCue: 'empty_stock', message: msg, changed: true };
  }

  state.isPouring = true;
  state.pouringIngredient = held;
  return { changed: true };
}

export function stopIngredientPour(state: FoodPrepSessionState): boolean {
  if (!state.isPouring && !state.pouringIngredient) return false;
  state.isPouring = false;
  state.pouringIngredient = null;
  return true;
}

/**
 * Advances pouring by `unitsToAdd` whole integer units.
 * Automatically stops pouring if the target plate leaves the valid interaction area
 * or if the ingredient stock runs out.
 */
export function stepIngredientPourUnits(
  state: FoodPrepSessionState,
  unitsToAdd: number
): FoodPrepActionOutcome {
  if (!state.isPouring || !state.pouringIngredient) {
    return { changed: false };
  }

  const ing = state.pouringIngredient;
  if (state.heldItem !== ing || !state.activePlate) {
    stopIngredientPour(state);
    return { changed: true };
  }

  const aimingAtPlate =
    state.aimedTarget === 'active_plate' || state.aimedTarget === 'prep_counter';
  if (!aimingAtPlate) {
    stopIngredientPour(state);
    state.statusBanner = 'Stopped pouring (moved crosshair off the plate).';
    return { changed: true };
  }

  const available = state.inventory[ing];
  if (available <= 0) {
    stopIngredientPour(state);
    const msg = `Out of ${POURABLE_INGREDIENTS[ing].name} stock!`;
    state.statusBanner = msg;
    return { soundCue: 'empty_stock', message: msg, changed: true };
  }

  const actualAdd = Math.min(unitsToAdd, available);
  if (actualAdd <= 0) {
    return { changed: false };
  }

  const prevAmount = state.activePlate.ingredients[ing];
  const nextAmount = prevAmount + actualAdd;
  state.activePlate.ingredients[ing] = nextAmount;
  state.inventory[ing] -= actualAdd;
  state.activePlate.status = 'in_progress';
  saveGameProgress(state);

  const targetAmt = RECIPES[state.selectedRecipeId].targetIngredients[ing];
  const crossedTarget =
    targetAmt > 0 && prevAmount < targetAmt && nextAmount >= targetAmt;

  let soundCue: FoodPrepSoundCue = 'pour_tick';
  if (state.inventory[ing] <= 0) {
    stopIngredientPour(state);
    state.statusBanner = `${POURABLE_INGREDIENTS[ing].name} container is now empty!`;
    soundCue = 'empty_stock';
  } else if (crossedTarget) {
    state.statusBanner = `Target reached for ${POURABLE_INGREDIENTS[ing].name} (${nextAmount}/${targetAmt})!`;
    soundCue = 'target_reached';
  }

  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
  return { soundCue, changed: true };
}

/**
 * Discards the currently active plate, clearing its contents and releasing the preparation slot.
 * Does not refund already-added ingredients.
 */
export function discardActivePlate(
  state: FoodPrepSessionState,
  forceConfirmed: boolean = false
): FoodPrepActionOutcome {
  state.isPouring = false;
  state.pouringIngredient = null;

  if (!state.activePlate) {
    state.discardConfirmOpen = false;
    state.pendingRecipeSwitch = null;
    return { changed: false };
  }

  if (hasAnyPlateContents(state.activePlate) && !forceConfirmed) {
    state.discardConfirmOpen = true;
    return { soundCue: 'notice', changed: true };
  }

  state.activePlate = null;
  state.discardConfirmOpen = false;

  if (state.pendingRecipeSwitch) {
    state.selectedRecipeId = state.pendingRecipeSwitch;
    state.pendingRecipeSwitch = null;
  }

  const msg = 'Discarded plate. Preparation counter is ready for a new plate.';
  state.statusBanner = msg;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
  return { soundCue: 'discard', message: msg, changed: true };
}

/**
 * Selects a recipe from the order panel. If the active plate already has ingredients,
 * requires confirmation to discard the current plate before switching.
 */
export function requestRecipeSelection(
  state: FoodPrepSessionState,
  nextRecipeId: RecipeId
): FoodPrepActionOutcome {
  if (state.selectedRecipeId === nextRecipeId) {
    state.pendingRecipeSwitch = null;
    return { changed: false };
  }

  if (state.activePlate && hasAnyPlateContents(state.activePlate)) {
    state.pendingRecipeSwitch = nextRecipeId;
    state.discardConfirmOpen = true;
    return { soundCue: 'notice', changed: true };
  }

  state.selectedRecipeId = nextRecipeId;
  state.pendingRecipeSwitch = null;
  state.discardConfirmOpen = false;
  const msg = `Selected order: ${RECIPES[nextRecipeId].name}`;
  state.statusBanner = msg;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
  return { soundCue: 'pickup', message: msg, changed: true };
}

/**
 * Completes and serves the active plate to the active NPC customer at the stall counter.
 * Validates:
 * 1. Active customer waiting at the serving position
 * 2. Active plate exists with 6 Sukhi Puris
 * 3. Plate matches the active customer's requested recipe and has all required ingredients
 * 4. Awards 50 / 30 / 20 / 15 / 5 coins based on 1..5 star rating and transitions customer to EATING -> REACTING -> LEAVING.
 */
export function completeActivePlate(
  state: FoodPrepSessionState
): FoodPrepActionOutcome & {
  evaluation?: RecipeAccuracyResult;
  serveResult?: CustomerServeResult;
} {
  state.isPouring = false;
  state.pouringIngredient = null;

  if (!state.activePlate && state.heldItem === 'plate' && state.heldPlateData) {
    state.activePlate = state.heldPlateData;
    state.heldItem = null;
    state.heldPlateData = null;
  }

  if (!state.activePlate) {
    const msg = 'No active plate on the Preparation Counter!';
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  const serveRes = evaluateAndServeCustomerOrder(
    state.customerSystem,
    state.activePlate
  );

  if (!serveRes.accepted) {
    state.statusBanner = serveRes.message;
    const fallbackEval =
      serveRes.evaluation ??
      calculateRecipeAccuracy(state.activePlate, state.selectedRecipeId);
    return {
      soundCue: 'notice',
      message: serveRes.message,
      changed: true,
      evaluation: fallbackEval,
      serveResult: serveRes,
    };
  }

  const evaluation = serveRes.evaluation!;
  const servedRecipeId = serveRes.recipeId ?? state.selectedRecipeId;
  const activeCustomer = getActiveCustomer(state.customerSystem);

  state.activePlate.status = 'completed';
  state.activePlate.finalAccuracy = evaluation.accuracy;

  state.lastServedPlate = {
    plate: {
      ...state.activePlate,
      ingredients: { ...state.activePlate.ingredients },
    },
    recipeId: servedRecipeId,
    accuracy: evaluation.accuracy,
    isWithinTolerance: evaluation.isWithinTolerance,
    starRating: serveRes.starRating,
    coinsAwarded: serveRes.coinsAwarded,
    customerName: activeCustomer?.name,
    reactionText: serveRes.reactionText,
    servedAt: Date.now(),
  };

  state.coins = Math.max(0, Number((state.coins + serveRes.coinsAwarded).toFixed(2)));
  state.completedPlatesCount += 1;
  state.activePlate = null;
  state.discardConfirmOpen = false;
  state.pendingRecipeSwitch = null;

  saveGameProgress(state);

  state.statusBanner = serveRes.message;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);

  return {
    soundCue: 'recipe_complete',
    message: serveRes.message,
    changed: true,
    evaluation,
    serveResult: serveRes,
  };
}

/**
 * Purchases +10 units of a shop item (ingredient or empty plates) if the player has enough coins.
 * Applies the 50% discount exactly once to eligible ingredient/plate purchases.
 * Preserves the current active plate, recipe, and customer order state.
 */
export function purchaseShopItem(
  state: FoodPrepSessionState,
  itemId: ShopItemId
): FoodPrepActionOutcome {
  const itemDef = SHOP_ITEMS.find((it) => it.id === itemId);
  if (!itemDef) {
    return { changed: false };
  }

  const price = getShopItemEffectivePrice(
    itemDef.basePrice,
    state.upgrades.discount50
  );

  if (!Number.isFinite(state.coins) || state.coins < price) {
    const msg = `Not enough coins for ${itemDef.name}! Need ${price} coins.`;
    state.statusBanner = msg;
    return { soundCue: 'empty_stock', message: msg, changed: true };
  }

  state.coins = Math.max(0, Number((state.coins - price).toFixed(2)));
  state.inventory[itemDef.inventoryKey] += itemDef.unitsPerPurchase;
  saveGameProgress(state);

  const msg = `Purchased +${itemDef.unitsPerPurchase} ${itemDef.name} for ${price} coin${price === 1 ? '' : 's'}.`;
  state.statusBanner = msg;
  state.contextualPrompt = computeContextualPrompt(state, state.aimedTarget);
  return { soundCue: 'purchase', message: msg, changed: true };
}

/**
 * Purchases a one-time stall upgrade (More Customers: 5 -> 10, or 50% Discount).
 * Note: Upgrades are never discounted by the 50% ingredient discount.
 * Prevents duplicate one-time purchases and blocks when coins are insufficient.
 */
export function purchaseShopUpgrade(
  state: FoodPrepSessionState,
  upgradeId: ShopUpgradeId
): FoodPrepActionOutcome {
  const upgradeDef = SHOP_UPGRADES.find((u) => u.id === upgradeId);
  if (!upgradeDef) {
    return { changed: false };
  }

  const alreadyOwned =
    upgradeId === 'more_customers'
      ? state.upgrades.moreCustomers
      : state.upgrades.discount50;

  if (alreadyOwned) {
    const msg = `${upgradeDef.name} upgrade is already active!`;
    state.statusBanner = msg;
    return { soundCue: 'notice', message: msg, changed: true };
  }

  const upgradePrice = upgradeDef.price;

  if (!Number.isFinite(state.coins) || state.coins < upgradePrice) {
    const msg = `Not enough coins for ${upgradeDef.name}! Need ${upgradePrice} coins.`;
    state.statusBanner = msg;
    return { soundCue: 'empty_stock', message: msg, changed: true };
  }

  state.coins = Math.max(0, Number((state.coins - upgradePrice).toFixed(2)));

  if (upgradeId === 'more_customers') {
    state.upgrades.moreCustomers = true;
    state.customerLimit = UPGRADED_CUSTOMER_LIMIT;
    setCustomerSystemLimit(state.customerSystem, UPGRADED_CUSTOMER_LIMIT);
  } else if (upgradeId === 'discount_50') {
    state.upgrades.discount50 = true;
  }

  saveGameProgress(state);

  const msg = `Unlocked ${upgradeDef.name}! ${upgradeDef.description}`;
  state.statusBanner = msg;
  return { soundCue: 'purchase', message: msg, changed: true };
}
