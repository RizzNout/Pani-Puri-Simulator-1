import { ColliderBox } from '../types/game';

/**
 * Phase 4.5 — Expanded 60 x 60 city grid layout (1 grid unit = 1.2 meters => 72m x 72m playable city,
 * 2x the original 36m x 36m dimensions and 4x total playable surface area).
 */
export const GRID_DIMENSIONS = 60;
export const TILE_SCALE = 1.2;
export const WORLD_SIZE = GRID_DIMENSIONS * TILE_SCALE; // 72.0m
export const WORLD_HALF_SIZE = WORLD_SIZE / 2; // 36.0m
export const PLAYER_RADIUS = 0.42;
export const PLAYER_EYE_HEIGHT = 1.65;

export const STALL_POSITION = {
  x: 4.5,
  y: 0,
  z: -4.5,
};

/**
 * 1.5x Expanded Pani Puri Stall physical dimensions (compared to Phase 1-4 2.68m x 1.42m counter)
 */
export const STALL_COUNTER_WIDTH = 4.05;
export const STALL_COUNTER_DEPTH = 2.06;

export const INITIAL_PLAYER_SPAWN = {
  x: 4.5,
  y: 0,
  z: -1.9,
  yaw: 0, // Facing -Z directly toward the central Pani Puri stall and counter
  pitch: -0.22,
};

export interface BuildingSpec {
  id: string;
  name: string;
  type: 'residential' | 'commercial';
  x: number;
  z: number;
  width: number;
  depth: number;
  height: number;
  primaryColor: number;
  secondaryColor: number;
  accentColor: number;
  floors: number;
  signText?: string;
}

/**
 * Road layout reference for collision-free placement:
 * - Main North-South Avenue (MG Road): x in [-2.6, 2.6]
 * - Main East-West Avenue (Bazaar Main St): z in [-2.6, 2.6]
 * - Inner Ring Side Streets: x = ±10.0 ([-11.3, -8.7] and [8.7, 11.3]), z = ±10.0 ([-11.3, -8.7] and [8.7, 11.3])
 * - Outer Ring Boulevards: x = ±22.0 ([-23.4, -20.6] and [20.6, 23.4]), z = ±22.0 ([-23.4, -20.6] and [20.6, 23.4])
 * Every building below is strictly inside city blocks with generous sidewalk clearance.
 */
export const CITY_BUILDINGS: BuildingSpec[] = [
  // ============================================================================
  // INNER & MID RING DISTRICTS (Preserved & aligned with ±10.0m inner streets)
  // ============================================================================

  // Northwest Quadrant — Colorful Residential & Corner Chai/Bakery Shop
  {
    id: 'bld-nw-inner',
    name: 'Surya Residency',
    type: 'residential',
    x: -5.6,
    z: -5.6,
    width: 3.6,
    depth: 3.6,
    height: 7.5,
    primaryColor: 0xf97316, // Warm terracotta orange
    secondaryColor: 0xffedd5,
    accentColor: 0x9a3412,
    floors: 2,
  },
  {
    id: 'bld-nw-north',
    name: 'Bombay Bakery & Cafe',
    type: 'commercial',
    x: -5.6,
    z: -15.6,
    width: 4.4,
    depth: 4.0,
    height: 6.2,
    primaryColor: 0xfef08a, // Marigold cream
    secondaryColor: 0x78350f,
    accentColor: 0xd97706,
    floors: 2,
    signText: 'BOMBAY BAKERY',
  },
  {
    id: 'bld-nw-west',
    name: 'Neelkanth Apartments',
    type: 'residential',
    x: -15.6,
    z: -5.6,
    width: 4.0,
    depth: 4.4,
    height: 9.8,
    primaryColor: 0x38bdf8, // Jodhpur sky blue
    secondaryColor: 0xe0f2fe,
    accentColor: 0x0369a1,
    floors: 3,
  },
  {
    id: 'bld-nw-corner',
    name: 'Grand Heritage Flats',
    type: 'residential',
    x: -15.6,
    z: -15.6,
    width: 5.0,
    depth: 5.0,
    height: 11.2,
    primaryColor: 0xfb7185, // Jaipur rose pink
    secondaryColor: 0xffe4e6,
    accentColor: 0x9f1239,
    floors: 3,
  },

  // Northeast Quadrant — Inner block is the Expanded Pani Puri Stall Plaza!
  {
    id: 'bld-ne-north',
    name: 'Laxmi Saree Emporium',
    type: 'commercial',
    x: 5.6,
    z: -15.6,
    width: 4.4,
    depth: 4.0,
    height: 7.0,
    primaryColor: 0xc084fc, // Festive lavender
    secondaryColor: 0xf3e8ff,
    accentColor: 0x6b21a8,
    floors: 2,
    signText: 'LAXMI EMPORIUM',
  },
  {
    id: 'bld-ne-east',
    name: 'Spice & Chai Corner',
    type: 'commercial',
    x: 15.6,
    z: -5.6,
    width: 4.0,
    depth: 4.2,
    height: 6.4,
    primaryColor: 0xfbbf24, // Turmeric gold
    secondaryColor: 0xfef3c7,
    accentColor: 0xb45309,
    floors: 2,
    signText: 'MASALA CHAI',
  },
  {
    id: 'bld-ne-corner',
    name: 'Apex Tech Plaza',
    type: 'commercial',
    x: 15.6,
    z: -15.6,
    width: 5.0,
    depth: 5.0,
    height: 12.6,
    primaryColor: 0x60a5fa, // Modern glass blue
    secondaryColor: 0xdbeafe,
    accentColor: 0x1e3a8a,
    floors: 4,
    signText: 'APEX PLAZA',
  },

  // Southwest Quadrant — Market & Apartments
  {
    id: 'bld-sw-inner',
    name: 'Kaveri Sweet House',
    type: 'commercial',
    x: -5.6,
    z: 5.6,
    width: 3.6,
    depth: 3.6,
    height: 6.2,
    primaryColor: 0xfdba74, // Peach sandstone
    secondaryColor: 0xffedd5,
    accentColor: 0xc2410c,
    floors: 2,
    signText: 'KAVERI SWEETS',
  },
  {
    id: 'bld-sw-west',
    name: 'Vrindavan Villa',
    type: 'residential',
    x: -15.6,
    z: 5.6,
    width: 4.0,
    depth: 4.4,
    height: 8.6,
    primaryColor: 0x4ade80, // Mint pistachio
    secondaryColor: 0xdcfce7,
    accentColor: 0x15803d,
    floors: 3,
  },
  {
    id: 'bld-sw-south',
    name: 'City Medical & General',
    type: 'commercial',
    x: -5.6,
    z: 15.6,
    width: 4.4,
    depth: 4.0,
    height: 7.4,
    primaryColor: 0x2dd4bf, // Teal cyan
    secondaryColor: 0xccfbf1,
    accentColor: 0x0f766e,
    floors: 2,
    signText: 'CITY CHEMIST',
  },
  {
    id: 'bld-sw-corner',
    name: 'Ashoka Towers',
    type: 'residential',
    x: -15.6,
    z: 15.6,
    width: 5.0,
    depth: 5.0,
    height: 11.8,
    primaryColor: 0xf472b6, // Warm coral pink
    secondaryColor: 0xfce7f3,
    accentColor: 0x9d174d,
    floors: 4,
  },

  // Southeast Quadrant — Inner block is Green City Park!
  {
    id: 'bld-se-east',
    name: 'Mayur Residency',
    type: 'residential',
    x: 15.6,
    z: 5.6,
    width: 4.0,
    depth: 4.4,
    height: 8.4,
    primaryColor: 0xa78bfa, // Soft indigo
    secondaryColor: 0xede9fe,
    accentColor: 0x4c1d95,
    floors: 3,
  },
  {
    id: 'bld-se-south',
    name: 'Ganesh Grocery Mart',
    type: 'commercial',
    x: 5.6,
    z: 15.6,
    width: 4.4,
    depth: 4.0,
    height: 6.8,
    primaryColor: 0xfacc15, // Warm saffron yellow
    secondaryColor: 0xfef9c3,
    accentColor: 0x854d0e,
    floors: 2,
    signText: 'DAILY MART',
  },
  {
    id: 'bld-se-corner',
    name: 'Horizon Corporate Hub',
    type: 'commercial',
    x: 15.6,
    z: 15.6,
    width: 5.0,
    depth: 5.0,
    height: 12.2,
    primaryColor: 0x3b82f6,
    secondaryColor: 0xdbeafe,
    accentColor: 0x1d4ed8,
    floors: 4,
    signText: 'HORIZON HUB',
  },

  // ============================================================================
  // PHASE 4.5 — EXPANDED OUTER RING DISTRICTS (|x| or |z| in [25.0, 33.0])
  // ============================================================================

  // North Outer District — Heritage Houses, Boutique Shops & Metro Plaza
  {
    id: 'bld-outer-nw-1',
    name: 'Marigold Haveli',
    type: 'residential',
    x: -5.8,
    z: -28.5,
    width: 4.6,
    depth: 4.8,
    height: 8.8,
    primaryColor: 0xfb923c,
    secondaryColor: 0xffedd5,
    accentColor: 0x9a3412,
    floors: 3,
  },
  {
    id: 'bld-outer-nw-2',
    name: 'Rani Silk & Bangles',
    type: 'commercial',
    x: -15.8,
    z: -28.5,
    width: 4.8,
    depth: 4.6,
    height: 7.2,
    primaryColor: 0xf43f5e,
    secondaryColor: 0xffe4e6,
    accentColor: 0x881337,
    floors: 2,
    signText: 'RANI BAZAAR',
  },
  {
    id: 'bld-outer-nw-corner',
    name: 'Himalaya View Apartments',
    type: 'residential',
    x: -28.8,
    z: -28.8,
    width: 5.6,
    depth: 5.6,
    height: 13.4,
    primaryColor: 0x38bdf8,
    secondaryColor: 0xe0f2fe,
    accentColor: 0x0c4a6e,
    floors: 4,
  },
  {
    id: 'bld-outer-ne-1',
    name: 'Old City Chaat & Lassi',
    type: 'commercial',
    x: 5.8,
    z: -28.5,
    width: 4.6,
    depth: 4.6,
    height: 6.8,
    primaryColor: 0xfbbf24,
    secondaryColor: 0xfef3c7,
    accentColor: 0x92400e,
    floors: 2,
    signText: 'ROYAL LASSI',
  },
  {
    id: 'bld-outer-ne-2',
    name: 'Lotus Garden Villas',
    type: 'residential',
    x: 15.8,
    z: -28.5,
    width: 4.8,
    depth: 4.8,
    height: 9.2,
    primaryColor: 0xa855f7,
    secondaryColor: 0xf3e8ff,
    accentColor: 0x581c87,
    floors: 3,
  },
  {
    id: 'bld-outer-ne-corner',
    name: 'Zenith IT Pinnacle',
    type: 'commercial',
    x: 28.8,
    z: -28.8,
    width: 5.8,
    depth: 5.8,
    height: 14.5,
    primaryColor: 0x2563eb,
    secondaryColor: 0xdbeafe,
    accentColor: 0x1e3a8a,
    floors: 5,
    signText: 'ZENITH TECH',
  },

  // East Outer District — Modern Commercial & Residential Blocks
  {
    id: 'bld-outer-e-1',
    name: 'Grand Sapphire Hotel',
    type: 'commercial',
    x: 28.5,
    z: -15.8,
    width: 5.2,
    depth: 4.8,
    height: 12.8,
    primaryColor: 0x0ea5e9,
    secondaryColor: 0xe0f2fe,
    accentColor: 0x0369a1,
    floors: 4,
    signText: 'HOTEL SAPPHIRE',
  },
  {
    id: 'bld-outer-e-2',
    name: 'Shanti Niketan House',
    type: 'residential',
    x: 28.5,
    z: -5.8,
    width: 4.6,
    depth: 4.4,
    height: 7.6,
    primaryColor: 0x34d399,
    secondaryColor: 0xd1fae5,
    accentColor: 0x065f46,
    floors: 2,
  },
  {
    id: 'bld-outer-e-3',
    name: 'Kaveri Hardware & Decor',
    type: 'commercial',
    x: 28.5,
    z: 5.8,
    width: 4.6,
    depth: 4.6,
    height: 7.0,
    primaryColor: 0xf59e0b,
    secondaryColor: 0xfef3c7,
    accentColor: 0x78350f,
    floors: 2,
    signText: 'HOME DECOR',
  },
  {
    id: 'bld-outer-e-4',
    name: 'Sunrise Enclave',
    type: 'residential',
    x: 28.5,
    z: 15.8,
    width: 5.0,
    depth: 4.8,
    height: 10.4,
    primaryColor: 0xf472b6,
    secondaryColor: 0xfce7f3,
    accentColor: 0x831843,
    floors: 3,
  },

  // South Outer District — Suburban Villas, Cinema & Community Hub
  {
    id: 'bld-outer-se-corner',
    name: 'Emerald Green Heights',
    type: 'residential',
    x: 28.8,
    z: 28.8,
    width: 5.6,
    depth: 5.6,
    height: 13.0,
    primaryColor: 0x10b981,
    secondaryColor: 0xd1fae5,
    accentColor: 0x064e3b,
    floors: 4,
  },
  {
    id: 'bld-outer-s-1',
    name: 'Gulmohar Bungalow',
    type: 'residential',
    x: 15.8,
    z: 28.5,
    width: 4.8,
    depth: 4.6,
    height: 7.8,
    primaryColor: 0xf97316,
    secondaryColor: 0xffedd5,
    accentColor: 0x7c2d12,
    floors: 2,
  },
  {
    id: 'bld-outer-s-2',
    name: 'Dakshin Book & Music Stall',
    type: 'commercial',
    x: 5.8,
    z: 28.5,
    width: 4.6,
    depth: 4.4,
    height: 6.6,
    primaryColor: 0x38bdf8,
    secondaryColor: 0xe0f2fe,
    accentColor: 0x075985,
    floors: 2,
    signText: 'BOOK CORNER',
  },
  {
    id: 'bld-outer-s-3',
    name: 'Banyan Courtyard Homes',
    type: 'residential',
    x: -5.8,
    z: 28.5,
    width: 4.6,
    depth: 4.6,
    height: 8.2,
    primaryColor: 0xeab308,
    secondaryColor: 0xfef9c3,
    accentColor: 0x713f12,
    floors: 3,
  },
  {
    id: 'bld-outer-sw-corner',
    name: 'Kala Mandir Multiplex',
    type: 'commercial',
    x: -28.8,
    z: 28.8,
    width: 5.8,
    depth: 5.6,
    height: 11.6,
    primaryColor: 0xec4899,
    secondaryColor: 0xfce7f3,
    accentColor: 0x831843,
    floors: 3,
    signText: 'KALA CINEMA',
  },

  // West Outer District — Artisan Shops & Townhouses
  {
    id: 'bld-outer-w-1',
    name: 'Amber Craft & Pottery',
    type: 'commercial',
    x: -28.5,
    z: -15.8,
    width: 4.8,
    depth: 4.8,
    height: 7.0,
    primaryColor: 0xd97706,
    secondaryColor: 0xfef3c7,
    accentColor: 0x78350f,
    floors: 2,
    signText: 'CRAFT BAZAAR',
  },
  {
    id: 'bld-outer-w-2',
    name: 'Vindhya Terrace Homes',
    type: 'residential',
    x: -28.5,
    z: -5.8,
    width: 4.6,
    depth: 4.6,
    height: 9.0,
    primaryColor: 0x8b5cf6,
    secondaryColor: 0xede9fe,
    accentColor: 0x4c1d95,
    floors: 3,
  },
  {
    id: 'bld-outer-w-3',
    name: 'Narmada Fresh Fruit Mart',
    type: 'commercial',
    x: -28.5,
    z: 15.8,
    width: 4.8,
    depth: 4.6,
    height: 6.8,
    primaryColor: 0x22c55e,
    secondaryColor: 0xdcfce7,
    accentColor: 0x14532d,
    floors: 2,
    signText: 'FRESH FRUITS',
  },
];

export interface TreeSpec {
  id: string;
  x: number;
  z: number;
  scale: number;
  trunkRadius: number;
}

export const CITY_TREES: TreeSpec[] = [
  // 1. Central Green Park trees (SE inner block around x: 5.6, z: 5.6)
  { id: 'tree-park-1', x: 3.9, z: 3.9, scale: 1.05, trunkRadius: 0.25 },
  { id: 'tree-park-2', x: 7.3, z: 3.9, scale: 0.95, trunkRadius: 0.25 },
  { id: 'tree-park-3', x: 3.9, z: 7.3, scale: 1.1, trunkRadius: 0.25 },
  { id: 'tree-park-4', x: 7.3, z: 7.3, scale: 1.0, trunkRadius: 0.25 },

  // 2. Inner & Mid Avenue trees near sidewalks (clear of all roads & stall queue)
  { id: 'tree-ave-1', x: 7.8, z: -7.6, scale: 0.92, trunkRadius: 0.22 },
  { id: 'tree-ave-2', x: -7.8, z: -3.4, scale: 0.95, trunkRadius: 0.22 },
  { id: 'tree-ave-3', x: -3.4, z: 7.8, scale: 0.9, trunkRadius: 0.22 },
  { id: 'tree-ave-4', x: -12.4, z: -12.4, scale: 1.0, trunkRadius: 0.24 },
  { id: 'tree-ave-5', x: 12.4, z: -12.4, scale: 1.05, trunkRadius: 0.24 },
  { id: 'tree-ave-6', x: -12.4, z: 12.4, scale: 0.95, trunkRadius: 0.24 },
  { id: 'tree-ave-7', x: 12.4, z: 12.4, scale: 1.0, trunkRadius: 0.24 },

  // 3. West Sunset Park trees (Outer West Park block around x: -28.5, z: 5.6)
  { id: 'tree-wpark-1', x: -26.2, z: 3.8, scale: 1.08, trunkRadius: 0.25 },
  { id: 'tree-wpark-2', x: -30.8, z: 3.8, scale: 0.98, trunkRadius: 0.25 },
  { id: 'tree-wpark-3', x: -26.2, z: 7.4, scale: 1.02, trunkRadius: 0.25 },
  { id: 'tree-wpark-4', x: -30.8, z: 7.4, scale: 1.12, trunkRadius: 0.25 },

  // 4. South Garden Promenade Park trees (Outer South block around x: -15.8, z: 28.5)
  { id: 'tree-spark-1', x: -13.6, z: 26.2, scale: 1.05, trunkRadius: 0.25 },
  { id: 'tree-spark-2', x: -18.0, z: 26.2, scale: 0.96, trunkRadius: 0.25 },
  { id: 'tree-spark-3', x: -13.6, z: 30.8, scale: 1.0, trunkRadius: 0.25 },
  { id: 'tree-spark-4', x: -18.0, z: 30.8, scale: 1.08, trunkRadius: 0.25 },

  // 5. Outer Ring Boulevard & Sidewalk trees
  { id: 'tree-outer-1', x: -19.2, z: -19.2, scale: 1.05, trunkRadius: 0.24 },
  { id: 'tree-outer-2', x: 19.2, z: -19.2, scale: 1.0, trunkRadius: 0.24 },
  { id: 'tree-outer-3', x: -19.2, z: 19.2, scale: 1.02, trunkRadius: 0.24 },
  { id: 'tree-outer-4', x: 19.2, z: 19.2, scale: 1.06, trunkRadius: 0.24 },
  { id: 'tree-outer-5', x: -3.4, z: -24.8, scale: 0.95, trunkRadius: 0.22 },
  { id: 'tree-outer-6', x: 3.4, z: -24.8, scale: 0.98, trunkRadius: 0.22 },
  { id: 'tree-outer-7', x: -3.4, z: 24.8, scale: 0.96, trunkRadius: 0.22 },
  { id: 'tree-outer-8', x: 3.4, z: 24.8, scale: 1.02, trunkRadius: 0.22 },
  { id: 'tree-outer-9', x: 24.8, z: -3.4, scale: 0.98, trunkRadius: 0.22 },
];

export interface BenchSpec {
  id: string;
  x: number;
  z: number;
  rotationY: number;
}

export const CITY_BENCHES: BenchSpec[] = [
  // Central Green Park benches
  { id: 'bench-park-n', x: 5.6, z: 3.8, rotationY: 0 },
  { id: 'bench-park-s', x: 5.6, z: 7.4, rotationY: Math.PI },
  // Expanded Pani Puri Stall Plaza bench (East edge of plaza)
  { id: 'bench-plaza-e', x: 7.6, z: -4.5, rotationY: -Math.PI / 2 },
  // West Sunset Park benches
  { id: 'bench-wpark-n', x: -28.5, z: 3.7, rotationY: 0 },
  { id: 'bench-wpark-s', x: -28.5, z: 7.5, rotationY: Math.PI },
  // South Garden Promenade benches
  { id: 'bench-spark-n', x: -15.8, z: 26.1, rotationY: 0 },
  { id: 'bench-spark-s', x: -15.8, z: 30.9, rotationY: Math.PI },
  // Outer Boulevard rest benches
  { id: 'bench-ave-n', x: -3.5, z: -18.5, rotationY: Math.PI / 2 },
  { id: 'bench-ave-s', x: 3.5, z: 18.5, rotationY: -Math.PI / 2 },
  { id: 'bench-ave-e', x: 18.5, z: -3.5, rotationY: 0 },
];

/**
 * Builds the complete list of solid AABB colliders for buildings, the expanded 1.5x Pani Puri stall,
 * trees, and park benches so the player cannot walk through solid objects.
 */
export function buildWorldColliders(): ColliderBox[] {
  const colliders: ColliderBox[] = [];

  // 1. Buildings
  for (const b of CITY_BUILDINGS) {
    colliders.push({
      id: b.id,
      label: b.name,
      minX: b.x - b.width / 2,
      maxX: b.x + b.width / 2,
      minZ: b.z - b.depth / 2,
      maxZ: b.z + b.depth / 2,
      height: b.height,
    });
  }

  // 2. Expanded Central Pani Puri Stall Counter (~1.5x footprint: 3.96m x 1.92m solid counter bounds)
  colliders.push({
    id: 'pani-puri-stall',
    label: 'Pani Puri Stall Counter',
    minX: STALL_POSITION.x - 1.98,
    maxX: STALL_POSITION.x + 1.98,
    minZ: STALL_POSITION.z - 0.96,
    maxZ: STALL_POSITION.z + 0.96,
    height: 2.8,
  });

  // 3. Trees (solid trunks)
  for (const t of CITY_TREES) {
    colliders.push({
      id: t.id,
      label: 'Tree Trunk',
      minX: t.x - t.trunkRadius,
      maxX: t.x + t.trunkRadius,
      minZ: t.z - t.trunkRadius,
      maxZ: t.z + t.trunkRadius,
      height: 3.5,
    });
  }

  // 4. Benches
  for (const bench of CITY_BENCHES) {
    const isEW = Math.abs(Math.sin(bench.rotationY)) > 0.7;
    const halfW = isEW ? 0.3 : 0.75;
    const halfD = isEW ? 0.75 : 0.3;
    colliders.push({
      id: bench.id,
      label: 'Park Bench',
      minX: bench.x - halfW,
      maxX: bench.x + halfW,
      minZ: bench.z - halfD,
      maxZ: bench.z + halfD,
      height: 0.9,
    });
  }

  return colliders;
}

export const WORLD_COLLIDERS: ColliderBox[] = buildWorldColliders();

export function getZoneName(x: number, z: number): string {
  const distToStall = Math.hypot(x - STALL_POSITION.x, z - STALL_POSITION.z);
  if (distToStall < 5.2) {
    return 'Pani Puri Stall Plaza';
  }
  if (x > 2.8 && x < 8.5 && z > 2.8 && z < 8.5) {
    return 'Green City Park';
  }
  if (x < -24.5 && x > -32.5 && z > 2.8 && z < 8.5) {
    return 'West Sunset Park';
  }
  if (x < -12.0 && x > -19.5 && z > 24.5 && z < 32.5) {
    return 'South Garden Promenade';
  }
  if (Math.abs(x) <= 2.6 && Math.abs(z) <= 2.6) {
    return 'Central Chowk Intersection';
  }
  if (Math.abs(x) <= 2.6) {
    return 'MG Road Avenue';
  }
  if (Math.abs(z) <= 2.6) {
    return 'Bazaar Main Street';
  }
  if (Math.abs(Math.abs(x) - 10.0) <= 1.35 || Math.abs(Math.abs(z) - 10.0) <= 1.35) {
    return 'Inner Ring Street';
  }
  if (Math.abs(Math.abs(x) - 22.0) <= 1.45 || Math.abs(Math.abs(z) - 22.0) <= 1.45) {
    return 'Outer Ring Boulevard';
  }
  return 'City Neighborhood Block';
}
