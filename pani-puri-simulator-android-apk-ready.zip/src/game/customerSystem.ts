import {
  calculateRecipeAccuracy,
  ITEM_DISPLAY_NAMES,
  PlateState,
  RecipeAccuracyResult,
  RecipeId,
  RECIPES,
  RECIPE_LIST,
  REQUIRED_PURIS_PER_PLATE,
} from './recipes';
import { STAR_RATING_REWARDS } from './economyConfig';

export type CustomerState =
  | 'SPAWNING'
  | 'WALKING_TO_QUEUE'
  | 'WAITING_IN_QUEUE'
  | 'ORDERING'
  | 'WAITING_FOR_FOOD'
  | 'EATING'
  | 'REACTING'
  | 'LEAVING';

export type CustomerHairStyle =
  | 'short_parted'
  | 'bun'
  | 'curly_top'
  | 'ponytail'
  | 'side_sweep'
  | 'bob_cut';

export type CustomerOutfitType =
  | 'tshirt_trousers'
  | 'shirt_trousers'
  | 'summer_dress'
  | 'jacket_jeans'
  | 'kurta_churidar'
  | 'polo_chinos';

export type CustomerAccessory = 'none' | 'glasses' | 'cap' | 'dupatta' | 'headphones';
export type CustomerMood = 'very_happy' | 'happy' | 'neutral' | 'disappointed' | 'unhappy';

export interface CustomerAppearance {
  archetypeId: string;
  outfitType: CustomerOutfitType;
  skinToneHex: number;
  shirtColorHex: number;
  outerwearColorHex: number;
  bottomColorHex: number;
  shoeColorHex: number;
  hairColorHex: number;
  hairStyle: CustomerHairStyle;
  accessory: CustomerAccessory;
  accentColorHex: number;
  heightScale: number;
  buildScale: number;
}

export interface Waypoint2D {
  x: number;
  z: number;
}

export interface QueueSlotSpec {
  x: number;
  z: number;
  facingYaw: number;
}

export interface CustomerEntity {
  id: string;
  name: string;
  state: CustomerState;
  appearance: CustomerAppearance;
  x: number;
  z: number;
  yaw: number;
  walkSpeed: number;
  animPhase: number;
  stateTimer: number;
  queueSlotIndex: number | null;
  waypoints: Waypoint2D[];
  orderRecipeId: RecipeId;
  maxPatience: number;
  patience: number; // 0..maxPatience seconds remaining
  orderServed: boolean;
  starRating: number | null; // 1..5 stars (or 0 if patience expired)
  coinsAwarded: number;
  reactionText: string | null;
  reactionMood: CustomerMood | null;
}

export interface CustomerServeResult {
  accepted: boolean;
  message: string;
  starRating: number;
  coinsAwarded: number;
  reactionText: string;
  mood: CustomerMood;
  customerId: string | null;
  recipeId: RecipeId | null;
  evaluation: RecipeAccuracyResult | null;
}

export interface CustomerSystemStepSummary {
  spawnedCustomerId: string | null;
  newlyActiveCustomerId: string | null;
  NewlyActiveOrderRecipeId: RecipeId | null;
  patienceExpiredCustomerId: string | null;
  despawnedCustomerIds: string[];
  uiChanged: boolean;
}

export interface CustomerSystemState {
  customers: CustomerEntity[];
  maxCustomers: number;
  spawnCooldown: number;
  spawnIntervalSeconds: number;
  nextCustomerSeq: number;
  totalServedCount: number;
  totalWalkedOutCount: number;
  lastServedSummary: {
    customerId: string;
    customerName: string;
    recipeId: RecipeId;
    starRating: number;
    coinsAwarded: number;
    reactionText: string;
    mood: CustomerMood;
    timestamp: number;
  } | null;
}

export const DEFAULT_CUSTOMER_PATIENCE_SECONDS = 55;
export const ORDERING_GREETING_DURATION = 0.45;
export const EATING_DURATION_SECONDS = 1.15;
export const REACTING_DURATION_SECONDS = 1.35;
export const SPAWN_INITIAL_DURATION = 0.25;

/**
 * 10 organized queue slots starting on the customer side of the expanded 1.5x Pani Puri stall counter
 * (facing +Z toward the vendor and Serving Area) and extending north/west along the stall plaza and North Inner Street (z = -10.0).
 * None of these coordinates intersect any building, tree, bench, or the player's workspace.
 */
export const QUEUE_SLOTS: QueueSlotSpec[] = [
  { x: 5.25, z: -6.05, facingYaw: 0 }, // Slot 0: Active Customer at Expanded Serving Counter
  { x: 4.65, z: -7.05, facingYaw: 0.45 }, // Slot 1
  { x: 4.65, z: -8.05, facingYaw: 0 }, // Slot 2
  { x: 4.65, z: -9.05, facingYaw: 0 }, // Slot 3
  { x: 4.65, z: -10.0, facingYaw: 0 }, // Slot 4
  { x: 3.45, z: -10.0, facingYaw: Math.PI / 2 }, // Slot 5
  { x: 2.25, z: -10.0, facingYaw: Math.PI / 2 }, // Slot 6
  { x: 1.05, z: -10.0, facingYaw: Math.PI / 2 }, // Slot 7
  { x: -0.15, z: -10.0, facingYaw: Math.PI / 2 }, // Slot 8
  { x: -1.35, z: -10.0, facingYaw: Math.PI / 2 }, // Slot 9
];

interface EdgeSpawnRoute {
  spawn: Waypoint2D;
  approachWaypoints: Waypoint2D[];
}

/**
 * Expanded 2x City-edge spawn routes along clear roads and boulevards (±33.5m world edges and ±22.0m outer ring).
 */
export const CITY_EDGE_SPAWN_ROUTES: EdgeSpawnRoute[] = [
  {
    // North Main Avenue Outer Edge
    spawn: { x: 0.0, z: -33.5 },
    approachWaypoints: [
      { x: 0.0, z: -22.0 },
      { x: 0.0, z: -10.0 },
    ],
  },
  {
    // Northeast Inner Ring Street Edge
    spawn: { x: 10.0, z: -33.5 },
    approachWaypoints: [
      { x: 10.0, z: -10.0 },
      { x: 4.65, z: -10.0 },
    ],
  },
  {
    // Northwest Inner Ring Street Edge
    spawn: { x: -10.0, z: -33.5 },
    approachWaypoints: [
      { x: -10.0, z: -10.0 },
      { x: 0.0, z: -10.0 },
    ],
  },
  {
    // East Main Avenue Outer Edge
    spawn: { x: 33.5, z: 0.0 },
    approachWaypoints: [
      { x: 10.0, z: 0.0 },
      { x: 10.0, z: -10.0 },
      { x: 4.65, z: -10.0 },
    ],
  },
  {
    // West Main Avenue Outer Edge
    spawn: { x: -33.5, z: 0.0 },
    approachWaypoints: [
      { x: 0.0, z: 0.0 },
      { x: 0.0, z: -10.0 },
    ],
  },
  {
    // South Main Avenue Outer Edge
    spawn: { x: 0.0, z: 33.5 },
    approachWaypoints: [
      { x: 0.0, z: 0.0 },
      { x: 0.0, z: -10.0 },
    ],
  },
  {
    // Northeast Outer Ring Boulevard
    spawn: { x: 22.0, z: -22.0 },
    approachWaypoints: [
      { x: 10.0, z: -22.0 },
      { x: 10.0, z: -10.0 },
      { x: 4.65, z: -10.0 },
    ],
  },
  {
    // Northwest Outer Ring Boulevard
    spawn: { x: -22.0, z: -22.0 },
    approachWaypoints: [
      { x: 0.0, z: -22.0 },
      { x: 0.0, z: -10.0 },
    ],
  },
];

/**
 * Exit route for customers leaving the expanded stall counter (walks east to East Inner Street at x = 10.0, then out to the city edge).
 * Never crosses the queue or the player's standing area.
 */
export const CUSTOMER_EXIT_WAYPOINTS: Waypoint2D[] = [
  { x: 8.2, z: -6.05 },
  { x: 10.0, z: -6.05 },
  { x: 10.0, z: -33.5 },
];

const CUSTOMER_NAMES = [
  'Aarav',
  'Priya',
  'Rohan',
  'Ananya',
  'Vikram',
  'Neha',
  'Kabir',
  'Meera',
  'Arjun',
  'Diya',
  'Dev',
  'Kavya',
];

const SKIN_TONES = [
  0xf3c68f, // Warm Light Tan
  0xe5b278, // Golden Medium
  0xd2955a, // Warm Bronze
  0xb9773e, // Rich Caramel
  0x8d5524, // Deep Umber
  0xc98a5b, // Cinnamon Tan
];

const SHIRT_COLORS = [
  0xf97316, // Saffron Orange
  0x2563eb, // Royal Blue
  0x10b981, // Emerald Green
  0xe11d48, // Rose Crimson
  0x8b5cf6, // Festive Violet
  0x0891b2, // Peacock Teal
  0xeab308, // Marigold Gold
  0xdb2777, // Rani Pink
  0xf8fafc, // Crisp White
  0x4f46e5, // Indigo Blue
];

const OUTERWEAR_COLORS = [
  0x1e293b, // Slate Navy Jacket
  0x7c2d12, // Terracotta Leather
  0x065f46, // Forest Olive
  0x312e81, // Deep Denim Indigo
  0x9a3412, // Rust Spice
  0x3f3f46, // Charcoal Vest
  0xb45309, // Amber Ochre
  0x831843, // Mulberry Wine
];

const BOTTOM_COLORS = [
  0x1e293b, // Dark Slate Trousers
  0x1d4ed8, // Classic Blue Jeans
  0xfef3c7, // Cream Churidar / Chinos
  0x334155, // Charcoal Slacks
  0x451a03, // Espresso Brown
  0x312e81, // Indigo Denim
  0xd6d3d1, // Khaki Stone
];

const SHOE_COLORS = [
  0x1c1917, // Jet Black
  0x451a03, // Dark Leather Brown
  0xf8fafc, // Clean White Sneakers
  0x1e3a8a, // Navy Canvas
  0x7f1d1d, // Burgundy Loafers
];

const HAIR_COLORS = [
  0x0f172a, // Raven Black
  0x1c1917, // Espresso Black
  0x3b1e08, // Deep Chestnut Brown
  0x5c2d0c, // Warm Auburn Brown
  0x27272a, // Charcoal Salt-Pepper
];

const ACCENT_COLORS = [0xfbbf24, 0x38bdf8, 0xf43f5e, 0xa855f7, 0x4ade80, 0xfb923c];

export interface CustomerArchetypeSpec {
  id: string;
  outfitType: CustomerOutfitType;
  hairStyle: CustomerHairStyle;
  accessory: CustomerAccessory;
  heightScale: number;
  buildScale: number;
}

/**
 * 8 distinct reusable human character archetypes combining outfits, hairstyles, accessories, and proportions.
 */
export const CUSTOMER_ARCHETYPES: CustomerArchetypeSpec[] = [
  {
    id: 'casual_tee_parted',
    outfitType: 'tshirt_trousers',
    hairStyle: 'short_parted',
    accessory: 'none',
    heightScale: 1.0,
    buildScale: 1.0,
  },
  {
    id: 'summer_dress_bun',
    outfitType: 'summer_dress',
    hairStyle: 'bun',
    accessory: 'dupatta',
    heightScale: 0.95,
    buildScale: 0.94,
  },
  {
    id: 'street_jacket_curly',
    outfitType: 'jacket_jeans',
    hairStyle: 'curly_top',
    accessory: 'glasses',
    heightScale: 1.04,
    buildScale: 1.03,
  },
  {
    id: 'festive_kurta_ponytail',
    outfitType: 'kurta_churidar',
    hairStyle: 'ponytail',
    accessory: 'dupatta',
    heightScale: 0.97,
    buildScale: 0.96,
  },
  {
    id: 'office_shirt_sweep',
    outfitType: 'shirt_trousers',
    hairStyle: 'side_sweep',
    accessory: 'glasses',
    heightScale: 1.02,
    buildScale: 0.98,
  },
  {
    id: 'sporty_polo_cap',
    outfitType: 'polo_chinos',
    hairStyle: 'short_parted',
    accessory: 'cap',
    heightScale: 1.01,
    buildScale: 1.04,
  },
  {
    id: 'urban_jacket_bob',
    outfitType: 'jacket_jeans',
    hairStyle: 'bob_cut',
    accessory: 'headphones',
    heightScale: 0.96,
    buildScale: 0.95,
  },
  {
    id: 'traditional_kurta_waves',
    outfitType: 'kurta_churidar',
    hairStyle: 'side_sweep',
    accessory: 'none',
    heightScale: 1.05,
    buildScale: 1.01,
  },
];

export function createCustomerAppearance(
  seedIndex: number,
  previousAppearance?: CustomerAppearance | null
): CustomerAppearance {
  let s = Math.abs(seedIndex);
  let archetypeIdx = s % CUSTOMER_ARCHETYPES.length;
  let archetype = CUSTOMER_ARCHETYPES[archetypeIdx];

  // Prevent consecutive identical outfit or archetype
  if (
    previousAppearance &&
    (previousAppearance.archetypeId === archetype.id ||
      previousAppearance.outfitType === archetype.outfitType)
  ) {
    s += 1;
    archetypeIdx = (archetypeIdx + 1) % CUSTOMER_ARCHETYPES.length;
    archetype = CUSTOMER_ARCHETYPES[archetypeIdx];
  }

  let shirtColorHex = SHIRT_COLORS[(s * 3 + 1) % SHIRT_COLORS.length];
  if (previousAppearance && shirtColorHex === previousAppearance.shirtColorHex) {
    shirtColorHex = SHIRT_COLORS[(s * 3 + 4) % SHIRT_COLORS.length];
  }

  const heightJitter = ((s % 3) - 1) * 0.015;
  const buildJitter = (((s * 2) % 3) - 1) * 0.015;

  return {
    archetypeId: archetype.id,
    outfitType: archetype.outfitType,
    skinToneHex: SKIN_TONES[(s * 5 + 1) % SKIN_TONES.length],
    shirtColorHex,
    outerwearColorHex: OUTERWEAR_COLORS[(s * 5 + 2) % OUTERWEAR_COLORS.length],
    bottomColorHex: BOTTOM_COLORS[(s * 5 + 3) % BOTTOM_COLORS.length],
    shoeColorHex: SHOE_COLORS[(s * 3 + 2) % SHOE_COLORS.length],
    hairColorHex: HAIR_COLORS[(s * 7 + 1) % HAIR_COLORS.length],
    hairStyle: archetype.hairStyle,
    accessory: archetype.accessory,
    accentColorHex: ACCENT_COLORS[(s * 3 + 1) % ACCENT_COLORS.length],
    heightScale: Number((archetype.heightScale + heightJitter).toFixed(3)),
    buildScale: Number((archetype.buildScale + buildJitter).toFixed(3)),
  };
}

export function pickOrderRecipe(seq: number): RecipeId {
  const ids: RecipeId[] = ['sweet_puri', 'pani_puri', 'sev_puri'];
  return ids[Math.abs(seq) % ids.length];
}

/**
 * Evaluates a star rating (1..5), coin reward (35/25/15/8/3 from centralized economyConfig),
 * and reaction message from a completed plate accuracy evaluation.
 */
export function computeStarRatingAndReward(evaluation: RecipeAccuracyResult): {
  starRating: number;
  coinsAwarded: number;
  reactionText: string;
  mood: CustomerMood;
} {
  if (evaluation.isWithinTolerance || evaluation.accuracy >= 92) {
    return {
      starRating: 5,
      coinsAwarded: STAR_RATING_REWARDS[5],
      reactionText: 'Perfect! That was delicious!',
      mood: 'very_happy',
    };
  }
  if (evaluation.accuracy >= 78) {
    return {
      starRating: 4,
      coinsAwarded: STAR_RATING_REWARDS[4],
      reactionText: 'Excellent pani puri!',
      mood: 'happy',
    };
  }
  if (evaluation.accuracy >= 62) {
    return {
      starRating: 3,
      coinsAwarded: STAR_RATING_REWARDS[3],
      reactionText: 'Not bad!',
      mood: 'neutral',
    };
  }
  if (evaluation.accuracy >= 45) {
    return {
      starRating: 2,
      coinsAwarded: STAR_RATING_REWARDS[2],
      reactionText: 'Could use more flavour!',
      mood: 'disappointed',
    };
  }
  return {
    starRating: 1,
    coinsAwarded: STAR_RATING_REWARDS[1],
    reactionText: "I'll try another stall next time!",
    mood: 'unhappy',
  };
}

/**
 * Builds obstacle-free waypoints from a customer's current position to their target queue slot.
 */
function buildWaypointsToQueueSlot(
  currentX: number,
  currentZ: number,
  slotIndex: number,
  initialApproach: Waypoint2D[] = []
): Waypoint2D[] {
  const clampedSlot = Math.min(Math.max(0, slotIndex), QUEUE_SLOTS.length - 1);
  const targetSlot = QUEUE_SLOTS[clampedSlot];
  const points: Waypoint2D[] = [...initialApproach];

  // If moving from the North Inner Ring Street (z <= -9.6) into the plaza queue corridor (slots 0..3)
  const lastPt = points.length > 0 ? points[points.length - 1] : { x: currentX, z: currentZ };
  if (clampedSlot <= 3 && Math.abs(lastPt.x - 4.65) > 0.6 && lastPt.z <= -9.0) {
    points.push({ x: 4.65, z: -10.0 });
  }

  points.push({ x: targetSlot.x, z: targetSlot.z });
  return points;
}

/**
 * Returns the customer currently at the front of the queue (Slot 0) in ORDERING or WAITING_FOR_FOOD state.
 */
export function getActiveCustomer(system: CustomerSystemState): CustomerEntity | null {
  for (const c of system.customers) {
    if (
      c.queueSlotIndex === 0 &&
      (c.state === 'ORDERING' || c.state === 'WAITING_FOR_FOOD' || c.state === 'EATING' || c.state === 'REACTING')
    ) {
      return c;
    }
  }
  return null;
}

/**
 * Returns the customer who is actively waiting to be served right now (ORDERING or WAITING_FOR_FOOD and not yet served).
 */
export function getServableActiveCustomer(system: CustomerSystemState): CustomerEntity | null {
  for (const c of system.customers) {
    if (
      c.queueSlotIndex === 0 &&
      (c.state === 'ORDERING' || c.state === 'WAITING_FOR_FOOD') &&
      !c.orderServed
    ) {
      return c;
    }
  }
  return null;
}

/**
 * Re-indexes all queueing customers (WALKING_TO_QUEUE, WAITING_IN_QUEUE, ORDERING, WAITING_FOR_FOOD)
 * so queue slots 0..N-1 are compact and customers advance smoothly when Slot 0 opens.
 */
export function compactCustomerQueue(system: CustomerSystemState): void {
  const queueMembers = system.customers
    .filter((c) => c.queueSlotIndex !== null && c.state !== 'LEAVING')
    .sort((a, b) => (a.queueSlotIndex ?? 99) - (b.queueSlotIndex ?? 99));

  queueMembers.forEach((c, newSlotIdx) => {
    if (c.queueSlotIndex !== newSlotIdx) {
      c.queueSlotIndex = newSlotIdx;
      const slot = QUEUE_SLOTS[Math.min(newSlotIdx, QUEUE_SLOTS.length - 1)];
      // Append intermediary plaza corner if turning from North Inner Street into the stall corridor
      const waypoints: Waypoint2D[] = [];
      if (newSlotIdx <= 3 && c.x < 4.0 && c.z <= -9.2) {
        waypoints.push({ x: 4.65, z: -10.0 });
      }
      waypoints.push({ x: slot.x, z: slot.z });
      c.waypoints = waypoints;
      if (c.state === 'WAITING_IN_QUEUE') {
        c.state = 'WALKING_TO_QUEUE';
      }
    }
  });
}

/**
 * Spawns a single new customer into the city if active count < maxCustomers.
 */
export function spawnCustomer(
  system: CustomerSystemState,
  options?: {
    nearStall?: boolean;
    forceRecipeId?: RecipeId;
    routeIndex?: number;
  }
): CustomerEntity | null {
  if (system.customers.length >= system.maxCustomers) {
    return null;
  }

  const occupiedSlots = system.customers.filter(
    (c) => c.queueSlotIndex !== null && c.state !== 'LEAVING'
  ).length;
  if (occupiedSlots >= QUEUE_SLOTS.length) {
    return null;
  }

  const seq = system.nextCustomerSeq++;
  const slotIndex = occupiedSlots;
  const routeIdx =
    options?.routeIndex !== undefined
      ? Math.abs(options.routeIndex) % CITY_EDGE_SPAWN_ROUTES.length
      : seq % CITY_EDGE_SPAWN_ROUTES.length;
  const route = CITY_EDGE_SPAWN_ROUTES[routeIdx];

  const startX = options?.nearStall ? 4.65 : route.spawn.x;
  const startZ = options?.nearStall ? -8.25 : route.spawn.z;
  const initialWaypoints = options?.nearStall ? [] : route.approachWaypoints;

  const waypoints = buildWaypointsToQueueSlot(startX, startZ, slotIndex, initialWaypoints);
  const firstTarget = waypoints[0] ?? QUEUE_SLOTS[slotIndex];
  const initialYaw = Math.atan2(firstTarget.x - startX, firstTarget.z - startZ);
  const prevCustomer =
    system.customers.length > 0 ? system.customers[system.customers.length - 1] : null;

  const customer: CustomerEntity = {
    id: `cust-${seq}`,
    name: CUSTOMER_NAMES[(seq - 1) % CUSTOMER_NAMES.length],
    state: 'SPAWNING',
    appearance: createCustomerAppearance(seq - 1, prevCustomer?.appearance ?? null),
    x: startX,
    z: startZ,
    yaw: initialYaw,
    walkSpeed: 2.35 + ((seq % 3) * 0.12),
    animPhase: (seq * 1.3) % (Math.PI * 2),
    stateTimer: SPAWN_INITIAL_DURATION,
    queueSlotIndex: slotIndex,
    waypoints,
    orderRecipeId: options?.forceRecipeId ?? pickOrderRecipe(seq - 1),
    maxPatience: DEFAULT_CUSTOMER_PATIENCE_SECONDS,
    patience: DEFAULT_CUSTOMER_PATIENCE_SECONDS,
    orderServed: false,
    starRating: null,
    coinsAwarded: 0,
    reactionText: null,
    reactionMood: null,
  };

  system.customers.push(customer);
  return customer;
}

/**
 * Creates the initial Phase 3 NPC Customer System state.
 * Places Customer #1 ready at the stall counter (Slot 0) and Customer #2 walking into the queue
 * so gameplay and order serving are immediately active, while remaining customers spawn gradually from city edges.
 */
export function createInitialCustomerSystemState(
  maxCustomers: number = 5,
  spawnInitialCustomers: boolean = true
): CustomerSystemState {
  const state: CustomerSystemState = {
    customers: [],
    maxCustomers: Math.max(1, maxCustomers),
    spawnCooldown: 3.2,
    spawnIntervalSeconds: 4.2,
    nextCustomerSeq: 1,
    totalServedCount: 0,
    totalWalkedOutCount: 0,
    lastServedSummary: null,
  };

  if (spawnInitialCustomers) {
    const first = spawnCustomer(state, { nearStall: true, forceRecipeId: 'sweet_puri' });
    if (first) {
      first.x = QUEUE_SLOTS[0].x;
      first.z = QUEUE_SLOTS[0].z;
      first.yaw = QUEUE_SLOTS[0].facingYaw;
      first.waypoints = [];
      first.state = 'WAITING_FOR_FOOD';
      first.stateTimer = 0;
    }
    if (state.maxCustomers >= 2) {
      spawnCustomer(state, { nearStall: true, forceRecipeId: 'pani_puri' });
    }
  }

  return state;
}

/**
 * Updates the maximum customer limit (5 default, 10 with "More Customers" upgrade).
 */
export function setCustomerSystemLimit(system: CustomerSystemState, newLimit: number): void {
  system.maxCustomers = Math.max(1, newLimit);
}

/**
 * Steps all active NPC customers, queue advancement, spawning, and patience timers.
 * When `isPausedOrBlocked` is true, customer spawning, movement, and patience timers are paused.
 */
export function stepCustomerSystem(
  system: CustomerSystemState,
  dt: number,
  isPausedOrBlocked: boolean
): CustomerSystemStepSummary {
  const summary: CustomerSystemStepSummary = {
    spawnedCustomerId: null,
    newlyActiveCustomerId: null,
    NewlyActiveOrderRecipeId: null,
    patienceExpiredCustomerId: null,
    despawnedCustomerIds: [],
    uiChanged: false,
  };

  if (isPausedOrBlocked || dt <= 0) {
    return summary;
  }

  // 1. Gradual Customer Spawning up to maxCustomers
  if (system.customers.length < system.maxCustomers) {
    system.spawnCooldown -= dt;
    if (system.spawnCooldown <= 0) {
      const spawned = spawnCustomer(system);
      system.spawnCooldown = system.spawnIntervalSeconds;
      if (spawned) {
        summary.spawnedCustomerId = spawned.id;
        summary.uiChanged = true;
      }
    }
  } else {
    system.spawnCooldown = system.spawnIntervalSeconds;
  }

  let queueNeedsCompaction = false;
  const toRemoveIds = new Set<string>();

  // 2. Step each customer's state machine
  for (const c of system.customers) {
    c.animPhase = (c.animPhase + dt * (c.state === 'WALKING_TO_QUEUE' || c.state === 'LEAVING' ? 7.5 : 2.4)) % (Math.PI * 20);

    switch (c.state) {
      case 'SPAWNING': {
        c.stateTimer -= dt;
        if (c.stateTimer <= 0) {
          c.state = 'WALKING_TO_QUEUE';
        }
        break;
      }

      case 'WALKING_TO_QUEUE': {
        if (c.waypoints.length === 0) {
          const slotIdx = c.queueSlotIndex ?? 0;
          const slot = QUEUE_SLOTS[Math.min(slotIdx, QUEUE_SLOTS.length - 1)];
          c.x = slot.x;
          c.z = slot.z;
          c.yaw = slot.facingYaw;

          if (slotIdx === 0) {
            c.state = 'ORDERING';
            c.stateTimer = ORDERING_GREETING_DURATION;
            summary.newlyActiveCustomerId = c.id;
            summary.NewlyActiveOrderRecipeId = c.orderRecipeId;
            summary.uiChanged = true;
          } else {
            c.state = 'WAITING_IN_QUEUE';
          }
          break;
        }

        const target = c.waypoints[0];
        const dx = target.x - c.x;
        const dz = target.z - c.z;
        const dist = Math.hypot(dx, dz);
        const stepDist = c.walkSpeed * dt;

        if (dist <= stepDist + 0.04) {
          c.x = target.x;
          c.z = target.z;
          c.waypoints.shift();

          if (c.waypoints.length === 0) {
            const slotIdx = c.queueSlotIndex ?? 0;
            const slot = QUEUE_SLOTS[Math.min(slotIdx, QUEUE_SLOTS.length - 1)];
            c.yaw = slot.facingYaw;
            if (slotIdx === 0) {
              c.state = 'ORDERING';
              c.stateTimer = ORDERING_GREETING_DURATION;
              summary.newlyActiveCustomerId = c.id;
              summary.NewlyActiveOrderRecipeId = c.orderRecipeId;
              summary.uiChanged = true;
            } else {
              c.state = 'WAITING_IN_QUEUE';
            }
          }
        } else {
          c.x += (dx / dist) * stepDist;
          c.z += (dz / dist) * stepDist;
          c.yaw = Math.atan2(dx, dz);
        }
        break;
      }

      case 'WAITING_IN_QUEUE': {
        const slotIdx = c.queueSlotIndex ?? 1;
        const slot = QUEUE_SLOTS[Math.min(slotIdx, QUEUE_SLOTS.length - 1)];
        c.yaw = slot.facingYaw;
        if (slotIdx === 0) {
          c.state = 'ORDERING';
          c.stateTimer = ORDERING_GREETING_DURATION;
          summary.newlyActiveCustomerId = c.id;
          summary.NewlyActiveOrderRecipeId = c.orderRecipeId;
          summary.uiChanged = true;
        }
        break;
      }

      case 'ORDERING': {
        c.yaw = QUEUE_SLOTS[0].facingYaw;
        c.patience = Math.max(0, c.patience - dt);
        c.stateTimer -= dt;
        if (c.stateTimer <= 0) {
          c.state = 'WAITING_FOR_FOOD';
          summary.uiChanged = true;
        }
        break;
      }

      case 'WAITING_FOR_FOOD': {
        c.yaw = QUEUE_SLOTS[0].facingYaw;
        const prevWholeSec = Math.ceil(c.patience);
        c.patience = Math.max(0, c.patience - dt);
        const nextWholeSec = Math.ceil(c.patience);
        if (prevWholeSec !== nextWholeSec) {
          summary.uiChanged = true;
        }

        if (c.patience <= 0 && !c.orderServed) {
          // Patience ran out -> react unhappily and leave without paying
          c.orderServed = true;
          c.starRating = 0;
          c.coinsAwarded = 0;
          c.reactionText = "Took too long! I'm leaving!";
          c.reactionMood = 'unhappy';
          c.state = 'REACTING';
          c.stateTimer = REACTING_DURATION_SECONDS;
          system.totalWalkedOutCount += 1;
          summary.patienceExpiredCustomerId = c.id;
          summary.uiChanged = true;
        }
        break;
      }

      case 'EATING': {
        c.stateTimer -= dt;
        if (c.stateTimer <= 0) {
          c.state = 'REACTING';
          c.stateTimer = REACTING_DURATION_SECONDS;
          summary.uiChanged = true;
        }
        break;
      }

      case 'REACTING': {
        c.stateTimer -= dt;
        if (c.stateTimer <= 0) {
          c.state = 'LEAVING';
          c.queueSlotIndex = null;
          c.waypoints = CUSTOMER_EXIT_WAYPOINTS.map((wp) => ({ ...wp }));
          queueNeedsCompaction = true;
          summary.uiChanged = true;
        }
        break;
      }

      case 'LEAVING': {
        if (c.waypoints.length === 0) {
          toRemoveIds.add(c.id);
          summary.despawnedCustomerIds.push(c.id);
          summary.uiChanged = true;
          break;
        }

        const target = c.waypoints[0];
        const dx = target.x - c.x;
        const dz = target.z - c.z;
        const dist = Math.hypot(dx, dz);
        const stepDist = c.walkSpeed * 1.12 * dt;

        if (dist <= stepDist + 0.05) {
          c.x = target.x;
          c.z = target.z;
          c.waypoints.shift();
          if (c.waypoints.length === 0) {
            toRemoveIds.add(c.id);
            summary.despawnedCustomerIds.push(c.id);
            summary.uiChanged = true;
          }
        } else {
          c.x += (dx / dist) * stepDist;
          c.z += (dz / dist) * stepDist;
          c.yaw = Math.atan2(dx, dz);
        }
        break;
      }
    }
  }

  if (toRemoveIds.size > 0) {
    system.customers = system.customers.filter((c) => !toRemoveIds.has(c.id));
  }

  if (queueNeedsCompaction) {
    compactCustomerQueue(system);
  }

  return summary;
}

/**
 * Validates and serves a prepared plate to the active customer at the front of the queue.
 * Enforces:
 * - Active customer waiting in ORDERING or WAITING_FOR_FOOD state
 * - Single-serve lock (prevents duplicate rewards)
 * - 6 Sukhi Puris on the plate
 * - Required ingredients for the active customer's ordered recipe
 * - 1..5 Star rating & 50/30/20/15/5 coin reward calculation
 * - State transition WAITING_FOR_FOOD -> EATING -> REACTING -> LEAVING
 */
export function evaluateAndServeCustomerOrder(
  system: CustomerSystemState,
  plate: PlateState | null
): CustomerServeResult {
  const activeCustomer = getActiveCustomer(system);

  if (!activeCustomer) {
    return {
      accepted: false,
      message: 'Wait for a customer to arrive at the stall counter first!',
      starRating: 0,
      coinsAwarded: 0,
      reactionText: '',
      mood: 'neutral',
      customerId: null,
      recipeId: null,
      evaluation: null,
    };
  }

  if (activeCustomer.orderServed || activeCustomer.state === 'EATING' || activeCustomer.state === 'REACTING') {
    return {
      accepted: false,
      message: `${activeCustomer.name} has already been served! Wait for the next customer.`,
      starRating: 0,
      coinsAwarded: 0,
      reactionText: '',
      mood: 'neutral',
      customerId: activeCustomer.id,
      recipeId: activeCustomer.orderRecipeId,
      evaluation: null,
    };
  }

  if (!plate) {
    return {
      accepted: false,
      message: 'Place an empty plate on the Preparation Counter first!',
      starRating: 0,
      coinsAwarded: 0,
      reactionText: '',
      mood: 'neutral',
      customerId: activeCustomer.id,
      recipeId: activeCustomer.orderRecipeId,
      evaluation: null,
    };
  }

  const orderedRecipeId = activeCustomer.orderRecipeId;
  const orderedRecipe = RECIPES[orderedRecipeId];
  const evaluation = calculateRecipeAccuracy(plate, orderedRecipeId);

  if (evaluation.missingPuris > 0) {
    return {
      accepted: false,
      message: `Incomplete plate: add ${REQUIRED_PURIS_PER_PLATE} Sukhi Puris first (${plate.puris}/${REQUIRED_PURIS_PER_PLATE}).`,
      starRating: 0,
      coinsAwarded: 0,
      reactionText: '',
      mood: 'neutral',
      customerId: activeCustomer.id,
      recipeId: orderedRecipeId,
      evaluation,
    };
  }

  if (!evaluation.isComplete) {
    // Check if the player accidentally prepared a different recipe than what the customer ordered
    const matchedOtherRecipe = RECIPE_LIST.find(
      (r) => r.id !== orderedRecipeId && calculateRecipeAccuracy(plate, r.id).isComplete
    );
    const missingNames = evaluation.missingIngredients
      .map((id) => ITEM_DISPLAY_NAMES[id])
      .join(', ');

    const message = matchedOtherRecipe
      ? `${activeCustomer.name} ordered ${orderedRecipe.name}, not ${matchedOtherRecipe.name}! Missing: ${missingNames}.`
      : `Incomplete ${orderedRecipe.name} for ${activeCustomer.name}: add ${missingNames}.`;

    return {
      accepted: false,
      message,
      starRating: 0,
      coinsAwarded: 0,
      reactionText: '',
      mood: 'neutral',
      customerId: activeCustomer.id,
      recipeId: orderedRecipeId,
      evaluation,
    };
  }

  // Valid plate served! Calculate 1..5 star rating and coin reward
  const ratingRes = computeStarRatingAndReward(evaluation);

  activeCustomer.orderServed = true;
  activeCustomer.starRating = ratingRes.starRating;
  activeCustomer.coinsAwarded = ratingRes.coinsAwarded;
  activeCustomer.reactionText = ratingRes.reactionText;
  activeCustomer.reactionMood = ratingRes.mood;
  activeCustomer.state = 'EATING';
  activeCustomer.stateTimer = EATING_DURATION_SECONDS;

  system.totalServedCount += 1;
  system.lastServedSummary = {
    customerId: activeCustomer.id,
    customerName: activeCustomer.name,
    recipeId: orderedRecipeId,
    starRating: ratingRes.starRating,
    coinsAwarded: ratingRes.coinsAwarded,
    reactionText: ratingRes.reactionText,
    mood: ratingRes.mood,
    timestamp: Date.now(),
  };

  return {
    accepted: true,
    message: `Served ${orderedRecipe.name} to ${activeCustomer.name}! (${ratingRes.starRating}/5 Stars) "${ratingRes.reactionText}" (+${ratingRes.coinsAwarded} Coins)`,
    starRating: ratingRes.starRating,
    coinsAwarded: ratingRes.coinsAwarded,
    reactionText: ratingRes.reactionText,
    mood: ratingRes.mood,
    customerId: activeCustomer.id,
    recipeId: orderedRecipeId,
    evaluation,
  };
}
