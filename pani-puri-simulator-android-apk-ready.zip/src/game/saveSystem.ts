import { GameSettings } from '../types/game';
import {
  DEFAULT_CUSTOMER_LIMIT,
  DEFAULT_INITIAL_COINS,
  ShopUpgradesState,
  UPGRADED_CUSTOMER_LIMIT,
} from './economyConfig';
import {
  cloneControlLayout,
  CONTROL_LAYOUT_STORAGE_KEY,
  ControlLayoutMap,
  DEFAULT_CONTROL_LAYOUT,
  sanitizeControlLayout,
} from './controlLayout';
import {
  DEFAULT_SETTINGS,
  sanitizeSettings,
  SETTINGS_STORAGE_KEY,
} from '../utils/settings';
import type { IngredientInventory, SavedGameProgress } from './foodPrepEngine';

export const SAVE_SCHEMA_VERSION = 4;
export const MASTER_SAVE_STORAGE_KEY = 'pani_puri_sim_save_v4';
export const LEGACY_SAVE_STORAGE_KEY = 'pani_puri_sim_save_v1';

export const SAFE_DEFAULT_INVENTORY: IngredientInventory = {
  emptyPlates: 12,
  sukhi_puri: 36,
  aloo: 300,
  sev: 200,
  curd: 200,
  jeera_jal: 250,
  sweet_chatni: 250,
};

export interface VersionedGameSaveBundle {
  version: number;
  updatedAt: number;
  progress: SavedGameProgress;
  controlLayout: ControlLayoutMap;
  settings: GameSettings;
}

function sanitizeNonNegativeInt(val: unknown, fallback: number): number {
  if (typeof val !== 'number' || !Number.isFinite(val) || val < 0) {
    return fallback;
  }
  return Math.floor(val);
}

function sanitizeNonNegativeCoins(val: unknown, fallback: number = DEFAULT_INITIAL_COINS): number {
  if (typeof val !== 'number' || !Number.isFinite(val) || val < 0) {
    return fallback;
  }
  return Number(val.toFixed(2));
}

export function sanitizeInventory(
  raw: Partial<Record<keyof IngredientInventory, unknown>> | null | undefined,
  fallback: IngredientInventory = SAFE_DEFAULT_INVENTORY
): IngredientInventory {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ...fallback };
  }
  return {
    emptyPlates: sanitizeNonNegativeInt(raw.emptyPlates, fallback.emptyPlates),
    sukhi_puri: sanitizeNonNegativeInt(raw.sukhi_puri, fallback.sukhi_puri),
    aloo: sanitizeNonNegativeInt(raw.aloo, fallback.aloo),
    sev: sanitizeNonNegativeInt(raw.sev, fallback.sev),
    curd: sanitizeNonNegativeInt(raw.curd, fallback.curd),
    jeera_jal: sanitizeNonNegativeInt(raw.jeera_jal, fallback.jeera_jal),
    sweet_chatni: sanitizeNonNegativeInt(raw.sweet_chatni, fallback.sweet_chatni),
  };
}

export function sanitizeUpgrades(raw: unknown): ShopUpgradesState {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { moreCustomers: false, discount50: false };
  }
  const obj = raw as Record<string, unknown>;
  return {
    moreCustomers: Boolean(obj.moreCustomers),
    discount50: Boolean(obj.discount50),
  };
}

/**
 * Validates and sanitizes raw progress data from storage or untrusted JSON.
 * Never throws and never produces negative coins, negative stock, or NaN values.
 */
export function sanitizeSavedProgress(raw: unknown): SavedGameProgress {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      coins: DEFAULT_INITIAL_COINS,
      customerLimit: DEFAULT_CUSTOMER_LIMIT,
      upgrades: { moreCustomers: false, discount50: false },
      inventory: { ...SAFE_DEFAULT_INVENTORY },
      completedPlatesCount: 0,
    };
  }

  const record = raw as Record<string, unknown>;
  const upgrades = sanitizeUpgrades(record.upgrades);
  const customerLimit = upgrades.moreCustomers
    ? UPGRADED_CUSTOMER_LIMIT
    : DEFAULT_CUSTOMER_LIMIT;
  const coins = sanitizeNonNegativeCoins(record.coins, DEFAULT_INITIAL_COINS);
  const inventory = sanitizeInventory(
    record.inventory as Partial<Record<keyof IngredientInventory, unknown>>,
    SAFE_DEFAULT_INVENTORY
  );
  const completedPlatesCount = sanitizeNonNegativeInt(record.completedPlatesCount, 0);

  return {
    coins,
    customerLimit,
    upgrades,
    inventory,
    completedPlatesCount,
  };
}

/**
 * Reads and validates the full versioned save bundle from localStorage.
 * Falls back gracefully if JSON is corrupted, missing, or from an older version.
 */
export function loadVersionedSaveBundle(
  viewportWidth: number = 844,
  viewportHeight: number = 390
): VersionedGameSaveBundle | null {
  if (typeof window === 'undefined' || !window.localStorage) {
    return null;
  }

  try {
    const rawMaster = window.localStorage.getItem(MASTER_SAVE_STORAGE_KEY);
    if (rawMaster) {
      const parsed = JSON.parse(rawMaster);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        const obj = parsed as Record<string, unknown>;
        const progressSource =
          obj.progress && typeof obj.progress === 'object' ? obj.progress : obj;
        const progress = sanitizeSavedProgress(progressSource);
        const controlLayout = sanitizeControlLayout(
          obj.controlLayout,
          viewportWidth,
          viewportHeight
        );
        const settings = sanitizeSettings(obj.settings as Partial<GameSettings>);

        return {
          version: SAVE_SCHEMA_VERSION,
          updatedAt:
            typeof obj.updatedAt === 'number' && Number.isFinite(obj.updatedAt)
              ? obj.updatedAt
              : Date.now(),
          progress,
          controlLayout,
          settings,
        };
      }
    }

    // Fallback migration from individual v1 keys if present and valid
    const rawLegacyProgress = window.localStorage.getItem(LEGACY_SAVE_STORAGE_KEY);
    const rawControls = window.localStorage.getItem(CONTROL_LAYOUT_STORAGE_KEY);
    const rawSettings = window.localStorage.getItem(SETTINGS_STORAGE_KEY);

    if (!rawLegacyProgress && !rawControls && !rawSettings) {
      return null;
    }

    let progress = sanitizeSavedProgress(null);
    if (rawLegacyProgress) {
      try {
        progress = sanitizeSavedProgress(JSON.parse(rawLegacyProgress));
      } catch {
        progress = sanitizeSavedProgress(null);
      }
    }

    let controlLayout = cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
    if (rawControls) {
      try {
        controlLayout = sanitizeControlLayout(
          JSON.parse(rawControls),
          viewportWidth,
          viewportHeight
        );
      } catch {
        controlLayout = cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
      }
    }

    let settings = { ...DEFAULT_SETTINGS };
    if (rawSettings) {
      try {
        settings = sanitizeSettings(JSON.parse(rawSettings));
      } catch {
        settings = { ...DEFAULT_SETTINGS };
      }
    }

    return {
      version: SAVE_SCHEMA_VERSION,
      updatedAt: Date.now(),
      progress,
      controlLayout,
      settings,
    };
  } catch {
    return null;
  }
}

/**
 * Persists a partial or complete update into the versioned save bundle in localStorage,
 * keeping individual storage keys synchronized as well.
 */
export function writeVersionedSaveBundle(
  partial: {
    progress?: SavedGameProgress;
    controlLayout?: ControlLayoutMap;
    settings?: GameSettings;
  },
  viewportWidth: number = 844,
  viewportHeight: number = 390
): VersionedGameSaveBundle {
  const existing = loadVersionedSaveBundle(viewportWidth, viewportHeight);

  const progress = partial.progress
    ? sanitizeSavedProgress(partial.progress)
    : existing?.progress ?? sanitizeSavedProgress(null);

  const controlLayout = partial.controlLayout
    ? sanitizeControlLayout(partial.controlLayout, viewportWidth, viewportHeight)
    : existing?.controlLayout ?? cloneControlLayout(DEFAULT_CONTROL_LAYOUT);

  const settings = partial.settings
    ? sanitizeSettings(partial.settings)
    : existing?.settings ?? { ...DEFAULT_SETTINGS };

  const bundle: VersionedGameSaveBundle = {
    version: SAVE_SCHEMA_VERSION,
    updatedAt: Date.now(),
    progress,
    controlLayout,
    settings,
  };

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.setItem(MASTER_SAVE_STORAGE_KEY, JSON.stringify(bundle));
      window.localStorage.setItem(LEGACY_SAVE_STORAGE_KEY, JSON.stringify(progress));
      window.localStorage.setItem(CONTROL_LAYOUT_STORAGE_KEY, JSON.stringify(controlLayout));
      window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore quota / private browsing errors gracefully
    }
  }

  return bundle;
}
