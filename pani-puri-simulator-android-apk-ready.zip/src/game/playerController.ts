import { InputState } from '../types/game';

/**
 * Manages unified desktop (WASD/Arrows + Mouse PointerLock/Drag) and mobile
 * (Virtual Joystick + Touch-Look + Sprint/Jump buttons) inputs without triggering React re-renders.
 */
export class PlayerInputController {
  private keysHeld = new Set<string>();
  private jumpEdgeQueued = false;

  // Virtual mobile joystick state (-1..1)
  private joystickX = 0;
  private joystickZ = 0;

  // Virtual mobile buttons
  private mobileSprintHeld = false;
  private mobileJumpHeld = false;

  // Accumulated camera look deltas (radians)
  private lookDeltaX = 0;
  private lookDeltaY = 0;

  // Fallback desktop mouse-drag look when PointerLock is unavailable (e.g. headless browser / iframe restriction)
  private isMouseDragging = false;
  private lastMouseX = 0;
  private lastMouseY = 0;

  private sensitivity = 1.0;
  private invertY = false;
  private enabled = false;

  private onPauseRequest?: () => void;

  constructor(onPauseRequest?: () => void) {
    this.onPauseRequest = onPauseRequest;
  }

  public setConfig(sensitivity: number, invertY: boolean) {
    this.sensitivity = sensitivity;
    this.invertY = invertY;
  }

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (!enabled) {
      this.clearAllInputs();
    }
  }

  public clearAllInputs() {
    this.keysHeld.clear();
    this.jumpEdgeQueued = false;
    this.joystickX = 0;
    this.joystickZ = 0;
    this.mobileSprintHeld = false;
    this.mobileJumpHeld = false;
    this.lookDeltaX = 0;
    this.lookDeltaY = 0;
    this.isMouseDragging = false;
  }

  public setJoystickVector(x: number, z: number) {
    this.joystickX = Math.max(-1, Math.min(1, x));
    this.joystickZ = Math.max(-1, Math.min(1, z));
  }

  public setMobileSprint(held: boolean) {
    this.mobileSprintHeld = held;
  }

  public setMobileJump(held: boolean) {
    if (held && !this.mobileJumpHeld) {
      this.jumpEdgeQueued = true;
    }
    this.mobileJumpHeld = held;
  }

  public addTouchLookDelta(deltaPixelsX: number, deltaPixelsY: number) {
    if (!this.enabled) return;
    const radPerPixel = 0.0042 * this.sensitivity;
    const ySign = this.invertY ? -1 : 1;
    this.lookDeltaX += deltaPixelsX * radPerPixel;
    this.lookDeltaY += deltaPixelsY * radPerPixel * ySign;
  }

  public consumeFrameInput(): InputState {
    if (!this.enabled) {
      return {
        moveX: 0,
        moveZ: 0,
        sprintHeld: false,
        jumpHeld: false,
        jumpJustPressed: false,
        lookDeltaX: 0,
        lookDeltaY: 0,
      };
    }

    let kbX = 0;
    let kbZ = 0;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) kbZ += 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) kbZ -= 1;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) kbX += 1;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) kbX -= 1;

    const moveX = Math.max(-1, Math.min(1, kbX + this.joystickX));
    const moveZ = Math.max(-1, Math.min(1, kbZ + this.joystickZ));

    const kbSprint =
      this.keysHeld.has('ShiftLeft') ||
      this.keysHeld.has('ShiftRight');
    const kbJump = this.keysHeld.has('Space');

    const snapshot: InputState = {
      moveX,
      moveZ,
      sprintHeld: kbSprint || this.mobileSprintHeld,
      jumpHeld: kbJump || this.mobileJumpHeld,
      jumpJustPressed: this.jumpEdgeQueued,
      lookDeltaX: this.lookDeltaX,
      lookDeltaY: this.lookDeltaY,
    };

    this.jumpEdgeQueued = false;
    this.lookDeltaX = 0;
    this.lookDeltaY = 0;

    return snapshot;
  }

  public attachListeners(canvasElement: HTMLElement): () => void {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!this.enabled) return;

      if (e.code === 'Escape' || e.code === 'KeyP') {
        e.preventDefault();
        this.onPauseRequest?.();
        return;
      }

      if (
        e.code === 'KeyW' ||
        e.code === 'KeyA' ||
        e.code === 'KeyS' ||
        e.code === 'KeyD' ||
        e.code === 'ArrowUp' ||
        e.code === 'ArrowDown' ||
        e.code === 'ArrowLeft' ||
        e.code === 'ArrowRight' ||
        e.code === 'Space' ||
        e.code === 'ShiftLeft' ||
        e.code === 'ShiftRight'
      ) {
        e.preventDefault();
      }

      if (e.code === 'Space' && !this.keysHeld.has('Space')) {
        this.jumpEdgeQueued = true;
      }
      this.keysHeld.add(e.code);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      this.keysHeld.delete(e.code);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!this.enabled) return;
      const radPerPixel = 0.0026 * this.sensitivity;
      const ySign = this.invertY ? -1 : 1;

      if (document.pointerLockElement === canvasElement) {
        this.lookDeltaX += e.movementX * radPerPixel;
        this.lookDeltaY += e.movementY * radPerPixel * ySign;
      } else if (this.isMouseDragging) {
        const dx = e.clientX - this.lastMouseX;
        const dy = e.clientY - this.lastMouseY;
        this.lastMouseX = e.clientX;
        this.lastMouseY = e.clientY;
        this.lookDeltaX += dx * radPerPixel * 1.3;
        this.lookDeltaY += dy * radPerPixel * 1.3 * ySign;
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (!this.enabled || e.button !== 0) return;
      this.isMouseDragging = true;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
    };

    const handleMouseUp = () => {
      this.isMouseDragging = false;
    };

    const handleBlur = () => {
      this.clearAllInputs();
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        this.clearAllInputs();
      }
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('blur', handleBlur);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    canvasElement.addEventListener('mousedown', handleMouseDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('blur', handleBlur);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      canvasElement.removeEventListener('mousedown', handleMouseDown);
    };
  }
}
