export type ControlId =
  | 'joystick'
  | 'sprint'
  | 'jump'
  | 'pick_drop'
  | 'pour'
  | 'put_down';

export type ControlSizePresetId = 'small' | 'medium' | 'large' | 'extra_large';

export interface ControlSizePreset {
  id: ControlSizePresetId;
  label: string;
  shortLabel: string;
  scale: number; // 0.70, 1.00, 1.25, 1.50
  percent: number; // 70, 100, 125, 150
}

export const CONTROL_SIZE_PRESETS: ControlSizePreset[] = [
  { id: 'small', label: 'Small (70%)', shortLabel: 'Small', scale: 0.7, percent: 70 },
  { id: 'medium', label: 'Medium (100%)', shortLabel: 'Medium', scale: 1.0, percent: 100 },
  { id: 'large', label: 'Large (125%)', shortLabel: 'Large', scale: 1.25, percent: 125 },
  { id: 'extra_large', label: 'Extra Large (150%)', shortLabel: 'Extra Large', scale: 1.5, percent: 150 },
];

export const MIN_CONTROL_SCALE = 0.7;
export const MAX_CONTROL_SCALE = 1.5;
export const DEFAULT_CONTROL_SCALE = 1.0;

export interface ControlPlacement {
  /** Normalized horizontal center position (0..100% of viewport width) */
  xPercent: number;
  /** Normalized vertical center position (0..100% of viewport height) */
  yPercent: number;
  /** Size multiplier from 0.70 (70%) to 1.50 (150%), default 1.00 (100%) */
  scale: number;
}

export type ControlLayoutMap = Record<ControlId, ControlPlacement>;

export interface ControlMetadata {
  id: ControlId;
  label: string;
  shortLabel: string;
  /** Base unscaled width in CSS pixels */
  baseWidth: number;
  /** Base unscaled height in CSS pixels */
  baseHeight: number;
}

export const CONTROL_METADATA: Record<ControlId, ControlMetadata> = {
  joystick: {
    id: 'joystick',
    label: 'Joystick',
    shortLabel: 'Move',
    baseWidth: 112,
    baseHeight: 112,
  },
  sprint: {
    id: 'sprint',
    label: 'Sprint',
    shortLabel: 'Sprint',
    baseWidth: 64,
    baseHeight: 64,
  },
  jump: {
    id: 'jump',
    label: 'Jump',
    shortLabel: 'Jump',
    baseWidth: 68,
    baseHeight: 68,
  },
  pick_drop: {
    id: 'pick_drop',
    label: 'Pick/Drop',
    shortLabel: 'Pick/Drop',
    baseWidth: 72,
    baseHeight: 72,
  },
  pour: {
    id: 'pour',
    label: 'Pour',
    shortLabel: 'Pour',
    baseWidth: 72,
    baseHeight: 72,
  },
  put_down: {
    id: 'put_down',
    label: 'Interact / Put Down',
    shortLabel: 'Put Down',
    baseWidth: 60,
    baseHeight: 60,
  },
};

export const ALL_CONTROL_IDS: ControlId[] = [
  'joystick',
  'sprint',
  'pick_drop',
  'jump',
  'pour',
  'put_down',
];

export const CONTROL_LAYOUT_STORAGE_KEY = 'pani_puri_sim_3d_controls_v1';

/**
 * Default landscape control positions (normalized 0..100 percentages):
 * - Left side: Sprint above Virtual Joystick in bottom-left
 * - Right side: Put Down, Pick/Drop, and Jump stacked directly above Pour in bottom-right
 */
export const DEFAULT_CONTROL_LAYOUT: ControlLayoutMap = {
  joystick: { xPercent: 10.5, yPercent: 78.0, scale: DEFAULT_CONTROL_SCALE },
  sprint: { xPercent: 10.5, yPercent: 52.0, scale: DEFAULT_CONTROL_SCALE },
  put_down: { xPercent: 68.0, yPercent: 85.0, scale: DEFAULT_CONTROL_SCALE },
  pick_drop: { xPercent: 79.5, yPercent: 85.0, scale: DEFAULT_CONTROL_SCALE },
  jump: { xPercent: 91.0, yPercent: 64.5, scale: DEFAULT_CONTROL_SCALE },
  pour: { xPercent: 91.0, yPercent: 85.0, scale: DEFAULT_CONTROL_SCALE },
};

export function cloneControlLayout(layout: ControlLayoutMap): ControlLayoutMap {
  const next = {} as ControlLayoutMap;
  for (const id of ALL_CONTROL_IDS) {
    const src = layout[id] || DEFAULT_CONTROL_LAYOUT[id];
    next[id] = {
      xPercent: src.xPercent,
      yPercent: src.yPercent,
      scale: src.scale,
    };
  }
  return next;
}

export function sanitizeControlScale(rawScale: unknown): number {
  if (typeof rawScale !== 'number' || !Number.isFinite(rawScale)) {
    return DEFAULT_CONTROL_SCALE;
  }
  const clamped = Math.max(MIN_CONTROL_SCALE, Math.min(MAX_CONTROL_SCALE, rawScale));
  return Number(clamped.toFixed(2));
}

/**
 * Clamps a control's normalized center position so its scaled visual bounds remain
 * inside the usable screen area, respecting safe-area margins on landscape screens.
 */
export function clampControlPlacement(
  id: ControlId,
  placement: Partial<ControlPlacement> | null | undefined,
  viewportWidth: number = 844,
  viewportHeight: number = 390
): ControlPlacement {
  const fallback = DEFAULT_CONTROL_LAYOUT[id];
  const scale = sanitizeControlScale(placement?.scale ?? fallback.scale);

  const rawX =
    typeof placement?.xPercent === 'number' && Number.isFinite(placement.xPercent)
      ? placement.xPercent
      : fallback.xPercent;
  const rawY =
    typeof placement?.yPercent === 'number' && Number.isFinite(placement.yPercent)
      ? placement.yPercent
      : fallback.yPercent;

  const safeW = Math.max(320, viewportWidth);
  const safeH = Math.max(240, viewportHeight);
  const meta = CONTROL_METADATA[id];

  // Half-size in pixels plus a 10px safe-area edge cushion
  const halfWpx = (meta.baseWidth * scale) / 2 + 10;
  const halfHpx = (meta.baseHeight * scale) / 2 + 10;

  const minXPercent = Math.min(25, Math.max(4, (halfWpx / safeW) * 100));
  const maxXPercent = Math.max(75, Math.min(96, 100 - minXPercent));

  const minYPercent = Math.min(30, Math.max(8, (halfHpx / safeH) * 100));
  const maxYPercent = Math.max(70, Math.min(94, 100 - minYPercent));

  const xPercent = Number(
    Math.max(minXPercent, Math.min(maxXPercent, rawX)).toFixed(2)
  );
  const yPercent = Number(
    Math.max(minYPercent, Math.min(maxYPercent, rawY)).toFixed(2)
  );

  return {
    xPercent,
    yPercent,
    scale,
  };
}

export function sanitizeControlLayout(
  raw: unknown,
  viewportWidth: number = 844,
  viewportHeight: number = 390
): ControlLayoutMap {
  if (!raw || typeof raw !== 'object') {
    return cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
  }
  const record = raw as Partial<Record<ControlId, Partial<ControlPlacement>>>;
  const result = {} as ControlLayoutMap;
  for (const id of ALL_CONTROL_IDS) {
    result[id] = clampControlPlacement(id, record[id], viewportWidth, viewportHeight);
  }
  return result;
}

export function loadControlLayout(
  viewportWidth: number = 844,
  viewportHeight: number = 390
): ControlLayoutMap {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
    }
    const raw = window.localStorage.getItem(CONTROL_LAYOUT_STORAGE_KEY);
    if (!raw) {
      return cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
    }
    const parsed = JSON.parse(raw);
    return sanitizeControlLayout(parsed, viewportWidth, viewportHeight);
  } catch {
    return cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
  }
}

export function saveControlLayout(
  layout: ControlLayoutMap,
  viewportWidth: number = 844,
  viewportHeight: number = 390
): ControlLayoutMap {
  const clean = sanitizeControlLayout(layout, viewportWidth, viewportHeight);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(CONTROL_LAYOUT_STORAGE_KEY, JSON.stringify(clean));
    }
  } catch {
    // Ignore quota / private browsing errors gracefully
  }
  return clean;
}

export function resetSingleControlInLayout(
  layout: ControlLayoutMap,
  id: ControlId
): ControlLayoutMap {
  return {
    ...cloneControlLayout(layout),
    [id]: { ...DEFAULT_CONTROL_LAYOUT[id] },
  };
}

export function resetAllControlsInLayout(): ControlLayoutMap {
  return cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
}

export function getMatchingSizePreset(scale: number): ControlSizePresetId | 'custom' {
  for (const preset of CONTROL_SIZE_PRESETS) {
    if (Math.abs(preset.scale - scale) < 0.02) {
      return preset.id;
    }
  }
  return 'custom';
}

export interface ControlOverlapPair {
  firstId: ControlId;
  secondId: ControlId;
  firstLabel: string;
  secondLabel: string;
  overlapRatio: number;
}

/**
 * Detects if any two gameplay controls overlap significantly on screen.
 * Intentional overlap is allowed, but this returns overlapping pairs so the UI can warn the player.
 */
export function detectControlOverlaps(
  layout: ControlLayoutMap,
  viewportWidth: number = 844,
  viewportHeight: number = 390
): ControlOverlapPair[] {
  const overlaps: ControlOverlapPair[] = [];
  const safeW = Math.max(320, viewportWidth);
  const safeH = Math.max(240, viewportHeight);

  for (let i = 0; i < ALL_CONTROL_IDS.length; i++) {
    for (let j = i + 1; j < ALL_CONTROL_IDS.length; j++) {
      const idA = ALL_CONTROL_IDS[i];
      const idB = ALL_CONTROL_IDS[j];
      const posA = layout[idA];
      const posB = layout[idB];
      const metaA = CONTROL_METADATA[idA];
      const metaB = CONTROL_METADATA[idB];

      const ax = (posA.xPercent / 100) * safeW;
      const ay = (posA.yPercent / 100) * safeH;
      const aw = metaA.baseWidth * posA.scale;
      const ah = metaA.baseHeight * posA.scale;

      const bx = (posB.xPercent / 100) * safeW;
      const by = (posB.yPercent / 100) * safeH;
      const bw = metaB.baseWidth * posB.scale;
      const bh = metaB.baseHeight * posB.scale;

      const xOverlap = Math.max(
        0,
        Math.min(ax + aw / 2, bx + bw / 2) - Math.max(ax - aw / 2, bx - bw / 2)
      );
      const yOverlap = Math.max(
        0,
        Math.min(ay + ah / 2, by + bh / 2) - Math.max(ay - ah / 2, by - bh / 2)
      );

      if (xOverlap > 0 && yOverlap > 0) {
        const overlapArea = xOverlap * yOverlap;
        const smallerArea = Math.min(aw * ah, bw * bh);
        const ratio = smallerArea > 0 ? overlapArea / smallerArea : 0;
        if (ratio >= 0.18) {
          overlaps.push({
            firstId: idA,
            secondId: idB,
            firstLabel: metaA.label,
            secondLabel: metaB.label,
            overlapRatio: Number(ratio.toFixed(2)),
          });
        }
      }
    }
  }

  return overlaps;
}
