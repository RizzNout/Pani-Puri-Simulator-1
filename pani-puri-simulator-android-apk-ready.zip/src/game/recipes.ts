export type PourableIngredientId =
  | 'aloo'
  | 'sev'
  | 'curd'
  | 'jeera_jal'
  | 'sweet_chatni';

export type ContainerItemId = 'sukhi_puri' | PourableIngredientId;

export type HeldItemId = 'plate' | ContainerItemId;

export type InteractiveTargetId =
  | 'plate_stack'
  | 'prep_counter'
  | 'active_plate'
  | 'dropped_plate'
  | 'serving_area'
  | ContainerItemId;

export type RecipeId = 'sweet_puri' | 'pani_puri' | 'sev_puri';

export interface IngredientMetadata {
  id: PourableIngredientId;
  name: string;
  colorHex: number;
  uiColor: string;
}

export const POURABLE_INGREDIENTS: Record<PourableIngredientId, IngredientMetadata> = {
  aloo: {
    id: 'aloo',
    name: 'Aloo',
    colorHex: 0xfacc15,
    uiColor: '#facc15',
  },
  sev: {
    id: 'sev',
    name: 'Sev',
    colorHex: 0xf59e0b,
    uiColor: '#f59e0b',
  },
  curd: {
    id: 'curd',
    name: 'Curd',
    colorHex: 0xf8fafc,
    uiColor: '#f8fafc',
  },
  jeera_jal: {
    id: 'jeera_jal',
    name: 'Jeera Jal',
    colorHex: 0x22c55e,
    uiColor: '#4ade80',
  },
  sweet_chatni: {
    id: 'sweet_chatni',
    name: 'Sweet Chatni',
    colorHex: 0xb45309,
    uiColor: '#fb923c',
  },
};

export const ALL_POURABLE_IDS: PourableIngredientId[] = [
  'aloo',
  'sev',
  'curd',
  'jeera_jal',
  'sweet_chatni',
];

export const ITEM_DISPLAY_NAMES: Record<HeldItemId, string> = {
  plate: 'Plate',
  sukhi_puri: 'Sukhi Puri',
  aloo: 'Aloo',
  sev: 'Sev',
  curd: 'Curd',
  jeera_jal: 'Jeera Jal',
  sweet_chatni: 'Sweet Chatni',
};

export interface RecipeDefinition {
  id: RecipeId;
  name: string;
  shortTitle: string;
  requiredPuris: number;
  /**
   * Standardized internal quantity units where a full serving totals 100 units across required ingredients.
   */
  targetIngredients: Record<PourableIngredientId, number>;
}

export const REQUIRED_PURIS_PER_PLATE = 6;
export const INGREDIENT_TOLERANCE = 5;

/**
 * Configurable Recipe Definitions for Phase 2:
 * - Recipe A: Sweet Puri (6 Sukhi Puris, 25 Aloo, 50 Sweet Chatni, 15 Curd, 10 Sev => 100 total)
 * - Recipe B: Pani Puri  (6 Sukhi Puris, 50 Aloo, 50 Jeera Jal => 100 total)
 * - Recipe C: Sev Puri   (6 Sukhi Puris, 50 Aloo, 30 Sev, 20 Curd => 100 total)
 */
export const RECIPES: Record<RecipeId, RecipeDefinition> = {
  sweet_puri: {
    id: 'sweet_puri',
    name: 'Sweet Puri',
    shortTitle: 'SWEET PURI',
    requiredPuris: REQUIRED_PURIS_PER_PLATE,
    targetIngredients: {
      aloo: 25,
      sweet_chatni: 50,
      curd: 15,
      sev: 10,
      jeera_jal: 0,
    },
  },
  pani_puri: {
    id: 'pani_puri',
    name: 'Pani Puri',
    shortTitle: 'PANI PURI',
    requiredPuris: REQUIRED_PURIS_PER_PLATE,
    targetIngredients: {
      aloo: 50,
      jeera_jal: 50,
      sev: 0,
      curd: 0,
      sweet_chatni: 0,
    },
  },
  sev_puri: {
    id: 'sev_puri',
    name: 'Sev Puri',
    shortTitle: 'SEV PURI',
    requiredPuris: REQUIRED_PURIS_PER_PLATE,
    targetIngredients: {
      aloo: 50,
      sev: 30,
      curd: 20,
      jeera_jal: 0,
      sweet_chatni: 0,
    },
  },
};

export const RECIPE_LIST: RecipeDefinition[] = [
  RECIPES.sweet_puri,
  RECIPES.pani_puri,
  RECIPES.sev_puri,
];

export type PlatePrepStatus = 'empty' | 'in_progress' | 'ready' | 'completed';

export interface PlateState {
  id: string;
  puris: number; // 0 to 6
  ingredients: Record<PourableIngredientId, number>;
  status: PlatePrepStatus;
  finalAccuracy: number | null;
}

export interface RecipeAccuracyResult {
  accuracy: number; // 0 to 100
  isComplete: boolean;
  isWithinTolerance: boolean;
  missingPuris: number;
  missingIngredients: PourableIngredientId[];
  wrongIngredients: PourableIngredientId[];
  excessIngredients: PourableIngredientId[];
}

export function createEmptyPlate(id: string): PlateState {
  return {
    id,
    puris: 0,
    ingredients: {
      aloo: 0,
      sev: 0,
      curd: 0,
      jeera_jal: 0,
      sweet_chatni: 0,
    },
    status: 'empty',
    finalAccuracy: null,
  };
}

export function hasAnyPlateContents(plate: PlateState | null): boolean {
  if (!plate) return false;
  if (plate.puris > 0) return true;
  for (const id of ALL_POURABLE_IDS) {
    if (plate.ingredients[id] > 0) return true;
  }
  return false;
}

/**
 * Evaluates a plate's current ingredient quantities and puri count against the selected recipe.
 * Rules:
 * - Missing required ingredients reduce accuracy.
 * - Incorrect (non-recipe) ingredients reduce accuracy.
 * - Excessive quantities beyond tolerance reduce accuracy.
 * - Missing puris prevent completion and scale accuracy.
 * - A plate is complete only when it contains 6 puris and all required ingredients (> 0).
 * - Quantities within ±tolerance (default 5 units) of target qualify as 100% accurate for that ingredient.
 */
export function calculateRecipeAccuracy(
  plate: PlateState,
  recipeId: RecipeId,
  tolerance: number = INGREDIENT_TOLERANCE
): RecipeAccuracyResult {
  const recipe = RECIPES[recipeId];
  const missingPuris = Math.max(0, recipe.requiredPuris - plate.puris);
  const missingIngredients: PourableIngredientId[] = [];
  const wrongIngredients: PourableIngredientId[] = [];
  const excessIngredients: PourableIngredientId[] = [];

  let weightedIngredientScore = 0; // out of 100 (since required targets sum to 100)
  let wrongPenalty = 0;
  let allRequiredWithinTolerance = true;

  for (const ingId of ALL_POURABLE_IDS) {
    const target = recipe.targetIngredients[ingId];
    const actual = plate.ingredients[ingId] || 0;

    if (target > 0) {
      if (actual <= 0) {
        missingIngredients.push(ingId);
        allRequiredWithinTolerance = false;
      } else {
        const diff = Math.abs(actual - target);
        if (diff <= tolerance) {
          // Within allowed measurement tolerance => full points for this ingredient
          weightedIngredientScore += target;
        } else {
          allRequiredWithinTolerance = false;
          if (actual > target + tolerance) {
            excessIngredients.push(ingId);
          }
          const excessError = diff - tolerance;
          const ratio = Math.max(0, 1 - excessError / target);
          weightedIngredientScore += target * ratio;
        }
      }
    } else {
      // Non-recipe ingredient: penalize its presence
      if (actual > 0) {
        wrongIngredients.push(ingId);
        allRequiredWithinTolerance = false;
        wrongPenalty += Math.min(45, actual * 1.5);
      }
    }
  }

  const isComplete =
    plate.puris === recipe.requiredPuris && missingIngredients.length === 0;

  // Puris factor (6 puris required; missing puris reduce overall score)
  const puriRatio = Math.min(1, plate.puris / recipe.requiredPuris);

  // Combine ingredient score (75% weight) and puri completion (25% weight) minus wrong-ingredient penalty
  const rawScore =
    weightedIngredientScore * 0.75 + puriRatio * 25 - wrongPenalty;

  // If plate is completely empty, accuracy is 0
  const hasAnything = hasAnyPlateContents(plate);
  const clampedScore = hasAnything
    ? Math.max(0, Math.min(100, Math.round(rawScore)))
    : 0;

  const isWithinTolerance =
    isComplete && allRequiredWithinTolerance && wrongIngredients.length === 0;

  // If all 6 puris are placed, all required ingredients are within tolerance, and no wrong ingredients, accuracy is 100%
  const finalAccuracy = isWithinTolerance ? 100 : clampedScore;

  return {
    accuracy: finalAccuracy,
    isComplete,
    isWithinTolerance,
    missingPuris,
    missingIngredients,
    wrongIngredients,
    excessIngredients,
  };
}
