import { ColliderBox, InputState, PlayerState, PlayerTelemetry } from '../types/game';
import {
  INITIAL_PLAYER_SPAWN,
  PLAYER_RADIUS,
  STALL_POSITION,
  WORLD_COLLIDERS,
  WORLD_HALF_SIZE,
  getZoneName,
} from './worldData';

export const WALK_SPEED = 4.6;
export const SPRINT_SPEED = 7.8;
export const GRAVITY = 22.0;
export const JUMP_VELOCITY = 7.6;
export const COYOTE_TIME = 0.1;
export const JUMP_BUFFER_TIME = 0.12;
export const MAX_PITCH = Math.PI * 0.44; // ~79 degrees

export function createInitialPlayerState(): PlayerState {
  return {
    x: INITIAL_PLAYER_SPAWN.x,
    y: INITIAL_PLAYER_SPAWN.y,
    z: INITIAL_PLAYER_SPAWN.z,
    vx: 0,
    vy: 0,
    vz: 0,
    yaw: INITIAL_PLAYER_SPAWN.yaw,
    pitch: INITIAL_PLAYER_SPAWN.pitch,
    isGrounded: true,
    isSprinting: false,
    coyoteTimer: COYOTE_TIME,
    jumpBufferTimer: 0,
    walkCycle: 0,
  };
}

/**
 * Resolves 2D circle-vs-AABB collisions on the XZ plane so the player slides smoothly
 * along building walls and stall counters without getting stuck or passing through.
 */
export function resolveHorizontalCollisions(
  x: number,
  z: number,
  radius: number,
  colliders: ColliderBox[] = WORLD_COLLIDERS
): { x: number; z: number; collided: boolean } {
  let resolvedX = x;
  let resolvedZ = z;
  let collided = false;

  // Run 2 iterations for stable corner resolution
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < colliders.length; i++) {
      const box = colliders[i];
      const closestX = Math.max(box.minX, Math.min(resolvedX, box.maxX));
      const closestZ = Math.max(box.minZ, Math.min(resolvedZ, box.maxZ));

      const dx = resolvedX - closestX;
      const dz = resolvedZ - closestZ;
      const distSq = dx * dx + dz * dz;

      if (distSq < radius * radius) {
        collided = true;
        if (distSq > 1e-8) {
          const dist = Math.sqrt(distSq);
          const overlap = radius - dist;
          resolvedX += (dx / dist) * overlap;
          resolvedZ += (dz / dist) * overlap;
        } else {
          // Player center is inside the AABB: push out along the minimum penetration axis
          const leftPen = Math.abs(resolvedX - box.minX);
          const rightPen = Math.abs(box.maxX - resolvedX);
          const topPen = Math.abs(resolvedZ - box.minZ);
          const bottomPen = Math.abs(box.maxZ - resolvedZ);
          const minPen = Math.min(leftPen, rightPen, topPen, bottomPen);

          if (minPen === leftPen) {
            resolvedX = box.minX - radius;
          } else if (minPen === rightPen) {
            resolvedX = box.maxX + radius;
          } else if (minPen === topPen) {
            resolvedZ = box.minZ - radius;
          } else {
            resolvedZ = box.maxZ + radius;
          }
        }
      }
    }
  }

  // Clamp to visible world boundary
  const boundaryLimit = WORLD_HALF_SIZE - radius;
  if (resolvedX < -boundaryLimit) {
    resolvedX = -boundaryLimit;
    collided = true;
  } else if (resolvedX > boundaryLimit) {
    resolvedX = boundaryLimit;
    collided = true;
  }

  if (resolvedZ < -boundaryLimit) {
    resolvedZ = -boundaryLimit;
    collided = true;
  } else if (resolvedZ > boundaryLimit) {
    resolvedZ = boundaryLimit;
    collided = true;
  }

  return { x: resolvedX, z: resolvedZ, collided };
}

export interface StepResult {
  jumped: boolean;
  landed: boolean;
  footstepTriggered: boolean;
  collided: boolean;
}

/**
 * Pure simulation step for the first-person player controller.
 * Clamps dt to <= 0.05s to prevent tunneling on frame hiccups.
 */
export function stepPlayerPhysics(
  state: PlayerState,
  input: InputState,
  rawDt: number,
  colliders: ColliderBox[] = WORLD_COLLIDERS
): StepResult {
  const dt = Math.min(Math.max(rawDt, 0), 0.05);

  // 1. Update camera orientation
  state.yaw -= input.lookDeltaX;
  state.pitch = Math.max(-MAX_PITCH, Math.min(MAX_PITCH, state.pitch - input.lookDeltaY));

  // 2. Normalize movement input vector
  let moveX = input.moveX;
  let moveZ = input.moveZ;
  const moveLen = Math.hypot(moveX, moveZ);
  if (moveLen > 1) {
    moveX /= moveLen;
    moveZ /= moveLen;
  }

  const isMoving = moveLen > 0.05;
  state.isSprinting = Boolean(isMoving && input.sprintHeld);
  const targetSpeed = state.isSprinting ? SPRINT_SPEED : WALK_SPEED;

  // In Three.js right-handed coordinates:
  // yaw = 0 looks along -Z, right is +X.
  // Forward input (moveZ > 0) moves along (-sin(yaw), -cos(yaw))
  // Right input (moveX > 0) moves along (cos(yaw), -sin(yaw))
  const sinYaw = Math.sin(state.yaw);
  const cosYaw = Math.cos(state.yaw);

  const wishDirX = moveX * cosYaw - moveZ * sinYaw;
  const wishDirZ = -moveX * sinYaw - moveZ * cosYaw;

  const targetVx = wishDirX * targetSpeed;
  const targetVz = wishDirZ * targetSpeed;

  // Smooth exponential damping for responsive velocity transitions
  const accelLambda = state.isGrounded ? 16.0 : 7.0;
  const blend = 1 - Math.exp(-accelLambda * dt);
  state.vx += (targetVx - state.vx) * blend;
  state.vz += (targetVz - state.vz) * blend;

  if (!isMoving && Math.hypot(state.vx, state.vz) < 0.02) {
    state.vx = 0;
    state.vz = 0;
  }

  // 3. Horizontal movement & collision detection (sub-stepped if fast)
  const nextX = state.x + state.vx * dt;
  const nextZ = state.z + state.vz * dt;
  const resolved = resolveHorizontalCollisions(nextX, nextZ, PLAYER_RADIUS, colliders);
  const distMoved = Math.hypot(resolved.x - state.x, resolved.z - state.z);
  state.x = resolved.x;
  state.z = resolved.z;

  // 4. Jump buffering, coyote time & vertical gravity
  if (state.isGrounded) {
    state.coyoteTimer = COYOTE_TIME;
  } else {
    state.coyoteTimer = Math.max(0, state.coyoteTimer - dt);
  }

  if (input.jumpJustPressed) {
    state.jumpBufferTimer = JUMP_BUFFER_TIME;
  } else {
    state.jumpBufferTimer = Math.max(0, state.jumpBufferTimer - dt);
  }

  let jumped = false;
  if (state.jumpBufferTimer > 0 && state.coyoteTimer > 0) {
    state.vy = JUMP_VELOCITY;
    state.isGrounded = false;
    state.coyoteTimer = 0;
    state.jumpBufferTimer = 0;
    jumped = true;
  }

  // Variable jump height cut when releasing jump early while ascending
  if (!input.jumpHeld && state.vy > 0) {
    state.vy *= Math.pow(0.45, dt * 10);
  }

  const wasGrounded = state.isGrounded;
  state.vy -= GRAVITY * dt;
  state.y += state.vy * dt;

  let landed = false;
  if (state.y <= 0) {
    state.y = 0;
    if (!wasGrounded && state.vy < -1.5) {
      landed = true;
    }
    state.vy = 0;
    state.isGrounded = true;
  } else {
    state.isGrounded = false;
  }

  // 5. Walk cycle & footstep cadence synced to actual distance traveled
  let footstepTriggered = false;
  if (state.isGrounded && distMoved > 0.001) {
    const prevStepIndex = Math.floor(state.walkCycle / Math.PI);
    state.walkCycle += distMoved * (state.isSprinting ? 2.15 : 1.85);
    const nextStepIndex = Math.floor(state.walkCycle / Math.PI);
    if (nextStepIndex > prevStepIndex) {
      footstepTriggered = true;
    }
  } else if (state.isGrounded) {
    // Smoothly settle bob phase
    state.walkCycle = 0;
  }

  return {
    jumped,
    landed,
    footstepTriggered,
    collided: resolved.collided,
  };
}

export function getPlayerTelemetry(state: PlayerState): PlayerTelemetry {
  const dist = Math.hypot(state.x - STALL_POSITION.x, state.z - STALL_POSITION.z);
  return {
    x: Number(state.x.toFixed(1)),
    y: Number(state.y.toFixed(2)),
    z: Number(state.z.toFixed(1)),
    isSprinting: state.isSprinting,
    isGrounded: state.isGrounded,
    nearStall: dist <= 3.8,
    distanceToStall: Math.round(dist),
    zoneName: getZoneName(state.x, state.z),
  };
}
