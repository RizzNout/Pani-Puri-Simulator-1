import * as THREE from 'three';
import {
  CITY_BENCHES,
  CITY_BUILDINGS,
  CITY_TREES,
  STALL_COUNTER_DEPTH,
  STALL_COUNTER_WIDTH,
  STALL_POSITION,
  WORLD_HALF_SIZE,
  BuildingSpec,
} from './worldData';
import { createPbrTextureLibrary, PbrTextureLibrary } from './pbrMaterials';

/**
 * Helper to create a crisp procedural CanvasTexture with SRGBColorSpace and max anisotropy.
 */
function createCanvasTexture(
  width: number,
  height: number,
  drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    drawFn(ctx, width, height);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Creates a soft radial contact shadow texture for grounding 3D props.
 */
function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
    grad.addColorStop(0, 'rgba(15, 23, 42, 0.58)');
    grad.addColorStop(0.6, 'rgba(15, 23, 42, 0.24)');
    grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Creates a signboard texture with bold typography and festive Indian border motifs.
 */
function createSignTexture(
  text: string,
  subtext: string,
  bgColor: string,
  textColor: string,
  accentColor: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  return createCanvasTexture(
    512,
    160,
    (ctx, w, h) => {
      // Background
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, w, h);

      // Outer & inner decorative border
      ctx.strokeStyle = accentColor;
      ctx.lineWidth = 8;
      ctx.strokeRect(8, 8, w - 16, h - 16);

      ctx.strokeStyle = textColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(18, 18, w - 36, h - 36);

      // Corner diamond accents
      const corners = [
        [28, 28],
        [w - 28, 28],
        [28, h - 28],
        [w - 28, h - 28],
      ];
      ctx.fillStyle = accentColor;
      for (const [cx, cy] of corners) {
        ctx.beginPath();
        ctx.arc(cx, cy, 6, 0, Math.PI * 2);
        ctx.fill();
      }

      // Main Title
      ctx.fillStyle = textColor;
      ctx.font = '800 52px "Outfit", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, w / 2, subtext ? h * 0.41 : h * 0.5);

      if (subtext) {
        ctx.fillStyle = accentColor;
        ctx.font = '700 18px "Plus Jakarta Sans", system-ui, sans-serif';
        ctx.fillText(subtext, w / 2, h * 0.71);
      }
    },
    maxAnisotropy
  );
}

/**
 * Phase 5 — Builds the 1.5x Expanded Hero Central Pani Puri Stall as a medium-poly PBR centerpiece.
 * Features:
 * - Brushed stainless-steel 4.05m x 2.06m countertop with beveled edge rails & brass corner caps
 * - Teak wood-grain cart body accents & spoked wooden cart wheels (`woodMap` + `woodBump`)
 * - Accessible lower & side ingredient storage bay with woven jute burlap sacks (`burlapMap` + `burlapBump`) and hammered brass matkas (`hammeredMetalBump`)
 * - Woven fabric canopy stripes (`canopyFabricBump`) + decorative marigold garland & warm string lights
 */
function createPaniPuriStall(
  maxAnisotropy: number,
  pbr: PbrTextureLibrary,
  shadowTex: THREE.CanvasTexture,
  disposables: { geometries: THREE.BufferGeometry[]; materials: THREE.Material[]; textures: THREE.Texture[] }
): THREE.Group {
  const stallGroup = new THREE.Group();
  stallGroup.name = 'PaniPuriStall';
  stallGroup.position.set(STALL_POSITION.x, 0, STALL_POSITION.z);

  const cartBodyMat = new THREE.MeshStandardMaterial({
    color: 0xd97706, // Warm saffron lacquered wood/metal body
    bumpMap: pbr.woodBump,
    bumpScale: 0.006,
    roughness: 0.52,
    metalness: 0.14,
  });
  const cartTrimMat = new THREE.MeshStandardMaterial({
    color: 0x991b1b, // Deep crimson trim panels
    bumpMap: pbr.plasterBump,
    bumpScale: 0.004,
    roughness: 0.58,
    metalness: 0.12,
  });
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0, // Brushed stainless steel counter & shelves
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.2,
    metalness: 0.88,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.34,
    metalness: 0.76,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24, // Hammered & polished brass matkas & accents
    bumpMap: pbr.hammeredMetalBump,
    bumpScale: 0.008,
    roughness: 0.24,
    metalness: 0.86,
  });
  const woodWheelMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.woodMap,
    bumpMap: pbr.woodBump,
    bumpScale: 0.01,
    roughness: 0.74,
    metalness: 0.05,
  });
  const burlapMat = new THREE.MeshStandardMaterial({
    color: 0xffffff, // Woven jute/burlap ingredient storage sacks
    map: pbr.burlapMap,
    bumpMap: pbr.burlapBump,
    bumpScale: 0.016,
    roughness: 0.88,
    metalness: 0.02,
  });
  const canopyRedMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    bumpMap: pbr.canopyFabricBump,
    bumpScale: 0.008,
    roughness: 0.78,
    metalness: 0.04,
  });
  const canopyGoldMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    bumpMap: pbr.canopyFabricBump,
    bumpScale: 0.008,
    roughness: 0.76,
    metalness: 0.04,
  });

  disposables.materials.push(
    cartBodyMat,
    cartTrimMat,
    steelMat,
    darkSteelMat,
    brassMat,
    woodWheelMat,
    burlapMat,
    canopyRedMat,
    canopyGoldMat
  );

  // 0. Contact Shadow beneath the expanded 1.5x stall
  const shadowGeo = new THREE.PlaneGeometry(4.9, 3.1);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity: 0.68,
    depthWrite: false,
  });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.position.y = 0.02;
  stallGroup.add(shadowMesh);
  disposables.geometries.push(shadowGeo);
  disposables.materials.push(shadowMat);

  // 1. Expanded Main Counter Body (3.86m wide x 0.82m high x 1.78m deep)
  const bodyGeo = new THREE.BoxGeometry(3.86, 0.82, 1.78);
  const bodyMesh = new THREE.Mesh(bodyGeo, cartBodyMat);
  bodyMesh.position.set(0, 0.56, 0);
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  stallGroup.add(bodyMesh);

  // Decorative Front (-Z customer side) & Back (+Z vendor side) Crimson Panels + Brass Medallions
  const frontPanelGeo = new THREE.BoxGeometry(3.68, 0.58, 0.06);
  const customerFrontPanel = new THREE.Mesh(frontPanelGeo, cartTrimMat);
  customerFrontPanel.position.set(0, 0.56, -0.88);
  const vendorBackPanel = new THREE.Mesh(frontPanelGeo, cartTrimMat);
  vendorBackPanel.position.set(0, 0.56, 0.88);
  stallGroup.add(customerFrontPanel, vendorBackPanel);

  // Expanded Stainless Steel Countertop (4.05m wide x 2.06m deep — ~1.5x original dimensions)
  const counterTopGeo = new THREE.BoxGeometry(STALL_COUNTER_WIDTH, 0.08, STALL_COUNTER_DEPTH);
  const counterTop = new THREE.Mesh(counterTopGeo, steelMat);
  counterTop.position.set(0, 1.01, 0);
  counterTop.castShadow = true;
  counterTop.receiveShadow = true;
  stallGroup.add(counterTop);

  // Beveled Stainless-Steel Perimeter Edge Rails & Brass Corner Caps on Countertop
  const edgeRailFrontGeo = new THREE.CylinderGeometry(0.044, 0.044, STALL_COUNTER_WIDTH, 12);
  edgeRailFrontGeo.rotateZ(Math.PI / 2);
  const edgeRailSideGeo = new THREE.CylinderGeometry(0.044, 0.044, STALL_COUNTER_DEPTH, 12);
  edgeRailSideGeo.rotateX(Math.PI / 2);
  const cornerCapGeo = new THREE.SphereGeometry(0.052, 12, 10);
  disposables.geometries.push(edgeRailFrontGeo, edgeRailSideGeo, cornerCapGeo);

  const railVendor = new THREE.Mesh(edgeRailFrontGeo, steelMat);
  railVendor.position.set(0, 1.01, STALL_COUNTER_DEPTH / 2);
  const railCustomer = new THREE.Mesh(edgeRailFrontGeo, steelMat);
  railCustomer.position.set(0, 1.01, -STALL_COUNTER_DEPTH / 2);
  const railLeft = new THREE.Mesh(edgeRailSideGeo, steelMat);
  railLeft.position.set(-STALL_COUNTER_WIDTH / 2, 1.01, 0);
  const railRight = new THREE.Mesh(edgeRailSideGeo, steelMat);
  railRight.position.set(STALL_COUNTER_WIDTH / 2, 1.01, 0);
  stallGroup.add(railVendor, railCustomer, railLeft, railRight);

  for (const cx of [-STALL_COUNTER_WIDTH / 2, STALL_COUNTER_WIDTH / 2]) {
    for (const cz of [-STALL_COUNTER_DEPTH / 2, STALL_COUNTER_DEPTH / 2]) {
      const cap = new THREE.Mesh(cornerCapGeo, brassMat);
      cap.position.set(cx, 1.01, cz);
      stallGroup.add(cap);
    }
  }

  // Customer-Facing Serving Counter Ledge on the -Z side (accessible to customers in Slot 0)
  const customerServingLedgeGeo = new THREE.BoxGeometry(3.84, 0.05, 0.28);
  const customerServingLedge = new THREE.Mesh(customerServingLedgeGeo, brassMat);
  customerServingLedge.position.set(0, 0.96, -1.08);
  stallGroup.add(customerServingLedge);

  // Sneeze-guard / display rail along the customer edge
  const guardRailGeo = new THREE.BoxGeometry(3.88, 0.04, 0.04);
  const guardRail = new THREE.Mesh(guardRailGeo, steelMat);
  guardRail.position.set(0, 1.24, -0.92);
  stallGroup.add(guardRail);

  // Decorative Chaat Masala & Black Salt Shaker Jars on the left-front counter corner
  const jarGeo = new THREE.CylinderGeometry(0.048, 0.052, 0.14, 14);
  const jarCapGeo = new THREE.CylinderGeometry(0.042, 0.042, 0.03, 14);
  disposables.geometries.push(jarGeo, jarCapGeo);
  for (let j = 0; j < 2; j++) {
    const jar = new THREE.Mesh(jarGeo, j === 0 ? brassMat : steelMat);
    jar.position.set(-1.82 + j * 0.14, 1.12, 0.82);
    const jCap = new THREE.Mesh(jarCapGeo, cartTrimMat);
    jCap.position.set(-1.82 + j * 0.14, 1.20, 0.82);
    stallGroup.add(jar, jCap);
  }

  // 2. Accessible Ingredient Storage Area (Side Storage Rack & Vendor-Side Supply Bay)
  const storageRackGeo = new THREE.BoxGeometry(0.56, 0.72, 1.56);
  const leftStorageRack = new THREE.Mesh(storageRackGeo, darkSteelMat);
  leftStorageRack.position.set(-1.72, 0.52, 0);
  const rightStorageRack = new THREE.Mesh(storageRackGeo, darkSteelMat);
  rightStorageRack.position.set(1.72, 0.52, 0);
  stallGroup.add(leftStorageRack, rightStorageRack);

  // Reserve Ingredient Sacks & Spare Brass Matkas in the Storage Area
  const sackGeo = new THREE.SphereGeometry(0.18, 14, 10);
  sackGeo.scale(1.1, 0.85, 0.95);
  const spareMatkaGeo = new THREE.SphereGeometry(0.135, 16, 12);
  spareMatkaGeo.scale(1, 0.9, 1);

  for (const sx of [-1.78, 1.78]) {
    const sack1 = new THREE.Mesh(sackGeo, burlapMat);
    sack1.position.set(sx, 0.92, 0.38);
    const sack2 = new THREE.Mesh(sackGeo, burlapMat);
    sack2.position.set(sx, 0.92, -0.02);
    const sparePot = new THREE.Mesh(spareMatkaGeo, brassMat);
    sparePot.position.set(sx, 0.95, -0.42);
    stallGroup.add(sack1, sack2, sparePot);
  }

  disposables.geometries.push(
    bodyGeo,
    frontPanelGeo,
    counterTopGeo,
    customerServingLedgeGeo,
    guardRailGeo,
    storageRackGeo,
    sackGeo,
    spareMatkaGeo
  );

  // 3. Four Heavy-Duty Corner Cart Wheels with Brass Rim & Spokes across the expanded 4.05m stall base
  const wheelGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.09, 20);
  wheelGeo.rotateX(Math.PI / 2);
  const wheelTireGeo = new THREE.TorusGeometry(0.25, 0.022, 8, 20);
  const hubGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.13, 14);
  hubGeo.rotateX(Math.PI / 2);
  disposables.geometries.push(wheelGeo, wheelTireGeo, hubGeo);

  const wheelPositions = [
    [-1.58, 0.25, 0.92],
    [1.58, 0.25, 0.92],
    [-1.58, 0.25, -0.92],
    [1.58, 0.25, -0.92],
  ];
  for (const [wx, wy, wz] of wheelPositions) {
    const wheel = new THREE.Mesh(wheelGeo, woodWheelMat);
    wheel.position.set(wx, wy, wz);
    const tire = new THREE.Mesh(wheelTireGeo, darkSteelMat);
    tire.position.set(wx, wy, wz);
    const hub = new THREE.Mesh(hubGeo, brassMat);
    hub.position.set(wx, wy, wz);
    stallGroup.add(wheel, tire, hub);
  }

  // 4. Four Corner Vertical Support Poles & Overhead Truss Beams (keeps center prep view 100% clear!)
  const poleGeo = new THREE.CylinderGeometry(0.044, 0.044, 1.48, 12);
  const crossBeamGeo = new THREE.BoxGeometry(3.84, 0.055, 0.055);
  disposables.geometries.push(poleGeo, crossBeamGeo);
  const poleCoords = [
    [-1.88, 1.75, 0.88],
    [1.88, 1.75, 0.88],
    [-1.88, 1.75, -0.88],
    [1.88, 1.75, -0.88],
  ];
  for (const [px, py, pz] of poleCoords) {
    const pole = new THREE.Mesh(poleGeo, steelMat);
    pole.position.set(px, py, pz);
    stallGroup.add(pole);
  }
  const frontBeam = new THREE.Mesh(crossBeamGeo, steelMat);
  frontBeam.position.set(0, 2.42, 0.88);
  const backBeam = new THREE.Mesh(crossBeamGeo, steelMat);
  backBeam.position.set(0, 2.42, -0.88);
  stallGroup.add(frontBeam, backBeam);

  // Striped canopy segments (9 alternating festive red & gold fabric stripes across 4.34m)
  const stripeCount = 9;
  const canopyWidth = 4.34;
  const stripeWidth = canopyWidth / stripeCount;
  const stripeGeo = new THREE.BoxGeometry(stripeWidth, 0.14, 2.45);
  const valanceGeo = new THREE.BoxGeometry(stripeWidth * 0.94, 0.12, 0.06);
  disposables.geometries.push(stripeGeo, valanceGeo);
  for (let i = 0; i < stripeCount; i++) {
    const mat = i % 2 === 0 ? canopyRedMat : canopyGoldMat;
    const xPos = -canopyWidth / 2 + stripeWidth * (i + 0.5);
    const stripe = new THREE.Mesh(stripeGeo, mat);
    stripe.position.set(xPos, 2.52, 0);
    stripe.castShadow = true;
    // Scalloped front & back fabric valance flaps
    const valFront = new THREE.Mesh(valanceGeo, mat);
    valFront.position.set(xPos, 2.41, 1.21);
    const valBack = new THREE.Mesh(valanceGeo, mat);
    valBack.position.set(xPos, 2.41, -1.21);
    stallGroup.add(stripe, valFront, valBack);
  }

  // 5. Expanded "PANI PURI DARBAR" Signboard on top of the canopy (visible from both customer & vendor sides)
  const signTex = createSignTexture(
    'PANI PURI DARBAR',
    'FRESH GOLGAPPA · TIKHA & MEETHA PANI · SEV PURI',
    '#450a0a',
    '#fef08a',
    '#f59e0b',
    maxAnisotropy
  );
  disposables.textures.push(signTex);

  const signBoardGeo = new THREE.BoxGeometry(3.25, 0.64, 0.12);
  const signFaceMat = new THREE.MeshStandardMaterial({
    map: signTex,
    color: 0xffffff,
    roughness: 0.88,
    metalness: 0.02,
  });
  const signBorderMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    bumpMap: pbr.hammeredMetalBump,
    bumpScale: 0.005,
    roughness: 0.28,
    metalness: 0.82,
  });
  disposables.geometries.push(signBoardGeo);
  disposables.materials.push(signFaceMat, signBorderMat);

  const signMesh = new THREE.Mesh(signBoardGeo, [
    signBorderMat,
    signBorderMat,
    signBorderMat,
    signBorderMat,
    signFaceMat,
    signFaceMat,
  ]);
  signMesh.position.set(0, 2.92, 0);
  stallGroup.add(signMesh);

  // Warm decorative string light bulbs + Marigold Toran Garland along both front & back canopy edges
  const bulbGeo = new THREE.SphereGeometry(0.044, 10, 10);
  const bulbMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.5,
    roughness: 0.18,
  });
  const marigoldMat = new THREE.MeshStandardMaterial({
    color: 0xf97316,
    roughness: 0.72,
  });
  disposables.geometries.push(bulbGeo);
  disposables.materials.push(bulbMat, marigoldMat);
  for (let i = -5; i <= 5; i++) {
    const bulbFront = new THREE.Mesh(bulbGeo, bulbMat);
    bulbFront.position.set(i * 0.38, 2.42, 1.18);
    const bulbBack = new THREE.Mesh(bulbGeo, bulbMat);
    bulbBack.position.set(i * 0.38, 2.42, -1.18);
    stallGroup.add(bulbFront, bulbBack);

    if (i < 5) {
      const garlandFlower = new THREE.Mesh(bulbGeo, marigoldMat);
      garlandFlower.position.set((i + 0.5) * 0.38, 2.34, -0.88);
      garlandFlower.scale.setScalar(0.85);
      stallGroup.add(garlandFlower);
    }
  }

  // 6. Clearly Defined Customer Queue & Waiting Area on the -Z Customer Side (z = -1.55 relative to stall => z = -6.05 world)
  const customerZoneGeo = new THREE.PlaneGeometry(3.8, 1.25);
  customerZoneGeo.rotateX(-Math.PI / 2);
  const customerZoneTex = createCanvasTexture(
    384,
    128,
    (ctx, w, h) => {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 6;
      ctx.setLineDash([14, 8]);
      ctx.strokeRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = '#f8fafc';
      ctx.font = '700 22px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('CUSTOMER SERVING & QUEUE BAY', w / 2, h / 2);
    },
    maxAnisotropy
  );
  const customerZoneMat = new THREE.MeshStandardMaterial({
    map: customerZoneTex,
    roughness: 0.78,
    metalness: 0.05,
  });
  const customerZoneMesh = new THREE.Mesh(customerZoneGeo, customerZoneMat);
  customerZoneMesh.position.set(0.2, 0.025, -1.55);
  stallGroup.add(customerZoneMesh);

  // Vendor Standing Workspace Mat on the +Z Player Side (z = +1.48 relative to stall)
  const vendorZoneGeo = new THREE.PlaneGeometry(3.8, 1.15);
  vendorZoneGeo.rotateX(-Math.PI / 2);
  const vendorZoneTex = createCanvasTexture(
    384,
    128,
    (ctx, w, h) => {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 6;
      ctx.setLineDash([14, 8]);
      ctx.strokeRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = '#fef3c7';
      ctx.font = '700 20px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('VENDOR PREPARATION WORKSPACE', w / 2, h / 2);
    },
    maxAnisotropy
  );
  const vendorZoneMat = new THREE.MeshStandardMaterial({
    map: vendorZoneTex,
    roughness: 0.78,
    metalness: 0.05,
  });
  const vendorZoneMesh = new THREE.Mesh(vendorZoneGeo, vendorZoneMat);
  vendorZoneMesh.position.set(0, 0.025, 1.48);
  stallGroup.add(vendorZoneMesh);

  // Queue Lane Carpet Runner extending along Slots 1..4 on the -Z side
  const queueLaneGeo = new THREE.PlaneGeometry(1.15, 3.2);
  queueLaneGeo.rotateX(-Math.PI / 2);
  const queueLaneMat = new THREE.MeshStandardMaterial({
    color: 0x064e3b,
    bumpMap: pbr.canopyFabricBump,
    bumpScale: 0.008,
    roughness: 0.84,
  });
  const queueLaneMesh = new THREE.Mesh(queueLaneGeo, queueLaneMat);
  queueLaneMesh.position.set(0.15, 0.022, -3.75);
  stallGroup.add(queueLaneMesh);

  disposables.geometries.push(customerZoneGeo, vendorZoneGeo, queueLaneGeo);
  disposables.materials.push(customerZoneMat, vendorZoneMat, queueLaneMat);
  disposables.textures.push(customerZoneTex, vendorZoneTex);

  return stallGroup;
}

/**
 * Phase 5 — Builds a medium-poly Indian residential or commercial building with:
 * - Plaster/stucco bump mapping (`plasterBump`)
 * - Ground-level weathering plinth band & stone base
 * - Multi-pane architectural window facades (`windowFacadeMap`) with 3D recessed frames & chajja sunshades
 * - Ground-floor entrance door & storefront awning
 */
function createBuildingGroup(
  spec: BuildingSpec,
  maxAnisotropy: number,
  pbr: PbrTextureLibrary,
  disposables: { geometries: THREE.BufferGeometry[]; materials: THREE.Material[]; textures: THREE.Texture[] }
): THREE.Group {
  const group = new THREE.Group();
  group.position.set(spec.x, 0, spec.z);

  const wallMat = new THREE.MeshStandardMaterial({
    color: spec.primaryColor,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.012,
    roughness: spec.type === 'commercial' ? 0.52 : 0.78,
    metalness: spec.type === 'commercial' ? 0.16 : 0.04,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: spec.secondaryColor,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.008,
    roughness: 0.66,
    metalness: 0.06,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: spec.accentColor,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.01,
    roughness: 0.56,
    metalness: 0.12,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.windowFacadeMap,
    emissive: 0x1e293b,
    emissiveIntensity: 0.18,
    roughness: 0.14,
    metalness: 0.78,
  });
  const doorMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.woodMap,
    bumpMap: pbr.woodBump,
    bumpScale: 0.008,
    roughness: 0.62,
    metalness: 0.08,
  });

  disposables.materials.push(wallMat, trimMat, accentMat, glassMat, doorMat);

  // 1. Stone Plinth base + Ground-level weathering trim band
  const plinthGeo = new THREE.BoxGeometry(spec.width + 0.18, 0.36, spec.depth + 0.18);
  const plinth = new THREE.Mesh(plinthGeo, accentMat);
  plinth.position.y = 0.18;
  plinth.receiveShadow = true;
  group.add(plinth);

  const weatherBandGeo = new THREE.BoxGeometry(spec.width + 0.06, 0.65, spec.depth + 0.06);
  const weatherBand = new THREE.Mesh(weatherBandGeo, trimMat);
  weatherBand.position.y = 0.55;
  weatherBand.receiveShadow = true;
  group.add(weatherBand);

  // 2. Primary building tower
  const bodyGeo = new THREE.BoxGeometry(spec.width, spec.height, spec.depth);
  const body = new THREE.Mesh(bodyGeo, wallMat);
  body.position.y = spec.height / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  // 3. Roof parapet wall & cornice ledge
  const corniceGeo = new THREE.BoxGeometry(spec.width + 0.26, 0.28, spec.depth + 0.26);
  const cornice = new THREE.Mesh(corniceGeo, trimMat);
  cornice.position.y = spec.height + 0.14;
  group.add(cornice);

  const parapetRimGeo = new THREE.BoxGeometry(spec.width + 0.32, 0.12, spec.depth + 0.32);
  const parapetRim = new THREE.Mesh(parapetRimGeo, accentMat);
  parapetRim.position.y = spec.height + 0.32;
  group.add(parapetRim);

  // 4. Rooftop water tank or AC unit (authentic Indian urban skyline detail)
  const tankGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.9, 14);
  const tankMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.38,
    metalness: 0.35,
  });
  const tank = new THREE.Mesh(tankGeo, tankMat);
  tank.position.set(spec.width * 0.22, spec.height + 0.72, -spec.depth * 0.2);
  group.add(tank);

  disposables.geometries.push(plinthGeo, weatherBandGeo, bodyGeo, corniceGeo, parapetRimGeo, tankGeo);
  disposables.materials.push(tankMat);

  // 5. Floor ledges, window bands with mullions & chajja sunshade overhangs
  const floorHeight = spec.height / (spec.floors + 0.4);
  const bandGeo = new THREE.BoxGeometry(spec.width + 0.1, 0.14, spec.depth + 0.1);
  const winBandGeo = new THREE.BoxGeometry(spec.width * 0.78, floorHeight * 0.44, spec.depth + 0.06);
  const winBandCrossGeo = new THREE.BoxGeometry(spec.width + 0.06, floorHeight * 0.44, spec.depth * 0.78);
  const chajjaNSGeo = new THREE.BoxGeometry(spec.width * 0.84, 0.08, spec.depth + 0.24);
  const chajjaEWGeo = new THREE.BoxGeometry(spec.width + 0.24, 0.08, spec.depth * 0.84);
  disposables.geometries.push(bandGeo, winBandGeo, winBandCrossGeo, chajjaNSGeo, chajjaEWGeo);

  for (let f = 1; f <= spec.floors; f++) {
    const y = f * floorHeight;

    // Horizontal floor slab trim
    const slab = new THREE.Mesh(bandGeo, trimMat);
    slab.position.y = y - floorHeight * 0.35;
    group.add(slab);

    // Windows on all 4 sides with multi-pane facade texture
    const winNS = new THREE.Mesh(winBandGeo, glassMat);
    winNS.position.y = y;
    group.add(winNS);

    const winEW = new THREE.Mesh(winBandCrossGeo, glassMat);
    winEW.position.y = y;
    group.add(winEW);

    // Architectural sunshade (chajja) ledge above each window row
    const chajjaNS = new THREE.Mesh(chajjaNSGeo, trimMat);
    chajjaNS.position.y = y + floorHeight * 0.25;
    const chajjaEW = new THREE.Mesh(chajjaEWGeo, trimMat);
    chajjaEW.position.y = y + floorHeight * 0.25;
    group.add(chajjaNS, chajjaEW);
  }

  // 6. Ground-floor storefront awning + recessed wooden entrance door
  const awningGeo = new THREE.BoxGeometry(spec.width * 0.72, 0.18, 0.56);
  const doorGeo = new THREE.BoxGeometry(Math.min(1.3, spec.width * 0.36), 1.85, 0.08);
  const faceTowardCenterZ = spec.z < 0 ? 1 : -1;
  const awning = new THREE.Mesh(awningGeo, accentMat);
  awning.position.set(0, 2.12, faceTowardCenterZ * (spec.depth / 2 + 0.22));
  const door = new THREE.Mesh(doorGeo, doorMat);
  door.position.set(0, 1.05, faceTowardCenterZ * (spec.depth / 2 + 0.02));
  group.add(awning, door);
  disposables.geometries.push(awningGeo, doorGeo);

  // Optional Commercial Signboard
  if (spec.signText) {
    const signTex = createSignTexture(
      spec.signText,
      '',
      '#0f172a',
      '#f8fafc',
      '#38bdf8',
      maxAnisotropy
    );
    const signGeo = new THREE.BoxGeometry(spec.width * 0.76, 0.52, 0.08);
    const signMat = new THREE.MeshStandardMaterial({
      map: signTex,
      roughness: 0.35,
      metalness: 0.1,
    });
    const sign = new THREE.Mesh(signGeo, signMat);
    sign.position.set(0, 2.55, faceTowardCenterZ * (spec.depth / 2 + 0.06));
    if (faceTowardCenterZ < 0) {
      sign.rotation.y = Math.PI;
    }
    group.add(sign);
    disposables.geometries.push(signGeo);
    disposables.materials.push(signMat);
    disposables.textures.push(signTex);
  }

  return group;
}

export interface BuiltCityWorld {
  worldGroup: THREE.Group;
  dispose: () => void;
}

/**
 * Constructs the expanded 60x60 (72m x 72m) 3D Indian city environment, extended main roads,
 * inner & outer ring streets, raised curbs, crosswalks, 3 parks, 28 trees, streetlights, 10 benches,
 * perimeter boundary, and the 1.5x expanded central Pani Puri stall with Phase 5 PBR materials.
 */
export function buildCityWorld(renderer: THREE.WebGLRenderer): BuiltCityWorld {
  const worldGroup = new THREE.Group();
  const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());

  const disposables: {
    geometries: THREE.BufferGeometry[];
    materials: THREE.Material[];
    textures: THREE.Texture[];
  } = {
    geometries: [],
    materials: [],
    textures: [],
  };

  // Shared PBR Texture Library for roads, sidewalks, plaza tiles, buildings, trees & stall
  const pbr = createPbrTextureLibrary(maxAnisotropy, disposables.textures);
  const shadowTex = createContactShadowTexture();
  disposables.textures.push(shadowTex);

  // 1. Extended Outer Terrain (so the 72m x 72m city block sits naturally in a wide landscape)
  const outerGroundGeo = new THREE.PlaneGeometry(260, 260);
  outerGroundGeo.rotateX(-Math.PI / 2);
  const outerGroundMat = new THREE.MeshStandardMaterial({
    color: 0xd6d0c4,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.015,
    roughness: 0.92,
    metalness: 0.02,
  });
  const outerGround = new THREE.Mesh(outerGroundGeo, outerGroundMat);
  outerGround.position.y = -0.04;
  outerGround.receiveShadow = true;
  worldGroup.add(outerGround);

  // 2. Playable 60x60 (72m x 72m) City Sidewalk Paving Base (y = 0.0) with Concrete Slab Joints
  const sidewalkGeo = new THREE.PlaneGeometry(WORLD_HALF_SIZE * 2, WORLD_HALF_SIZE * 2);
  sidewalkGeo.rotateX(-Math.PI / 2);
  const sidewalkMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.sidewalkMap,
    bumpMap: pbr.sidewalkBump,
    bumpScale: 0.014,
    roughness: 0.8,
    metalness: 0.03,
  });
  const sidewalkBase = new THREE.Mesh(sidewalkGeo, sidewalkMat);
  sidewalkBase.position.y = 0.0;
  sidewalkBase.receiveShadow = true;
  worldGroup.add(sidewalkBase);

  disposables.geometries.push(outerGroundGeo, sidewalkGeo);
  disposables.materials.push(outerGroundMat, sidewalkMat);

  // 3. Asphalt Roads with Aggregate Grain & Bump (2 Main Avenues + 4 Inner Ring + 4 Outer Ring Boulevards)
  const roadMat = new THREE.MeshStandardMaterial({
    map: pbr.asphaltMap,
    bumpMap: pbr.asphaltBump,
    bumpScale: 0.018,
    color: 0xffffff,
    roughness: 0.84,
    metalness: 0.05,
  });
  const curbStoneMat = new THREE.MeshStandardMaterial({
    color: 0xcbd5e1,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.01,
    roughness: 0.74,
    metalness: 0.04,
  });
  disposables.materials.push(roadMat, curbStoneMat);

  const mainRoadWidth = 5.2; // x or z in [-2.6, 2.6]
  const innerStreetWidth = 2.6; // centered at ±10.0m
  const outerStreetWidth = 2.8; // centered at ±22.0m

  const roadDefs = [
    // Main North-South Avenue (MG Road)
    { w: mainRoadWidth, d: WORLD_HALF_SIZE * 2, x: 0, z: 0, y: 0.015 },
    // Main East-West Avenue (Bazaar Main Street)
    { w: WORLD_HALF_SIZE * 2, d: mainRoadWidth, x: 0, z: 0, y: 0.017 },
    // Inner Ring West & East Side Streets (x = ±10.0m)
    { w: innerStreetWidth, d: WORLD_HALF_SIZE * 2, x: -10.0, z: 0, y: 0.014 },
    { w: innerStreetWidth, d: WORLD_HALF_SIZE * 2, x: 10.0, z: 0, y: 0.014 },
    // Inner Ring North & South Side Streets (z = ±10.0m)
    { w: WORLD_HALF_SIZE * 2, d: innerStreetWidth, x: 0, z: -10.0, y: 0.016 },
    { w: WORLD_HALF_SIZE * 2, d: innerStreetWidth, x: 0, z: 10.0, y: 0.016 },
    // Outer Ring West & East Boulevards (x = ±22.0m)
    { w: outerStreetWidth, d: WORLD_HALF_SIZE * 2, x: -22.0, z: 0, y: 0.013 },
    { w: outerStreetWidth, d: WORLD_HALF_SIZE * 2, x: 22.0, z: 0, y: 0.013 },
    // Outer Ring North & South Boulevards (z = ±22.0m)
    { w: WORLD_HALF_SIZE * 2, d: outerStreetWidth, x: 0, z: -22.0, y: 0.015 },
    { w: WORLD_HALF_SIZE * 2, d: outerStreetWidth, x: 0, z: 22.0, y: 0.015 },
  ];

  for (const r of roadDefs) {
    const rGeo = new THREE.PlaneGeometry(r.w, r.d);
    rGeo.rotateX(-Math.PI / 2);
    const rMesh = new THREE.Mesh(rGeo, roadMat);
    rMesh.position.set(r.x, r.y, r.z);
    rMesh.receiveShadow = true;
    worldGroup.add(rMesh);
    disposables.geometries.push(rGeo);
  }

  // Raised Stone Road Curbs along Main Avenue Sidewalk Edges (between intersections)
  const curbSegments = [
    { start: -34.5, end: -23.6 },
    { start: -20.4, end: -11.5 },
    { start: -8.5, end: -3.6 },
    { start: 3.6, end: 8.5 },
    { start: 11.5, end: 20.4 },
    { start: 23.6, end: 34.5 },
  ];
  for (const seg of curbSegments) {
    const len = seg.end - seg.start;
    const mid = (seg.start + seg.end) / 2;
    const curbNSGeo = new THREE.BoxGeometry(0.18, 0.055, len);
    const curbEWGeo = new THREE.BoxGeometry(len, 0.055, 0.18);
    disposables.geometries.push(curbNSGeo, curbEWGeo);

    for (const side of [-2.68, 2.68]) {
      const cNS = new THREE.Mesh(curbNSGeo, curbStoneMat);
      cNS.position.set(side, 0.028, mid);
      const cEW = new THREE.Mesh(curbEWGeo, curbStoneMat);
      cEW.position.set(mid, 0.028, side);
      worldGroup.add(cNS, cEW);
    }
  }

  // 4. Road Markings & Zebra Pedestrian Crossings across the 72m x 72m city (y = 0.028)
  const stripeWhiteMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    bumpMap: pbr.asphaltBump,
    bumpScale: 0.008,
    roughness: 0.65,
    metalness: 0.04,
  });
  const stripeYellowMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    bumpMap: pbr.asphaltBump,
    bumpScale: 0.008,
    roughness: 0.65,
    metalness: 0.04,
  });
  disposables.materials.push(stripeWhiteMat, stripeYellowMat);

  const dashNSGeo = new THREE.PlaneGeometry(0.16, 1.4);
  dashNSGeo.rotateX(-Math.PI / 2);
  const dashEWGeo = new THREE.PlaneGeometry(1.4, 0.16);
  dashEWGeo.rotateX(-Math.PI / 2);
  disposables.geometries.push(dashNSGeo, dashEWGeo);

  for (let pos = -34.0; pos <= 34.0; pos += 2.8) {
    if (
      Math.abs(pos) < 3.8 ||
      Math.abs(Math.abs(pos) - 10.0) < 1.8 ||
      Math.abs(Math.abs(pos) - 22.0) < 1.9
    ) {
      continue;
    }
    const dNS = new THREE.Mesh(dashNSGeo, stripeYellowMat);
    dNS.position.set(0, 0.028, pos);
    worldGroup.add(dNS);

    const dEW = new THREE.Mesh(dashEWGeo, stripeYellowMat);
    dEW.position.set(pos, 0.028, 0);
    worldGroup.add(dEW);
  }

  // Zebra Crossings at Central Intersection & Inner Ring Crossings
  const zebraBarNS = new THREE.PlaneGeometry(0.32, 1.2);
  zebraBarNS.rotateX(-Math.PI / 2);
  const zebraBarEW = new THREE.PlaneGeometry(1.2, 0.32);
  zebraBarEW.rotateX(-Math.PI / 2);
  disposables.geometries.push(zebraBarNS, zebraBarEW);

  for (let offset = -1.8; offset <= 1.8; offset += 0.6) {
    // Central Chowk crosswalks
    const zN = new THREE.Mesh(zebraBarNS, stripeWhiteMat);
    zN.position.set(offset, 0.029, -3.3);
    const zS = new THREE.Mesh(zebraBarNS, stripeWhiteMat);
    zS.position.set(offset, 0.029, 3.3);
    const zE = new THREE.Mesh(zebraBarEW, stripeWhiteMat);
    zE.position.set(3.3, 0.029, offset);
    const zW = new THREE.Mesh(zebraBarEW, stripeWhiteMat);
    zW.position.set(-3.3, 0.029, offset);
    worldGroup.add(zN, zS, zE, zW);
  }

  // 5. Three Green City Parks with Botanical Grass Texture & Flowering Shrubs
  const grassGeo = new THREE.BoxGeometry(5.2, 0.08, 5.2);
  const parkBorderGeo = new THREE.BoxGeometry(5.38, 0.11, 5.38);
  const grassMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.grassMap,
    bumpMap: pbr.grassBump,
    bumpScale: 0.02,
    roughness: 0.88,
    metalness: 0.02,
  });
  const flowerbedRingGeo = new THREE.CylinderGeometry(0.88, 0.94, 0.24, 20);
  const flowerbedSoilGeo = new THREE.CylinderGeometry(0.75, 0.75, 0.28, 20);
  const flowerGeo = new THREE.DodecahedronGeometry(0.36, 1);
  const shrubGeo = new THREE.SphereGeometry(0.28, 10, 8);
  shrubGeo.scale(1.2, 0.75, 1.2);
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0xa8a29e,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.012,
    roughness: 0.76,
  });
  const blossomMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.58 });
  const shrubMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8 });
  disposables.geometries.push(
    grassGeo,
    parkBorderGeo,
    flowerbedRingGeo,
    flowerbedSoilGeo,
    flowerGeo,
    shrubGeo
  );
  disposables.materials.push(grassMat, stoneMat, blossomMat, shrubMat);

  const parkCenters = [
    { x: 5.6, z: 5.6 }, // Central Green City Park
    { x: -28.5, z: 5.6 }, // West Sunset Park
    { x: -15.8, z: 28.5 }, // South Garden Promenade
  ];

  for (const pc of parkCenters) {
    const pGroup = new THREE.Group();
    pGroup.position.set(pc.x, 0, pc.z);

    const borderMesh = new THREE.Mesh(parkBorderGeo, stoneMat);
    borderMesh.position.y = 0.03;

    const grassMesh = new THREE.Mesh(grassGeo, grassMat);
    grassMesh.position.y = 0.055;
    grassMesh.receiveShadow = true;

    const bedRing = new THREE.Mesh(flowerbedRingGeo, stoneMat);
    bedRing.position.y = 0.16;
    const bedSoil = new THREE.Mesh(flowerbedSoilGeo, grassMat);
    bedSoil.position.y = 0.18;
    const blossom = new THREE.Mesh(flowerGeo, blossomMat);
    blossom.position.y = 0.44;

    pGroup.add(borderMesh, grassMesh, bedRing, bedSoil, blossom);

    // Corner ornamental garden shrubs
    for (const [sx, sz] of [
      [-1.95, -1.95],
      [1.95, -1.95],
      [-1.95, 1.95],
      [1.95, 1.95],
    ]) {
      const shrub = new THREE.Mesh(shrubGeo, shrubMat);
      shrub.position.set(sx, 0.22, sz);
      pGroup.add(shrub);
    }

    worldGroup.add(pGroup);
  }

  // 6. Expanded Central Pani Puri Stall Sandstone Plaza Tile Apron (6.1m x 6.4m in NE Inner Block)
  const plazaGeo = new THREE.BoxGeometry(6.1, 0.036, 6.4);
  const plazaMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.plazaTileMap,
    bumpMap: pbr.plazaTileBump,
    bumpScale: 0.015,
    roughness: 0.68,
    metalness: 0.04,
  });
  const plazaMesh = new THREE.Mesh(plazaGeo, plazaMat);
  plazaMesh.position.set(5.45, 0.008, -5.5);
  plazaMesh.receiveShadow = true;
  worldGroup.add(plazaMesh);
  disposables.geometries.push(plazaGeo);
  disposables.materials.push(plazaMat);

  // 7. Add the 1.5x Expanded Hero Central Pani Puri Stall
  const paniPuriStall = createPaniPuriStall(maxAnisotropy, pbr, shadowTex, disposables);
  worldGroup.add(paniPuriStall);

  // 8. Add all 30 Residential & Commercial Buildings across Inner, Mid, and Outer City Districts
  for (const bSpec of CITY_BUILDINGS) {
    const bGroup = createBuildingGroup(bSpec, maxAnisotropy, pbr, disposables);
    worldGroup.add(bGroup);
  }

  // 9. Add Medium-Poly Trees (Textured Bark Trunk + 3 Smooth Layered Foliage Canopies + Contact Shadow)
  const trunkGeo = new THREE.CylinderGeometry(0.15, 0.25, 1.55, 10);
  const foliageGeo1 = new THREE.IcosahedronGeometry(0.96, 2);
  const foliageGeo2 = new THREE.IcosahedronGeometry(0.74, 2);
  const foliageGeo3 = new THREE.IcosahedronGeometry(0.56, 2);
  const treeShadowGeo = new THREE.PlaneGeometry(2.0, 2.0);
  treeShadowGeo.rotateX(-Math.PI / 2);

  const trunkMat = new THREE.MeshStandardMaterial({
    color: 0x6b3410,
    bumpMap: pbr.woodBump,
    bumpScale: 0.02,
    roughness: 0.88,
  });
  const leafMat1 = new THREE.MeshStandardMaterial({
    color: 0x166534,
    bumpMap: pbr.grassBump,
    bumpScale: 0.012,
    roughness: 0.76,
  });
  const leafMat2 = new THREE.MeshStandardMaterial({
    color: 0x15803d,
    bumpMap: pbr.grassBump,
    bumpScale: 0.012,
    roughness: 0.72,
  });
  const leafMat3 = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    roughness: 0.68,
  });
  const treeShadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity: 0.48,
    depthWrite: false,
  });

  disposables.geometries.push(trunkGeo, foliageGeo1, foliageGeo2, foliageGeo3, treeShadowGeo);
  disposables.materials.push(trunkMat, leafMat1, leafMat2, leafMat3, treeShadowMat);

  for (const tSpec of CITY_TREES) {
    const tree = new THREE.Group();
    tree.position.set(tSpec.x, 0, tSpec.z);
    tree.scale.setScalar(tSpec.scale);

    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = 0.76;
    trunk.castShadow = true;

    const c1 = new THREE.Mesh(foliageGeo1, leafMat1);
    c1.position.set(0, 1.88, 0);
    c1.scale.set(1.06, 0.88, 1.06);
    c1.castShadow = true;

    const c2 = new THREE.Mesh(foliageGeo2, leafMat2);
    c2.position.set(0.32, 2.36, 0.18);

    const c3 = new THREE.Mesh(foliageGeo3, leafMat3);
    c3.position.set(-0.28, 2.5, -0.2);

    const tShadow = new THREE.Mesh(treeShadowGeo, treeShadowMat);
    tShadow.position.y = 0.022;

    tree.add(trunk, c1, c2, c3, tShadow);
    worldGroup.add(tree);
  }

  // 10. Park & Plaza Benches (Teak wood-grain slats & cast-iron legs/armrests)
  const benchSeatGeo = new THREE.BoxGeometry(1.42, 0.08, 0.48);
  const benchBackGeo = new THREE.BoxGeometry(1.42, 0.42, 0.07);
  const benchLegGeo = new THREE.BoxGeometry(0.1, 0.44, 0.48);
  const benchWoodMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: pbr.woodMap,
    bumpMap: pbr.woodBump,
    bumpScale: 0.008,
    roughness: 0.65,
  });
  const benchIronMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.36,
    metalness: 0.75,
  });
  disposables.geometries.push(benchSeatGeo, benchBackGeo, benchLegGeo);
  disposables.materials.push(benchWoodMat, benchIronMat);

  for (const b of CITY_BENCHES) {
    const bGroup = new THREE.Group();
    bGroup.position.set(b.x, 0, b.z);
    bGroup.rotation.y = b.rotationY;

    const seat = new THREE.Mesh(benchSeatGeo, benchWoodMat);
    seat.position.set(0, 0.44, 0);
    const back = new THREE.Mesh(benchBackGeo, benchWoodMat);
    back.position.set(0, 0.68, -0.2);
    const legL = new THREE.Mesh(benchLegGeo, benchIronMat);
    legL.position.set(-0.56, 0.22, 0);
    const legR = new THREE.Mesh(benchLegGeo, benchIronMat);
    legR.position.set(0.56, 0.22, 0);

    bGroup.add(seat, back, legL, legR);
    worldGroup.add(bGroup);
  }

  // 11. Streetlights along the Main Intersection, Inner Ring, and Outer Ring Boulevards
  const lampPostGeo = new THREE.CylinderGeometry(0.05, 0.085, 3.8, 10);
  const lampBaseGeo = new THREE.CylinderGeometry(0.14, 0.18, 0.35, 10);
  const lampArmGeo = new THREE.BoxGeometry(0.72, 0.06, 0.06);
  const lampHeadGeo = new THREE.BoxGeometry(0.3, 0.1, 0.2);
  const lampMetalMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    bumpMap: pbr.brushedSteelBump,
    bumpScale: 0.004,
    roughness: 0.32,
    metalness: 0.78,
  });
  const lampGlowMat = new THREE.MeshStandardMaterial({
    color: 0xfef9c3,
    emissive: 0xfde047,
    emissiveIntensity: 1.35,
    roughness: 0.18,
  });
  disposables.geometries.push(lampPostGeo, lampBaseGeo, lampArmGeo, lampHeadGeo);
  disposables.materials.push(lampMetalMat, lampGlowMat);

  const lampCoords = [
    { x: -2.9, z: -2.9, rot: Math.PI / 4 },
    { x: 2.8, z: -8.2, rot: Math.PI },
    { x: -2.9, z: 2.9, rot: (3 * Math.PI) / 4 },
    { x: 2.9, z: 2.9, rot: -(3 * Math.PI) / 4 },
    { x: -2.9, z: -11.8, rot: 0 },
    { x: 2.9, z: 11.8, rot: Math.PI },
    { x: -11.8, z: -2.9, rot: Math.PI / 2 },
    { x: 11.8, z: 2.9, rot: -Math.PI / 2 },
    { x: -2.9, z: -23.8, rot: 0 },
    { x: 2.9, z: -23.8, rot: Math.PI },
    { x: -2.9, z: 23.8, rot: 0 },
    { x: 2.9, z: 23.8, rot: Math.PI },
    { x: -23.8, z: -2.9, rot: Math.PI / 2 },
    { x: 23.8, z: 2.9, rot: -Math.PI / 2 },
  ];
  for (const lc of lampCoords) {
    const lGroup = new THREE.Group();
    lGroup.position.set(lc.x, 0, lc.z);
    lGroup.rotation.y = lc.rot;

    const base = new THREE.Mesh(lampBaseGeo, lampMetalMat);
    base.position.y = 0.175;
    const post = new THREE.Mesh(lampPostGeo, lampMetalMat);
    post.position.y = 1.9;
    const arm = new THREE.Mesh(lampArmGeo, lampMetalMat);
    arm.position.set(0.3, 3.75, 0);
    const head = new THREE.Mesh(lampHeadGeo, lampGlowMat);
    head.position.set(0.58, 3.7, 0);

    lGroup.add(base, post, arm, head);
    worldGroup.add(lGroup);
  }

  // 12. Visible World Boundary Perimeter at ±36.0m (Carved Sandstone Pillars & Wrought-Iron Rails)
  const pillarGeo = new THREE.BoxGeometry(0.46, 1.15, 0.46);
  const pillarCapGeo = new THREE.BoxGeometry(0.56, 0.12, 0.56);
  const railHGeo = new THREE.BoxGeometry(WORLD_HALF_SIZE * 2, 0.08, 0.08);
  const railVGeo = new THREE.BoxGeometry(0.08, 0.08, WORLD_HALF_SIZE * 2);

  const boundaryPillarMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.012,
    roughness: 0.72,
  });
  const boundaryCapMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    bumpMap: pbr.plasterBump,
    bumpScale: 0.008,
    roughness: 0.6,
  });
  disposables.geometries.push(pillarGeo, pillarCapGeo, railHGeo, railVGeo);
  disposables.materials.push(boundaryPillarMat, boundaryCapMat);

  for (let p = -WORLD_HALF_SIZE; p <= WORLD_HALF_SIZE; p += 4.5) {
    const edgeCoords = [
      [p, -WORLD_HALF_SIZE],
      [p, WORLD_HALF_SIZE],
      [-WORLD_HALF_SIZE, p],
      [WORLD_HALF_SIZE, p],
    ];
    for (const [px, pz] of edgeCoords) {
      const pil = new THREE.Mesh(pillarGeo, boundaryPillarMat);
      pil.position.set(px, 0.575, pz);
      const cap = new THREE.Mesh(pillarCapGeo, boundaryCapMat);
      cap.position.set(px, 1.2, pz);
      worldGroup.add(pil, cap);
    }
  }

  // Top & Bottom horizontal boundary rails on all 4 sides
  for (const railY of [0.42, 0.88]) {
    const rNorth = new THREE.Mesh(railHGeo, benchIronMat);
    rNorth.position.set(0, railY, -WORLD_HALF_SIZE);
    const rSouth = new THREE.Mesh(railHGeo, benchIronMat);
    rSouth.position.set(0, railY, WORLD_HALF_SIZE);
    const rWest = new THREE.Mesh(railVGeo, benchIronMat);
    rWest.position.set(-WORLD_HALF_SIZE, railY, 0);
    const rEast = new THREE.Mesh(railVGeo, benchIronMat);
    rEast.position.set(WORLD_HALF_SIZE, railY, 0);
    worldGroup.add(rNorth, rSouth, rWest, rEast);
  }

  return {
    worldGroup,
    dispose: () => {
      for (const g of disposables.geometries) g.dispose();
      for (const m of disposables.materials) m.dispose();
      for (const t of disposables.textures) t.dispose();
    },
  };
}
