import * as THREE from 'three';

export interface PbrTextureLibrary {
  asphaltMap: THREE.CanvasTexture;
  asphaltBump: THREE.CanvasTexture;
  sidewalkMap: THREE.CanvasTexture;
  sidewalkBump: THREE.CanvasTexture;
  plazaTileMap: THREE.CanvasTexture;
  plazaTileBump: THREE.CanvasTexture;
  grassMap: THREE.CanvasTexture;
  grassBump: THREE.CanvasTexture;
  woodMap: THREE.CanvasTexture;
  woodBump: THREE.CanvasTexture;
  brushedSteelBump: THREE.CanvasTexture;
  hammeredMetalBump: THREE.CanvasTexture;
  burlapMap: THREE.CanvasTexture;
  burlapBump: THREE.CanvasTexture;
  canopyFabricBump: THREE.CanvasTexture;
  plasterBump: THREE.CanvasTexture;
  windowFacadeMap: THREE.CanvasTexture;
  puriCrustMap: THREE.CanvasTexture;
  puriCrustBump: THREE.CanvasTexture;
  alooMashMap: THREE.CanvasTexture;
  alooMashBump: THREE.CanvasTexture;
  sevStrandMap: THREE.CanvasTexture;
  sevStrandBump: THREE.CanvasTexture;
  curdSwirlMap: THREE.CanvasTexture;
  jeeraLiquidMap: THREE.CanvasTexture;
  chatniLiquidMap: THREE.CanvasTexture;
  dispose: () => void;
}

/**
 * Deterministic pseudo-random helper in [0, 1) so procedural PBR maps are 100% consistent.
 */
function hash2D(x: number, y: number, seed: number = 1): number {
  const n = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

function createCanvasTex(
  width: number,
  height: number,
  isColorMap: boolean,
  maxAnisotropy: number,
  drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    drawFn(ctx, width, height);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColorMap ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Creates a shared library of PBR albedo, bump/normal, and roughness textures
 * for the city environment, hero Pani Puri stall, and food ingredients.
 */
export function createPbrTextureLibrary(
  maxAnisotropy: number,
  texturesTracker?: THREE.Texture[]
): PbrTextureLibrary {
  const created: THREE.Texture[] = [];
  const register = <T extends THREE.Texture>(t: T): T => {
    created.push(t);
    texturesTracker?.push(t);
    return t;
  };

  // 1. ASPHALT ROAD (Aggregate grain, subtle tar variation, restrained wear)
  const asphaltMap = register(
    createCanvasTex(512, 512, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#2d3748';
      ctx.fillRect(0, 0, w, h);

      // Subtle broad tonal patches (restrained road wear)
      for (let i = 0; i < 48; i++) {
        const px = hash2D(i, 1, 10) * w;
        const py = hash2D(i, 2, 10) * h;
        const rad = 28 + hash2D(i, 3, 10) * 55;
        const g = ctx.createRadialGradient(px, py, 4, px, py, rad);
        const dark = i % 2 === 0;
        g.addColorStop(0, dark ? 'rgba(15, 23, 42, 0.22)' : 'rgba(100, 116, 139, 0.14)');
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, w, h);
      }

      // Fine mineral aggregate speckles
      for (let i = 0; i < 6500; i++) {
        const x = (i * 97) % w;
        const y = (i * 193) % h;
        const v = 34 + ((i * 29) % 34);
        ctx.fillStyle = `rgb(${v}, ${v + 3}, ${v + 8})`;
        ctx.fillRect(x, y, 2, 2);
      }
    })
  );
  asphaltMap.repeat.set(24, 24);

  const asphaltBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 4800; i++) {
        const x = (i * 61) % w;
        const y = (i * 137) % h;
        const v = 90 + ((i * 43) % 85);
        ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
        ctx.fillRect(x, y, 2, 2);
      }
    })
  );
  asphaltBump.repeat.set(24, 24);

  // 2. SIDEWALK PAVING (Concrete/stone slabs with subtle seams and natural discoloration)
  const sidewalkMap = register(
    createCanvasTex(512, 512, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#e5e0d8';
      ctx.fillRect(0, 0, w, h);

      const grid = 4;
      const cell = w / grid;
      for (let gx = 0; gx < grid; gx++) {
        for (let gy = 0; gy < grid; gy++) {
          const shade = 220 + Math.floor(hash2D(gx, gy, 3) * 18 - 9);
          ctx.fillStyle = `rgb(${shade + 4}, ${shade}, ${shade - 6})`;
          ctx.fillRect(gx * cell + 2, gy * cell + 2, cell - 4, cell - 4);
        }
      }

      // Subtle weathering / mineral grain
      for (let i = 0; i < 3200; i++) {
        const x = (i * 83) % w;
        const y = (i * 151) % h;
        const v = 198 + ((i * 19) % 32);
        ctx.fillStyle = `rgba(${v}, ${v - 4}, ${v - 8}, 0.35)`;
        ctx.fillRect(x, y, 2, 2);
      }

      // Grout seams
      ctx.strokeStyle = '#a8a29e';
      ctx.lineWidth = 3;
      for (let i = 0; i <= grid; i++) {
        const p = i * cell;
        ctx.beginPath();
        ctx.moveTo(p, 0);
        ctx.lineTo(p, h);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, p);
        ctx.lineTo(w, p);
        ctx.stroke();
      }
    })
  );
  sidewalkMap.repeat.set(18, 18);

  const sidewalkBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#969696';
      ctx.fillRect(0, 0, w, h);
      const grid = 4;
      const cell = w / grid;
      ctx.strokeStyle = '#383838';
      ctx.lineWidth = 3;
      for (let i = 0; i <= grid; i++) {
        const p = i * cell;
        ctx.beginPath();
        ctx.moveTo(p, 0);
        ctx.lineTo(p, h);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, p);
        ctx.lineTo(w, p);
        ctx.stroke();
      }
    })
  );
  sidewalkBump.repeat.set(18, 18);

  // 3. SANDSTONE PLAZA TILES (Warm Jaipur sandstone tiles around the Pani Puri Stall)
  const plazaTileMap = register(
    createCanvasTex(512, 512, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#f5d0a9';
      ctx.fillRect(0, 0, w, h);
      const cols = 4;
      const rows = 4;
      const cw = w / cols;
      const ch = h / rows;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const delta = Math.floor(hash2D(c, r, 7) * 20 - 10);
          ctx.fillStyle = `rgb(${242 + delta}, ${202 + delta}, ${160 + delta})`;
          ctx.fillRect(c * cw + 3, r * ch + 3, cw - 6, ch - 6);

          // Inner decorative sandstone bevel line
          ctx.strokeStyle = 'rgba(180, 83, 9, 0.18)';
          ctx.lineWidth = 2;
          ctx.strokeRect(c * cw + 8, r * ch + 8, cw - 16, ch - 16);
        }
      }

      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 4;
      for (let i = 0; i <= cols; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cw, 0);
        ctx.lineTo(i * cw, h);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i * ch);
        ctx.lineTo(w, i * ch);
        ctx.stroke();
      }
    })
  );
  plazaTileMap.repeat.set(4, 4);

  const plazaTileBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#a0a0a0';
      ctx.fillRect(0, 0, w, h);
      const cell = w / 4;
      ctx.strokeStyle = '#303030';
      ctx.lineWidth = 4;
      for (let i = 0; i <= 4; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cell, 0);
        ctx.lineTo(i * cell, h);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i * cell);
        ctx.lineTo(w, i * cell);
        ctx.stroke();
      }
    })
  );
  plazaTileBump.repeat.set(4, 4);

  // 4. NATURAL PARK GRASS (Lush botanical multi-tone green without neon oversaturation)
  const grassMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#2e6f40';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 3600; i++) {
        const x = (i * 53) % w;
        const y = (i * 113) % h;
        const g = 92 + ((i * 31) % 48);
        const r = Math.floor(g * 0.42);
        const b = Math.floor(g * 0.34);
        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        ctx.fillRect(x, y, 2, 4);
      }
    })
  );
  grassMap.repeat.set(5, 5);

  const grassBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#787878';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 3000; i++) {
        const x = (i * 47) % w;
        const y = (i * 101) % h;
        const v = 70 + ((i * 37) % 110);
        ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
        ctx.fillRect(x, y, 2, 3);
      }
    })
  );
  grassBump.repeat.set(5, 5);

  // 5. WARM TEAK WOOD GRAIN (Stall prep board, cart wheels, park benches)
  const woodMap = register(
    createCanvasTex(512, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#7c3f16';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 2) {
        const wave = Math.sin(y * 0.14) * 10 + Math.cos(y * 0.05) * 6;
        const r = Math.max(60, Math.min(165, Math.round(122 + wave)));
        const g = Math.max(30, Math.min(95, Math.round(62 + wave * 0.6)));
        const b = Math.max(12, Math.min(48, Math.round(22 + wave * 0.3)));
        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        ctx.fillRect(0, y, w, 2);
      }
      // Subtle plank join lines
      ctx.strokeStyle = 'rgba(41, 18, 5, 0.38)';
      ctx.lineWidth = 2;
      for (let y = 64; y < h; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    })
  );

  const woodBump = register(
    createCanvasTex(256, 128, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y++) {
        const v = Math.round(128 + Math.sin(y * 0.35) * 28);
        ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
        ctx.fillRect(0, y, w, 1);
      }
    })
  );

  // 6. BRUSHED STAINLESS STEEL & HAMMERED BRASS BUMP MAPS
  const brushedSteelBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y++) {
        const v = 114 + ((y * 17) % 28);
        ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
        ctx.fillRect(0, y, w, 1);
      }
    })
  );
  brushedSteelBump.repeat.set(3, 3);

  const hammeredMetalBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 160; i++) {
        const cx = hash2D(i, 1, 21) * w;
        const cy = hash2D(i, 2, 21) * h;
        const r = 8 + hash2D(i, 3, 21) * 10;
        const g = ctx.createRadialGradient(cx, cy, 1, cx, cy, r);
        g.addColorStop(0, '#a8a8a8');
        g.addColorStop(1, '#707070');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    })
  );
  hammeredMetalBump.repeat.set(2, 2);

  // 7. WOVEN JUTE BURLAP & CANOPY FABRIC
  const burlapMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#a16207';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = 'rgba(120, 53, 15, 0.35)';
      for (let x = 0; x < w; x += 6) {
        ctx.fillRect(x, 0, 2, h);
      }
      ctx.fillStyle = 'rgba(254, 243, 199, 0.16)';
      for (let y = 0; y < h; y += 6) {
        ctx.fillRect(0, y, w, 2);
      }
    })
  );
  burlapMap.repeat.set(2, 2);

  const burlapBump = register(
    createCanvasTex(128, 128, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#707070';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#b0b0b0';
      for (let x = 0; x < w; x += 4) ctx.fillRect(x, 0, 2, h);
      for (let y = 0; y < h; y += 4) ctx.fillRect(0, y, w, 2);
    })
  );
  burlapBump.repeat.set(3, 3);

  const canopyFabricBump = register(
    createCanvasTex(128, 128, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#787878';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#9a9a9a';
      for (let y = 0; y < h; y += 3) ctx.fillRect(0, y, w, 1);
    })
  );
  canopyFabricBump.repeat.set(4, 4);

  // 8. BUILDING PLASTER BUMP & ARCHITECTURAL WINDOW MULLION FACADE
  const plasterBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 4200; i++) {
        const x = (i * 71) % w;
        const y = (i * 149) % h;
        const v = 104 + ((i * 23) % 48);
        ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
        ctx.fillRect(x, y, 2, 2);
      }
    })
  );
  plasterBump.repeat.set(4, 4);

  const windowFacadeMap = register(
    createCanvasTex(256, 128, true, maxAnisotropy, (ctx, w, h) => {
      // Deep architectural glass with subtle sky gradient & interior warm glow
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(0.55, '#1e293b');
      grad.addColorStop(1, '#334155');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      const panes = 4;
      const pw = w / panes;
      for (let i = 0; i < panes; i++) {
        // Subtle warm interior reflection on alternating panes
        if (i % 2 === 1) {
          ctx.fillStyle = 'rgba(253, 224, 71, 0.14)';
          ctx.fillRect(i * pw + 6, 8, pw - 12, h - 16);
        }
        // Diagonal sky reflection highlight
        ctx.fillStyle = 'rgba(186, 230, 253, 0.16)';
        ctx.beginPath();
        ctx.moveTo(i * pw + 8, 8);
        ctx.lineTo(i * pw + pw * 0.55, 8);
        ctx.lineTo(i * pw + 8, h * 0.65);
        ctx.closePath();
        ctx.fill();

        // Aluminum / painted window frame mullions
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 4;
        ctx.strokeRect(i * pw + 3, 3, pw - 6, h - 6);
      }
    })
  );

  // ============================================================================
  // 9. APPETIZING FOOD & INGREDIENT PBR MAPS
  // ============================================================================

  // A. SUKHI PURI — Golden-brown crispy fried semolina shell with toasted blister spots
  const puriCrustMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#e59824';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 140; i++) {
        const cx = hash2D(i, 1, 31) * w;
        const cy = hash2D(i, 2, 31) * h;
        const r = 6 + hash2D(i, 3, 31) * 16;
        const g = ctx.createRadialGradient(cx, cy, 1, cx, cy, r);
        if (i % 3 === 0) {
          // Light golden puffed blister
          g.addColorStop(0, 'rgba(254, 240, 138, 0.55)');
          g.addColorStop(1, 'rgba(229, 152, 36, 0)');
        } else {
          // Warm toasted brown spot
          g.addColorStop(0, 'rgba(180, 83, 9, 0.48)');
          g.addColorStop(1, 'rgba(229, 152, 36, 0)');
        }
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    })
  );

  const puriCrustBump = register(
    createCanvasTex(256, 256, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#787878';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 180; i++) {
        const cx = hash2D(i, 1, 31) * w;
        const cy = hash2D(i, 2, 31) * h;
        const r = 4 + hash2D(i, 3, 31) * 12;
        const g = ctx.createRadialGradient(cx, cy, 1, cx, cy, r);
        g.addColorStop(0, '#c8c8c8');
        g.addColorStop(1, '#707070');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    })
  );

  // B. ALOO — Spiced mashed potato with roasted cumin, coriander leaves & red chili flecks
  const alooMashMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#eab308';
      ctx.fillRect(0, 0, w, h);
      // Soft mashed potato tonal variación
      for (let i = 0; i < 90; i++) {
        const cx = hash2D(i, 1, 41) * w;
        const cy = hash2D(i, 2, 41) * h;
        const r = 10 + hash2D(i, 3, 41) * 20;
        const g = ctx.createRadialGradient(cx, cy, 2, cx, cy, r);
        g.addColorStop(0, i % 2 === 0 ? 'rgba(254, 240, 138, 0.5)' : 'rgba(202, 138, 4, 0.45)');
        g.addColorStop(1, 'rgba(234, 179, 8, 0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
      // Fresh green coriander & roasted cumin/chili spice flecks
      for (let i = 0; i < 120; i++) {
        const x = hash2D(i, 4, 41) * w;
        const y = hash2D(i, 5, 41) * h;
        ctx.fillStyle = i % 3 === 0 ? '#15803d' : i % 3 === 1 ? '#78350f' : '#b91c1c';
        ctx.fillRect(x, y, 3, 3);
      }
    })
  );

  const alooMashBump = register(
    createCanvasTex(128, 128, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 120; i++) {
        const cx = hash2D(i, 1, 41) * w;
        const cy = hash2D(i, 2, 41) * h;
        const r = 6 + hash2D(i, 3, 41) * 10;
        const g = ctx.createRadialGradient(cx, cy, 1, cx, cy, r);
        g.addColorStop(0, '#bcbcbc');
        g.addColorStop(1, '#686868');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    })
  );

  // C. SEV — Fine golden-yellow crispy gram-flour strands
  const sevStrandMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#d97706';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 320; i++) {
        const x = hash2D(i, 1, 51) * w;
        const y = hash2D(i, 2, 51) * h;
        const angle = hash2D(i, 3, 51) * Math.PI * 2;
        const len = 14 + hash2D(i, 4, 51) * 14;
        ctx.strokeStyle = i % 2 === 0 ? '#fde047' : '#f59e0b';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
        ctx.stroke();
      }
    })
  );

  const sevStrandBump = register(
    createCanvasTex(128, 128, false, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#686868';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#d0d0d0';
      ctx.lineWidth = 2;
      for (let i = 0; i < 220; i++) {
        const x = hash2D(i, 1, 51) * w;
        const y = hash2D(i, 2, 51) * h;
        const angle = hash2D(i, 3, 51) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(angle) * 12, y + Math.sin(angle) * 12);
        ctx.stroke();
      }
    })
  );

  // D. CURD — Creamy white whisked yogurt with subtle spice dust
  const curdSwirlMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, w, h);
      for (let r = 20; r < 120; r += 18) {
        ctx.strokeStyle = 'rgba(226, 232, 240, 0.7)';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, r, 0, Math.PI * 2);
        ctx.stroke();
      }
      // Subtle pinch of roasted cumin & chili powder on the curd
      for (let i = 0; i < 45; i++) {
        const x = hash2D(i, 1, 61) * w;
        const y = hash2D(i, 2, 61) * h;
        ctx.fillStyle = i % 2 === 0 ? 'rgba(180, 83, 9, 0.45)' : 'rgba(185, 28, 28, 0.4)';
        ctx.fillRect(x, y, 2, 2);
      }
    })
  );

  // E. JEERA JAL — Spiced emerald-mint & cumin water with floating boondi/mint flecks
  const jeeraLiquidMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      const grad = ctx.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w / 2);
      grad.addColorStop(0, '#15803d');
      grad.addColorStop(0.7, '#166534');
      grad.addColorStop(1, '#14532d');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Floating mint leaf & spiced boondi droplets
      for (let i = 0; i < 55; i++) {
        const x = hash2D(i, 1, 71) * w;
        const y = hash2D(i, 2, 71) * h;
        ctx.fillStyle = i % 3 === 0 ? '#facc15' : '#4ade80';
        ctx.beginPath();
        ctx.arc(x, y, i % 3 === 0 ? 3.5 : 2, 0, Math.PI * 2);
        ctx.fill();
      }
    })
  );

  // F. SWEET CHATNI — Rich glossy tamarind-date brown glaze with fennel/melon seeds
  const chatniLiquidMap = register(
    createCanvasTex(256, 256, true, maxAnisotropy, (ctx, w, h) => {
      const grad = ctx.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w / 2);
      grad.addColorStop(0, '#9a3412');
      grad.addColorStop(0.75, '#7c2d12');
      grad.addColorStop(1, '#431407');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      for (let i = 0; i < 36; i++) {
        const x = hash2D(i, 1, 81) * w;
        const y = hash2D(i, 2, 81) * h;
        ctx.fillStyle = 'rgba(254, 215, 170, 0.55)';
        ctx.fillRect(x, y, 3, 2);
      }
    })
  );

  return {
    asphaltMap,
    asphaltBump,
    sidewalkMap,
    sidewalkBump,
    plazaTileMap,
    plazaTileBump,
    grassMap,
    grassBump,
    woodMap,
    woodBump,
    brushedSteelBump,
    hammeredMetalBump,
    burlapMap,
    burlapBump,
    canopyFabricBump,
    plasterBump,
    windowFacadeMap,
    puriCrustMap,
    puriCrustBump,
    alooMashMap,
    alooMashBump,
    sevStrandMap,
    sevStrandBump,
    curdSwirlMap,
    jeeraLiquidMap,
    chatniLiquidMap,
    dispose: () => {
      for (const t of created) {
        t.dispose();
      }
    },
  };
}
