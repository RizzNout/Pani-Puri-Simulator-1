import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateRecipeAccuracy,
  createEmptyPlate,
  RECIPES,
  REQUIRED_PURIS_PER_PLATE,
} from './recipes';
import {
  addSinglePuriToActivePlate,
  completeActivePlate,
  createInitialFoodPrepState,
  discardActivePlate,
  getShopItemEffectivePrice,
  INGREDIENT_BASE_PRICES,
  performPickOrDrop,
  purchaseShopItem,
  purchaseShopUpgrade,
  requestRecipeSelection,
  SHOP_ITEMS,
  SHOP_UPGRADES,
  STAR_RATING_REWARDS,
  startIngredientPour,
  stepIngredientPourUnits,
  stopIngredientPour,
  UPGRADE_PRICES,
  STALL_HOME_POSITIONS,
  PLATE_STACK_POSITION,
  PREP_COUNTER_POSITION,
  SERVING_AREA_POSITION,
} from './foodPrepEngine';
import { sanitizeSavedProgress, SAFE_DEFAULT_INVENTORY } from './saveSystem';
import { sanitizeSettings } from '../utils/settings';
import {
  clampControlPlacement,
  cloneControlLayout,
  CONTROL_SIZE_PRESETS,
  DEFAULT_CONTROL_LAYOUT,
  detectControlOverlaps,
  resetAllControlsInLayout,
  resetSingleControlInLayout,
  sanitizeControlLayout,
} from './controlLayout';
import {
  CITY_EDGE_SPAWN_ROUTES,
  CUSTOMER_EXIT_WAYPOINTS,
  computeStarRatingAndReward,
  createCustomerAppearance,
  createInitialCustomerSystemState,
  CUSTOMER_ARCHETYPES,
  getActiveCustomer,
  QUEUE_SLOTS,
  spawnCustomer,
  stepCustomerSystem,
} from './customerSystem';

test('Recipe definitions match Phase 2 specification and sum to 100 ingredient units', () => {
  // Recipe A: Sweet Puri
  const sweet = RECIPES.sweet_puri;
  assert.equal(sweet.requiredPuris, 6);
  assert.equal(sweet.targetIngredients.aloo, 25);
  assert.equal(sweet.targetIngredients.sweet_chatni, 50);
  assert.equal(sweet.targetIngredients.curd, 15);
  assert.equal(sweet.targetIngredients.sev, 10);
  assert.equal(sweet.targetIngredients.jeera_jal, 0);
  const sweetSum = Object.values(sweet.targetIngredients).reduce((a, b) => a + b, 0);
  assert.equal(sweetSum, 100);

  // Recipe B: Pani Puri
  const pani = RECIPES.pani_puri;
  assert.equal(pani.requiredPuris, 6);
  assert.equal(pani.targetIngredients.aloo, 50);
  assert.equal(pani.targetIngredients.jeera_jal, 50);
  const paniSum = Object.values(pani.targetIngredients).reduce((a, b) => a + b, 0);
  assert.equal(paniSum, 100);

  // Recipe C: Sev Puri
  const sev = RECIPES.sev_puri;
  assert.equal(sev.requiredPuris, 6);
  assert.equal(sev.targetIngredients.aloo, 50);
  assert.equal(sev.targetIngredients.sev, 30);
  assert.equal(sev.targetIngredients.curd, 20);
  const sevSum = Object.values(sev.targetIngredients).reduce((a, b) => a + b, 0);
  assert.equal(sevSum, 100);
});

test('Six-puri placement system allows adding 1..6 puris and blocks a 7th puri without wasting stock', () => {
  const state = createInitialFoodPrepState();

  // 1. Pick up plate from stack
  state.aimedTarget = 'plate_stack';
  const initialPlates = state.inventory.emptyPlates;
  performPickOrDrop(state, 4.5, -3.0, 0);
  assert.equal(state.heldItem, 'plate');
  assert.equal(state.inventory.emptyPlates, initialPlates - 1);

  // 2. Place plate on prep counter
  state.aimedTarget = 'prep_counter';
  performPickOrDrop(state, 4.5, -3.0, 0);
  assert.equal(state.heldItem, null);
  assert.ok(state.activePlate);
  assert.equal(state.activePlate.puris, 0);

  // 3. Pick up Sukhi Puri container
  state.aimedTarget = 'sukhi_puri';
  performPickOrDrop(state, 4.5, -3.0, 0);
  assert.equal(state.heldItem, 'sukhi_puri');

  // 4. Add 6 puris one at a time
  state.aimedTarget = 'active_plate';
  const initialPuriStock = state.inventory.sukhi_puri;
  for (let i = 1; i <= REQUIRED_PURIS_PER_PLATE; i++) {
    addSinglePuriToActivePlate(state);
    assert.equal(state.activePlate.puris, i);
  }
  assert.equal(state.inventory.sukhi_puri, initialPuriStock - 6);
  assert.equal(state.statusBanner, 'All 6 puris added!');

  // 5. Attempt to add a 7th puri -> blocked, stock unchanged
  const res7 = addSinglePuriToActivePlate(state);
  assert.equal(res7.message, 'All 6 puris added!');
  assert.equal(state.activePlate.puris, 6);
  assert.equal(state.inventory.sukhi_puri, initialPuriStock - 6);
});

test('Pouring system updates quantities, stops on release, and stops when stock runs out', () => {
  const state = createInitialFoodPrepState({ aloo: 30 });
  state.activePlate = createEmptyPlate('plate-test');
  state.heldItem = 'aloo';
  state.aimedTarget = 'active_plate';

  startIngredientPour(state);
  assert.equal(state.isPouring, true);
  assert.equal(state.pouringIngredient, 'aloo');

  // Pour 20 units
  stepIngredientPourUnits(state, 20);
  assert.equal(state.activePlate.ingredients.aloo, 20);
  assert.equal(state.inventory.aloo, 10);
  assert.equal(state.isPouring, true);

  // Release button stops pouring
  stopIngredientPour(state);
  assert.equal(state.isPouring, false);
  stepIngredientPourUnits(state, 10);
  assert.equal(state.activePlate.ingredients.aloo, 20);

  // Resume pouring and exceed remaining stock (10 units left)
  startIngredientPour(state);
  stepIngredientPourUnits(state, 25);
  assert.equal(state.activePlate.ingredients.aloo, 30);
  assert.equal(state.inventory.aloo, 0);
  assert.equal(state.isPouring, false);
});

test('Recipe accuracy calculation honors ±5 tolerance and penalizes missing or wrong ingredients', () => {
  const plate = createEmptyPlate('p1');
  plate.puris = 6;
  // Sweet Puri targets: aloo 25, sweet_chatni 50, curd 15, sev 10
  plate.ingredients.aloo = 27; // within +2 (<= 5 tolerance)
  plate.ingredients.sweet_chatni = 46; // within -4 (<= 5 tolerance)
  plate.ingredients.curd = 15;
  plate.ingredients.sev = 12;

  const exactRes = calculateRecipeAccuracy(plate, 'sweet_puri');
  assert.equal(exactRes.isComplete, true);
  assert.equal(exactRes.isWithinTolerance, true);
  assert.equal(exactRes.accuracy, 100);

  // Add wrong ingredient (Jeera Jal is not in Sweet Puri)
  plate.ingredients.jeera_jal = 20;
  const wrongRes = calculateRecipeAccuracy(plate, 'sweet_puri');
  assert.equal(wrongRes.isWithinTolerance, false);
  assert.ok(wrongRes.accuracy < 80);
  assert.deepEqual(wrongRes.wrongIngredients, ['jeera_jal']);
});

test('Discarding a plate clears active plate, prevents state leaks, and handles recipe switch confirmation', () => {
  const state = createInitialFoodPrepState();
  state.activePlate = createEmptyPlate('p-first');
  state.activePlate.puris = 3;
  state.activePlate.ingredients.aloo = 25;

  // Trying to switch recipe while plate has contents opens confirmation
  requestRecipeSelection(state, 'pani_puri');
  assert.equal(state.selectedRecipeId, 'sweet_puri');
  assert.equal(state.pendingRecipeSwitch, 'pani_puri');
  assert.equal(state.discardConfirmOpen, true);

  // Confirm discard clears the plate and applies the pending recipe switch
  discardActivePlate(state, true);
  assert.equal(state.activePlate, null);
  assert.equal(state.selectedRecipeId, 'pani_puri');

  // New plate starts completely clean with no leaked quantities
  const freshPlate = createEmptyPlate('p-second');
  assert.equal(freshPlate.puris, 0);
  assert.equal(freshPlate.ingredients.aloo, 0);

  // Completing an incomplete plate is rejected
  state.activePlate = freshPlate;
  const completeAttempt = completeActivePlate(state);
  assert.ok(completeAttempt.evaluation && !completeAttempt.evaluation.isComplete);
  assert.ok(state.activePlate !== null);
});

test('Control layout customization clamps coordinates, supports 70%-150% sizing, detects overlaps, and resets cleanly', () => {
  // Verify presets
  assert.deepEqual(
    CONTROL_SIZE_PRESETS.map((p) => p.percent),
    [70, 100, 125, 150]
  );

  // Default layout starts with Medium (1.0 = 100%) and zero overlaps
  const layout = cloneControlLayout(DEFAULT_CONTROL_LAYOUT);
  assert.equal(layout.jump.scale, 1.0);
  assert.equal(detectControlOverlaps(layout).length, 0);

  // Clamping out-of-bounds coordinates and sizes
  const clamped = clampControlPlacement('jump', { xPercent: 99, yPercent: -10, scale: 2.1 });
  assert.ok(clamped.xPercent <= 96);
  assert.ok(clamped.yPercent >= 8);
  assert.equal(clamped.scale, 1.5);

  const clampedSmall = clampControlPlacement('sprint', { xPercent: 1, yPercent: 99, scale: 0.3 });
  assert.ok(clampedSmall.xPercent >= 4);
  assert.ok(clampedSmall.yPercent <= 94);
  assert.equal(clampedSmall.scale, 0.7);

  // Overlap detection when Jump is moved on top of Pour
  layout.jump = { ...layout.pour, scale: 1.25 };
  const overlaps = detectControlOverlaps(layout);
  assert.ok(overlaps.length >= 1);

  // Reset single control restores Jump to default and resolves overlap
  const afterSingleReset = resetSingleControlInLayout(layout, 'jump');
  assert.deepEqual(afterSingleReset.jump, DEFAULT_CONTROL_LAYOUT.jump);
  assert.equal(detectControlOverlaps(afterSingleReset).length, 0);

  // Reset all controls restores full default map
  layout.joystick = { xPercent: 45, yPercent: 45, scale: 1.5 };
  const afterAllReset = resetAllControlsInLayout();
  assert.deepEqual(afterAllReset, DEFAULT_CONTROL_LAYOUT);

  // Sanitize partial or corrupted input
  const sanitized = sanitizeControlLayout({ jump: { xPercent: 60, yPercent: 40, scale: 1.25 } });
  assert.equal(sanitized.jump.xPercent, 60);
  assert.equal(sanitized.jump.scale, 1.25);
  assert.deepEqual(sanitized.joystick, DEFAULT_CONTROL_LAYOUT.joystick);
});

test('Phase 4 Economy Rebalance: Shop purchases +10 units, deducts exact prices, applies 50% discount only to ingredients, and enforces upgrade prices', () => {
  const state = createInitialFoodPrepState();
  assert.equal(state.coins, 50);
  assert.equal(state.customerLimit, 5);

  // Verify centralized base prices match Phase 4 specification
  const priceMap = Object.fromEntries(SHOP_ITEMS.map((item) => [item.id, item.basePrice]));
  assert.equal(priceMap.sukhi_puri, 8);
  assert.equal(priceMap.aloo, 15);
  assert.equal(priceMap.sev, 12);
  assert.equal(priceMap.curd, 18);
  assert.equal(priceMap.jeera_jal, 12);
  assert.equal(priceMap.sweet_chatni, 14);
  assert.equal(priceMap.plate, 5);
  assert.deepEqual(priceMap, INGREDIENT_BASE_PRICES);

  // Verify centralized upgrade prices (More Customers: 250, 50% Discount: 500)
  const upgradePriceMap = Object.fromEntries(SHOP_UPGRADES.map((u) => [u.id, u.price]));
  assert.equal(upgradePriceMap.more_customers, 250);
  assert.equal(upgradePriceMap.discount_50, 500);
  assert.deepEqual(upgradePriceMap, UPGRADE_PRICES);

  // Purchase Aloo (+10 units for 15 coins)
  const initialAloo = state.inventory.aloo;
  const buyAloo = purchaseShopItem(state, 'aloo');
  assert.equal(buyAloo.soundCue, 'purchase');
  assert.equal(state.inventory.aloo, initialAloo + 10);
  assert.equal(state.coins, 35);

  // Purchase Plate (+10 plates for 5 coins)
  const initialPlates = state.inventory.emptyPlates;
  const buyPlate = purchaseShopItem(state, 'plate');
  assert.equal(buyPlate.soundCue, 'purchase');
  assert.equal(state.inventory.emptyPlates, initialPlates + 10);
  assert.equal(state.coins, 30);

  // Attempt to purchase More Customers (250 coins) with only 30 coins -> blocked
  const failUpgrade = purchaseShopUpgrade(state, 'more_customers');
  assert.equal(failUpgrade.soundCue, 'empty_stock');
  assert.equal(state.upgrades.moreCustomers, false);
  assert.equal(state.coins, 30);

  // Grant coins to test upgrade purchases & 50% discount rules
  state.coins = 800;

  // Purchase 50% Discount first (500 coins)
  const buyDiscount = purchaseShopUpgrade(state, 'discount_50');
  assert.equal(buyDiscount.soundCue, 'purchase');
  assert.equal(state.upgrades.discount50, true);
  assert.equal(state.coins, 300);

  // Verify 50% discount does NOT discount the More Customers upgrade (still costs 250, not 125)
  const buyCustomers = purchaseShopUpgrade(state, 'more_customers');
  assert.equal(buyCustomers.soundCue, 'purchase');
  assert.equal(state.upgrades.moreCustomers, true);
  assert.equal(state.customerLimit, 10);
  assert.equal(state.coins, 50); // 300 - 250 = 50

  // Prevent duplicate upgrade purchase (coins unchanged)
  const duplicateCustomers = purchaseShopUpgrade(state, 'more_customers');
  assert.equal(duplicateCustomers.soundCue, 'notice');
  assert.equal(state.coins, 50);

  // Verify 50% discount prices on eligible ingredients (applied once per transaction)
  assert.equal(getShopItemEffectivePrice(priceMap.sukhi_puri, state.upgrades.discount50), 4);
  assert.equal(getShopItemEffectivePrice(priceMap.aloo, state.upgrades.discount50), 7.5);
  assert.equal(getShopItemEffectivePrice(priceMap.sev, state.upgrades.discount50), 6);
  assert.equal(getShopItemEffectivePrice(priceMap.curd, state.upgrades.discount50), 9);
  assert.equal(getShopItemEffectivePrice(priceMap.jeera_jal, state.upgrades.discount50), 6);
  assert.equal(getShopItemEffectivePrice(priceMap.sweet_chatni, state.upgrades.discount50), 7);
  assert.equal(getShopItemEffectivePrice(priceMap.plate, state.upgrades.discount50), 2.5);

  // Purchase discounted Aloo (7.5 coins) and discounted Curd (9 coins)
  const buyDiscountedAloo = purchaseShopItem(state, 'aloo');
  assert.equal(buyDiscountedAloo.soundCue, 'purchase');
  assert.equal(state.coins, 42.5);

  const buyDiscountedCurd = purchaseShopItem(state, 'curd');
  assert.equal(buyDiscountedCurd.soundCue, 'purchase');
  assert.equal(state.coins, 33.5);

  // Prevent purchase when coins are insufficient and never allow negative balances
  state.coins = 2;
  const stockBeforeFail = state.inventory.curd;
  const failBuy = purchaseShopItem(state, 'curd');
  assert.equal(failBuy.soundCue, 'empty_stock');
  assert.equal(state.inventory.curd, stockBeforeFail);
  assert.equal(state.coins, 2);
});

test('Phase 3 & 4: Customer spawning respects default limit of 5 and increases to 10 with More Customers upgrade', () => {
  const state = createInitialFoodPrepState(undefined, 300);
  const sys = state.customerSystem;
  assert.equal(sys.maxCustomers, 5);
  assert.equal(sys.customers.length, 2); // Customer 1 at counter, Customer 2 walking in

  // Step 30 seconds to allow gradual spawning up to limit
  for (let i = 0; i < 60; i++) {
    // Keep active customer patience topped up so we purely test max spawn cap
    if (sys.customers[0]) sys.customers[0].patience = 55;
    stepCustomerSystem(sys, 0.5, false);
  }
  assert.equal(sys.customers.length, 5);

  // Attempting to spawn beyond 5 returns null
  assert.equal(spawnCustomer(sys), null);

  // Pause blocks spawning and patience decay
  const pBefore = sys.customers[0].patience;
  stepCustomerSystem(sys, 5.0, true);
  assert.equal(sys.customers[0].patience, pBefore);

  // Buy More Customers upgrade (250 coins) -> limit increases to 10
  purchaseShopUpgrade(state, 'more_customers');
  assert.equal(state.customerLimit, 10);
  assert.equal(sys.maxCustomers, 10);
  assert.equal(state.coins, 50);

  for (let i = 0; i < 60; i++) {
    if (sys.customers[0]) sys.customers[0].patience = 55;
    stepCustomerSystem(sys, 0.5, false);
  }
  assert.equal(sys.customers.length, 10);
  assert.equal(spawnCustomer(sys), null);
});

test('Phase 4: Serving system validates recipe, awards 35/25/15/8/3 coins for 5..1 stars, prevents duplicate rewards, and advances queue', () => {
  const state = createInitialFoodPrepState();
  const sys = state.customerSystem;
  const firstCustomer = getActiveCustomer(sys)!;
  assert.ok(firstCustomer);
  assert.equal(firstCustomer.orderRecipeId, 'sweet_puri');
  assert.equal(firstCustomer.state, 'WAITING_FOR_FOOD');

  // 1. Try serving with only 4 puris -> rejected, plate kept editable
  const plate = createEmptyPlate('p-serve-1');
  plate.puris = 4;
  plate.ingredients.aloo = 25;
  plate.ingredients.sweet_chatni = 50;
  plate.ingredients.curd = 15;
  plate.ingredients.sev = 10;
  state.activePlate = plate;

  const incompletePuriRes = completeActivePlate(state);
  assert.equal(incompletePuriRes.serveResult?.accepted, false);
  assert.ok(state.activePlate !== null);
  assert.equal(state.coins, 50);

  // 2. Try serving wrong recipe (Pani Puri ingredients when customer ordered Sweet Puri) -> rejected
  const wrongRecipePlate = createEmptyPlate('p-wrong');
  wrongRecipePlate.puris = 6;
  wrongRecipePlate.ingredients.aloo = 50;
  wrongRecipePlate.ingredients.jeera_jal = 50;
  state.activePlate = wrongRecipePlate;

  const wrongRecipeRes = completeActivePlate(state);
  assert.equal(wrongRecipeRes.serveResult?.accepted, false);
  assert.ok(wrongRecipeRes.message?.includes('Sweet Puri'));
  assert.ok(state.activePlate !== null);
  assert.equal(state.coins, 50);

  // 3. Serve a 5-Star Sweet Puri plate (within ±5 tolerance) -> +35 coins!
  plate.puris = 6;
  state.activePlate = plate;
  const fiveStarRes = completeActivePlate(state);
  assert.equal(fiveStarRes.serveResult?.accepted, true);
  assert.equal(fiveStarRes.serveResult?.starRating, 5);
  assert.equal(fiveStarRes.serveResult?.coinsAwarded, 35);
  assert.equal(state.coins, 85);
  assert.equal(state.activePlate, null);
  assert.equal(firstCustomer.state, 'EATING');

  // 4. Attempting to serve the same customer again while EATING is blocked (no duplicate coins)
  state.activePlate = { ...plate, ingredients: { ...plate.ingredients } };
  const duplicateRes = completeActivePlate(state);
  assert.equal(duplicateRes.serveResult?.accepted, false);
  assert.equal(state.coins, 85);
  state.activePlate = null;

  // 5. Step customer through EATING -> REACTING -> LEAVING, and verify Customer #2 advances to Slot 0
  stepCustomerSystem(sys, 1.3, false); // finishes EATING -> enters REACTING
  assert.equal(firstCustomer.state, 'REACTING');

  stepCustomerSystem(sys, 1.5, false); // finishes REACTING -> enters LEAVING & compacts queue
  assert.equal(firstCustomer.state, 'LEAVING');

  // Step Customer #2 into Slot 0 (ORDERING -> WAITING_FOR_FOOD)
  for (let i = 0; i < 20; i++) {
    stepCustomerSystem(sys, 0.25, false);
  }
  const secondCustomer = getActiveCustomer(sys)!;
  assert.ok(secondCustomer);
  assert.equal(secondCustomer.id, 'cust-2');
  assert.equal(secondCustomer.orderRecipeId, 'pani_puri');
  assert.equal(secondCustomer.state, 'WAITING_FOR_FOOD');

  // 6. Verify centralized star rating & coin reward tiers (5★=35, 4★=25, 3★=15, 2★=8, 1★=3)
  assert.deepEqual(STAR_RATING_REWARDS, { 5: 35, 4: 25, 3: 15, 2: 8, 1: 3 });

  assert.equal(
    computeStarRatingAndReward({
      accuracy: 95,
      isComplete: true,
      isWithinTolerance: true,
      missingPuris: 0,
      missingIngredients: [],
      wrongIngredients: [],
      excessIngredients: [],
    }).coinsAwarded,
    35
  );
  assert.equal(
    computeStarRatingAndReward({
      accuracy: 82,
      isComplete: true,
      isWithinTolerance: false,
      missingPuris: 0,
      missingIngredients: [],
      wrongIngredients: [],
      excessIngredients: [],
    }).coinsAwarded,
    25
  );
  assert.equal(
    computeStarRatingAndReward({
      accuracy: 68,
      isComplete: true,
      isWithinTolerance: false,
      missingPuris: 0,
      missingIngredients: [],
      wrongIngredients: [],
      excessIngredients: [],
    }).coinsAwarded,
    15
  );
  assert.equal(
    computeStarRatingAndReward({
      accuracy: 50,
      isComplete: true,
      isWithinTolerance: false,
      missingPuris: 0,
      missingIngredients: [],
      wrongIngredients: [],
      excessIngredients: [],
    }).coinsAwarded,
    8
  );
  assert.equal(
    computeStarRatingAndReward({
      accuracy: 30,
      isComplete: true,
      isWithinTolerance: false,
      missingPuris: 0,
      missingIngredients: [],
      wrongIngredients: ['sev'],
      excessIngredients: [],
    }).coinsAwarded,
    3
  );
});

test('Phase 3: Customer patience expiry causes unhappy reaction, 0 coins, and queue advancement', () => {
  const sys = createInitialCustomerSystemState(5, true);
  const cust1 = getActiveCustomer(sys)!;
  assert.equal(cust1.id, 'cust-1');
  assert.equal(cust1.patience, 55);

  // Expire patience completely
  stepCustomerSystem(sys, 56, false);
  assert.equal(cust1.state, 'REACTING');
  assert.equal(cust1.starRating, 0);
  assert.equal(cust1.coinsAwarded, 0);
  assert.equal(cust1.reactionMood, 'unhappy');
  assert.equal(sys.totalWalkedOutCount, 1);

  // Finish reacting -> leaves queue -> Customer 2 advances to Slot 0
  stepCustomerSystem(sys, 2.0, false);
  assert.equal(cust1.state, 'LEAVING');
});

test('Phase 3.1: Human character appearance generator provides 8 distinct archetypes and prevents consecutive duplicates', () => {
  assert.ok(CUSTOMER_ARCHETYPES.length >= 8);

  const sys = createInitialCustomerSystemState(10, false);
  const spawned = [];
  for (let i = 0; i < 10; i++) {
    const c = spawnCustomer(sys);
    assert.ok(c);
    spawned.push(c);
  }

  const distinctArchetypes = new Set(spawned.map((c) => c.appearance.archetypeId));
  const distinctOutfits = new Set(spawned.map((c) => c.appearance.outfitType));
  const distinctHairStyles = new Set(spawned.map((c) => c.appearance.hairStyle));
  const distinctSkinTones = new Set(spawned.map((c) => c.appearance.skinToneHex));

  assert.ok(distinctArchetypes.size >= 6);
  assert.ok(distinctOutfits.size >= 5);
  assert.ok(distinctHairStyles.size >= 5);
  assert.ok(distinctSkinTones.size >= 4);

  // Verify no two consecutive customers have the exact same archetype or shirt color
  for (let i = 1; i < spawned.length; i++) {
    const prev = spawned[i - 1].appearance;
    const curr = spawned[i].appearance;
    assert.notEqual(curr.archetypeId, prev.archetypeId);
    assert.notEqual(curr.shirtColorHex, prev.shirtColorHex);
  }

  // Also test explicit anti-duplicate fallback when same seed index is passed twice in a row
  const appA = createCustomerAppearance(3, null);
  const appB = createCustomerAppearance(3, appA);
  assert.notEqual(appB.archetypeId, appA.archetypeId);
  assert.notEqual(appB.shirtColorHex, appA.shirtColorHex);
});

test('Phase 4 Save/Load Validation: Recovers safely from corrupted, missing, or negative data and preserves upgrades & settings', () => {
  // 1. Null / corrupted input falls back to safe defaults
  const fromNull = sanitizeSavedProgress(null);
  assert.equal(fromNull.coins, 50);
  assert.equal(fromNull.customerLimit, 5);
  assert.deepEqual(fromNull.upgrades, { moreCustomers: false, discount50: false });
  assert.deepEqual(fromNull.inventory, SAFE_DEFAULT_INVENTORY);

  // 2. Negative coins and negative/NaN inventory values are rejected and replaced with safe defaults
  const corrupted = sanitizeSavedProgress({
    coins: -999,
    upgrades: { moreCustomers: true, discount50: true },
    inventory: {
      emptyPlates: -5,
      sukhi_puri: NaN,
      aloo: 420.9,
      sev: 'invalid',
    },
    completedPlatesCount: -10,
  });
  assert.equal(corrupted.coins, 50); // negative coins recovered to default 50
  assert.equal(corrupted.customerLimit, 10); // derived from moreCustomers: true
  assert.equal(corrupted.upgrades.moreCustomers, true);
  assert.equal(corrupted.upgrades.discount50, true);
  assert.equal(corrupted.inventory.emptyPlates, SAFE_DEFAULT_INVENTORY.emptyPlates);
  assert.equal(corrupted.inventory.sukhi_puri, SAFE_DEFAULT_INVENTORY.sukhi_puri);
  assert.equal(corrupted.inventory.aloo, 420); // floored valid integer
  assert.equal(corrupted.inventory.sev, SAFE_DEFAULT_INVENTORY.sev);
  assert.equal(corrupted.completedPlatesCount, 0);

  // 3. Settings sanitization preserves sfxEnabled and clamps volume
  const cleanSettings = sanitizeSettings({
    volume: 150,
    muted: false,
    sfxEnabled: false,
    lookSensitivity: 9.9,
    invertY: true,
  });
  assert.equal(cleanSettings.volume, 100);
  assert.equal(cleanSettings.sfxEnabled, false);
  assert.equal(cleanSettings.lookSensitivity, 2.5);
  assert.equal(cleanSettings.invertY, true);
});

test('Phase 4.5: Expanded 1.5x Stall workstations, 6 spaced ingredient containers, and 10 NPC queue slots operate cleanly', () => {
  const state = createInitialFoodPrepState();

  // Verify wider spacing across the 6 ingredient containers (~3.10m total span, >= 0.60m between adjacent containers)
  const xs = [
    STALL_HOME_POSITIONS.jeera_jal.x,
    STALL_HOME_POSITIONS.sweet_chatni.x,
    STALL_HOME_POSITIONS.aloo.x,
    STALL_HOME_POSITIONS.curd.x,
    STALL_HOME_POSITIONS.sev.x,
    STALL_HOME_POSITIONS.sukhi_puri.x,
  ];
  for (let i = 1; i < xs.length; i++) {
    assert.ok(xs[i] - xs[i - 1] >= 0.6, `Adjacent containers must have >= 0.6m spacing (got ${xs[i] - xs[i - 1]})`);
  }

  // Verify front row workstations (Plate Stack on left, Prep Counter in center, Serving Area on right)
  assert.ok(PLATE_STACK_POSITION.x < PREP_COUNTER_POSITION.x - 1.2);
  assert.ok(SERVING_AREA_POSITION.x > PREP_COUNTER_POSITION.x + 1.2);

  // Verify picking up and returning every single container on the expanded stall counter works
  const containerIds = ['jeera_jal', 'sweet_chatni', 'aloo', 'curd', 'sev', 'sukhi_puri'] as const;
  for (const cid of containerIds) {
    state.aimedTarget = cid;
    performPickOrDrop(state, 4.5, -2.5, 0);
    assert.equal(state.heldItem, cid);

    // Return to stall counter home position
    state.aimedTarget = 'prep_counter';
    performPickOrDrop(state, 4.5, -2.5, 0);
    assert.equal(state.heldItem, null);
    assert.equal(state.containerPlacements[cid].onStallCounter, true);
    assert.equal(state.containerPlacements[cid].x, STALL_HOME_POSITIONS[cid].x);
  }

  // Verify 10 queue slots and expanded city-edge routes
  assert.equal(QUEUE_SLOTS.length, 10);
  assert.ok(CITY_EDGE_SPAWN_ROUTES.length >= 8);
  assert.ok(CUSTOMER_EXIT_WAYPOINTS.length >= 3);
});




