import * as THREE from 'three';
import {
  CustomerEntity,
  CustomerSystemState,
} from './customerSystem';
import { RECIPES } from './recipes';

export interface CustomerWorldRig {
  rootGroup: THREE.Group;
  raycastTargets: THREE.Object3D[];
  syncWithCustomers: (
    customerSystem: CustomerSystemState,
    camera: THREE.Camera,
    dt: number,
    elapsedTime: number
  ) => void;
  dispose: () => void;
}

interface CharacterNodeRig {
  customerId: string;
  root: THREE.Group;
  bodyPivot: THREE.Group;
  spinePivot: THREE.Group;
  headGroup: THREE.Group;
  leftBrow: THREE.Mesh;
  rightBrow: THREE.Mesh;
  mouthMesh: THREE.Mesh;
  leftShoulderPivot: THREE.Group;
  leftElbowPivot: THREE.Group;
  rightShoulderPivot: THREE.Group;
  rightElbowPivot: THREE.Group;
  leftHipPivot: THREE.Group;
  leftKneePivot: THREE.Group;
  rightHipPivot: THREE.Group;
  rightKneePivot: THREE.Group;
  eatingPlateGroup: THREE.Group;
  heldPuriMesh: THREE.Mesh;
  happyStarRing: THREE.Mesh;
  materials: THREE.Material[];
}

const STALL_LOOK_TARGET_X = 4.55;
const STALL_LOOK_TARGET_Z = -4.25;

function normalizeAngleDiff(angle: number): number {
  let a = angle;
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function dampValue(current: number, target: number, factor: number): number {
  return current + (target - current) * factor;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
    grad.addColorStop(0, 'rgba(15, 23, 42, 0.52)');
    grad.addColorStop(0.65, 'rgba(15, 23, 42, 0.18)');
    grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Shared low-poly human character geometries reused across all NPC customers
 * to keep draw overhead and GPU memory lightweight on mobile browsers.
 */
interface SharedCharacterGeometries {
  shadowGeo: THREE.PlaneGeometry;
  pelvisGeo: THREE.CylinderGeometry;
  beltGeo: THREE.CylinderGeometry;
  buckleGeo: THREE.BoxGeometry;
  abdomenGeo: THREE.CylinderGeometry;
  chestGeo: THREE.CylinderGeometry;
  shoulderCapGeo: THREE.SphereGeometry;
  collarRingGeo: THREE.TorusGeometry;
  shirtCollarGeo: THREE.CylinderGeometry;
  mandarinCollarGeo: THREE.CylinderGeometry;
  placketGeo: THREE.BoxGeometry;
  jacketShellGeo: THREE.CylinderGeometry;
  dressSkirtGeo: THREE.CylinderGeometry;
  kurtaSkirtGeo: THREE.CylinderGeometry;
  sashGeo: THREE.CylinderGeometry;
  neckGeo: THREE.CylinderGeometry;
  headGeo: THREE.SphereGeometry;
  jawGeo: THREE.CylinderGeometry;
  eyeWhiteGeo: THREE.SphereGeometry;
  pupilGeo: THREE.SphereGeometry;
  browGeo: THREE.BoxGeometry;
  noseGeo: THREE.ConeGeometry;
  smileGeo: THREE.TorusGeometry;
  earGeo: THREE.SphereGeometry;
  upperArmGeo: THREE.CylinderGeometry;
  elbowJointGeo: THREE.SphereGeometry;
  forearmGeo: THREE.CylinderGeometry;
  handPalmGeo: THREE.SphereGeometry;
  thumbGeo: THREE.CylinderGeometry;
  hipJointGeo: THREE.SphereGeometry;
  thighGeo: THREE.CylinderGeometry;
  kneeJointGeo: THREE.SphereGeometry;
  shinGeo: THREE.CylinderGeometry;
  shoeUpperGeo: THREE.BoxGeometry;
  shoeToeGeo: THREE.CylinderGeometry;
  shoeSoleGeo: THREE.BoxGeometry;
  hairCapGeo: THREE.SphereGeometry;
  hairCrestGeo: THREE.SphereGeometry;
  hairSideburnGeo: THREE.BoxGeometry;
  hairSweepGeo: THREE.SphereGeometry;
  hairBunGeo: THREE.SphereGeometry;
  hairCurlGeo: THREE.SphereGeometry;
  hairPonyGeo: THREE.ConeGeometry;
  hairBobSideGeo: THREE.SphereGeometry;
  glassesLensRimGeo: THREE.TorusGeometry;
  glassesBridgeGeo: THREE.BoxGeometry;
  glassesTempleGeo: THREE.BoxGeometry;
  visorCapDomeGeo: THREE.SphereGeometry;
  visorBrimGeo: THREE.CylinderGeometry;
  dupattaLoopGeo: THREE.TorusGeometry;
  dupattaTailGeo: THREE.BoxGeometry;
  headphoneBandGeo: THREE.TorusGeometry;
  headphoneCupGeo: THREE.CylinderGeometry;
  miniPlateGeo: THREE.CylinderGeometry;
  miniPuriGeo: THREE.SphereGeometry;
  starRingGeo: THREE.TorusGeometry;
}

function createSharedCharacterGeometries(): SharedCharacterGeometries {
  const shadowGeo = new THREE.PlaneGeometry(0.84, 0.84);
  shadowGeo.rotateX(-Math.PI / 2);

  // Connected Pelvis, Waist & V-Tapered Human Torso
  const pelvisGeo = new THREE.CylinderGeometry(0.156, 0.148, 0.14, 14);
  const beltGeo = new THREE.CylinderGeometry(0.162, 0.162, 0.044, 14);
  const buckleGeo = new THREE.BoxGeometry(0.055, 0.046, 0.025);

  const abdomenGeo = new THREE.CylinderGeometry(0.16, 0.155, 0.22, 14);
  const chestGeo = new THREE.CylinderGeometry(0.188, 0.16, 0.30, 14);
  const shoulderCapGeo = new THREE.SphereGeometry(0.066, 10, 10);

  // Outfit Details: Collars, Plackets, Open-Front Jacket Shell, Dresses, Kurtas
  const collarRingGeo = new THREE.TorusGeometry(0.078, 0.016, 8, 16);
  collarRingGeo.rotateX(Math.PI / 2);

  const shirtCollarGeo = new THREE.CylinderGeometry(0.088, 0.082, 0.052, 12, 1, true);
  const mandarinCollarGeo = new THREE.CylinderGeometry(0.082, 0.084, 0.048, 12);
  const placketGeo = new THREE.BoxGeometry(0.034, 0.32, 0.02);

  // Smooth open-front jacket shell wrapping around sides and back, leaving center +Z open to show inner shirt
  const jacketShellGeo = new THREE.CylinderGeometry(
    0.198,
    0.172,
    0.44,
    16,
    1,
    false,
    Math.PI * 0.18,
    Math.PI * 1.64
  );

  const dressSkirtGeo = new THREE.CylinderGeometry(0.158, 0.255, 0.36, 16);
  const kurtaSkirtGeo = new THREE.CylinderGeometry(0.162, 0.215, 0.34, 14);
  const sashGeo = new THREE.CylinderGeometry(0.164, 0.168, 0.055, 14);

  // Neck, Sculpted Head & Facial Features
  const neckGeo = new THREE.CylinderGeometry(0.062, 0.074, 0.11, 12);
  const headGeo = new THREE.SphereGeometry(0.158, 16, 14);
  const jawGeo = new THREE.CylinderGeometry(0.132, 0.095, 0.11, 12);

  const eyeWhiteGeo = new THREE.SphereGeometry(0.025, 10, 8);
  eyeWhiteGeo.scale(1.15, 0.88, 0.55);
  const pupilGeo = new THREE.SphereGeometry(0.014, 8, 8);
  pupilGeo.scale(1.0, 1.0, 0.6);
  const browGeo = new THREE.BoxGeometry(0.044, 0.011, 0.014);

  const noseGeo = new THREE.ConeGeometry(0.02, 0.054, 6);
  noseGeo.rotateX(Math.PI * 0.46);
  const smileGeo = new THREE.TorusGeometry(0.035, 0.008, 6, 12, Math.PI);
  smileGeo.rotateX(Math.PI);
  const earGeo = new THREE.SphereGeometry(0.03, 8, 8);
  earGeo.scale(0.65, 1.15, 0.8);

  // Articulated Multi-Joint Arms & Hands
  const upperArmGeo = new THREE.CylinderGeometry(0.056, 0.048, 0.22, 10);
  const elbowJointGeo = new THREE.SphereGeometry(0.047, 10, 8);
  const forearmGeo = new THREE.CylinderGeometry(0.046, 0.038, 0.20, 10);
  const handPalmGeo = new THREE.SphereGeometry(0.044, 10, 8);
  handPalmGeo.scale(0.85, 1.12, 0.68);
  const thumbGeo = new THREE.CylinderGeometry(0.013, 0.011, 0.042, 6);

  // Articulated Multi-Joint Legs & Shoes
  const hipJointGeo = new THREE.SphereGeometry(0.068, 10, 8);
  const thighGeo = new THREE.CylinderGeometry(0.068, 0.056, 0.26, 10);
  const kneeJointGeo = new THREE.SphereGeometry(0.054, 10, 8);
  const shinGeo = new THREE.CylinderGeometry(0.054, 0.044, 0.25, 10);
  const shoeUpperGeo = new THREE.BoxGeometry(0.105, 0.065, 0.17);
  const shoeToeGeo = new THREE.CylinderGeometry(0.052, 0.052, 0.062, 10);
  shoeToeGeo.rotateX(Math.PI / 2);
  const shoeSoleGeo = new THREE.BoxGeometry(0.112, 0.022, 0.215);

  // 6 Distinct Low-Poly 3D Hairstyles (Tilted backward so forehead and face are 100% clear)
  const hairCapGeo = new THREE.SphereGeometry(0.165, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.52);
  const hairCrestGeo = new THREE.SphereGeometry(0.075, 10, 8);
  hairCrestGeo.scale(1.35, 0.55, 1.15);
  const hairSideburnGeo = new THREE.BoxGeometry(0.022, 0.075, 0.042);
  const hairSweepGeo = new THREE.SphereGeometry(0.082, 10, 8);
  hairSweepGeo.scale(1.45, 0.62, 1.1);
  const hairBunGeo = new THREE.SphereGeometry(0.074, 10, 10);
  const hairCurlGeo = new THREE.SphereGeometry(0.052, 8, 8);
  const hairPonyGeo = new THREE.ConeGeometry(0.058, 0.21, 10);
  hairPonyGeo.rotateX(Math.PI * 0.76);
  const hairBobSideGeo = new THREE.SphereGeometry(0.068, 10, 8);
  hairBobSideGeo.scale(0.48, 1.45, 1.05);

  // Open-frame Eyeglasses & Accessories
  const glassesLensRimGeo = new THREE.TorusGeometry(0.03, 0.005, 6, 14);
  const glassesBridgeGeo = new THREE.BoxGeometry(0.028, 0.008, 0.01);
  const glassesTempleGeo = new THREE.BoxGeometry(0.008, 0.008, 0.13);

  const visorCapDomeGeo = new THREE.SphereGeometry(0.168, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.44);
  const visorBrimGeo = new THREE.CylinderGeometry(0.162, 0.162, 0.014, 12, 1, false, -Math.PI * 0.32, Math.PI * 0.64);

  const dupattaLoopGeo = new THREE.TorusGeometry(0.145, 0.032, 8, 16);
  dupattaLoopGeo.rotateX(Math.PI / 2);
  const dupattaTailGeo = new THREE.BoxGeometry(0.072, 0.34, 0.022);

  const headphoneBandGeo = new THREE.TorusGeometry(0.172, 0.016, 8, 18, Math.PI);
  const headphoneCupGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.032, 10);
  headphoneCupGeo.rotateZ(Math.PI / 2);

  // Props
  const miniPlateGeo = new THREE.CylinderGeometry(0.11, 0.085, 0.02, 12);
  const miniPuriGeo = new THREE.SphereGeometry(0.028, 8, 6);
  const starRingGeo = new THREE.TorusGeometry(0.32, 0.018, 8, 20);
  starRingGeo.rotateX(Math.PI / 2);

  return {
    shadowGeo,
    pelvisGeo,
    beltGeo,
    buckleGeo,
    abdomenGeo,
    chestGeo,
    shoulderCapGeo,
    collarRingGeo,
    shirtCollarGeo,
    mandarinCollarGeo,
    placketGeo,
    jacketShellGeo,
    dressSkirtGeo,
    kurtaSkirtGeo,
    sashGeo,
    neckGeo,
    headGeo,
    jawGeo,
    eyeWhiteGeo,
    pupilGeo,
    browGeo,
    noseGeo,
    smileGeo,
    earGeo,
    upperArmGeo,
    elbowJointGeo,
    forearmGeo,
    handPalmGeo,
    thumbGeo,
    hipJointGeo,
    thighGeo,
    kneeJointGeo,
    shinGeo,
    shoeUpperGeo,
    shoeToeGeo,
    shoeSoleGeo,
    hairCapGeo,
    hairCrestGeo,
    hairSideburnGeo,
    hairSweepGeo,
    hairBunGeo,
    hairCurlGeo,
    hairPonyGeo,
    hairBobSideGeo,
    glassesLensRimGeo,
    glassesBridgeGeo,
    glassesTempleGeo,
    visorCapDomeGeo,
    visorBrimGeo,
    dupattaLoopGeo,
    dupattaTailGeo,
    headphoneBandGeo,
    headphoneCupGeo,
    miniPlateGeo,
    miniPuriGeo,
    starRingGeo,
  };
}

/**
 * Builds a complete, cohesive 3D low-poly human character with connected pelvis, waist, V-tapered chest,
 * outfit-specific clothing meshes (T-shirt, collared shirt, summer dress, layered jacket, kurta tunic, polo),
 * sculpted head & facial features, 6 hairstyles, accessories, and multi-joint arms & legs.
 */
function buildCustomerCharacterNode(
  customer: CustomerEntity,
  sharedGeo: SharedCharacterGeometries,
  shadowMat: THREE.Material
): CharacterNodeRig {
  const root = new THREE.Group();
  root.name = `Customer_${customer.id}`;

  const materials: THREE.Material[] = [];
  const app = customer.appearance;

  const skinMat = new THREE.MeshStandardMaterial({
    color: app.skinToneHex,
    roughness: 0.62,
    metalness: 0.04,
  });
  const shirtMat = new THREE.MeshStandardMaterial({
    color: app.shirtColorHex,
    roughness: 0.55,
    metalness: 0.06,
  });
  const outerwearMat = new THREE.MeshStandardMaterial({
    color: app.outerwearColorHex ?? 0x1e293b,
    roughness: 0.52,
    metalness: 0.08,
  });
  const bottomMat = new THREE.MeshStandardMaterial({
    color: app.bottomColorHex,
    roughness: 0.7,
    metalness: 0.05,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: app.hairColorHex,
    roughness: 0.76,
    metalness: 0.06,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: app.accentColorHex,
    roughness: 0.42,
    metalness: 0.18,
  });
  const eyeWhiteMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.25,
  });
  const featureDarkMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.28,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: app.shoeColorHex ?? 0x1c1917,
    roughness: 0.58,
  });
  const soleMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    roughness: 0.65,
  });
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.25,
    metalness: 0.8,
  });
  const puriMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.48,
  });
  const starGlowMat = new THREE.MeshBasicMaterial({
    color: 0xfacc15,
  });

  materials.push(
    skinMat,
    shirtMat,
    outerwearMat,
    bottomMat,
    hairMat,
    accentMat,
    eyeWhiteMat,
    featureDarkMat,
    shoeMat,
    soleMat,
    steelMat,
    puriMat,
    starGlowMat
  );

  // Contact shadow on ground
  const shadowMesh = new THREE.Mesh(sharedGeo.shadowGeo, shadowMat);
  shadowMesh.position.y = 0.02;
  root.add(shadowMesh);

  // Main body container scaled to human height (~1.76m) with character-specific build & height
  const bodyPivot = new THREE.Group();
  bodyPivot.scale.set(
    app.buildScale * 1.15,
    app.heightScale * 1.19,
    app.buildScale * 1.15
  );
  root.add(bodyPivot);

  const outfit = app.outfitType ?? 'tshirt_trousers';
  const isDress = outfit === 'summer_dress';
  const isKurta = outfit === 'kurta_churidar';
  const isJacket = outfit === 'jacket_jeans';
  const isCollaredShirt = outfit === 'shirt_trousers' || outfit === 'polo_chinos';

  // 1. Connected Pelvis & Waist
  const pelvisMesh = new THREE.Mesh(
    sharedGeo.pelvisGeo,
    isDress ? shirtMat : bottomMat
  );
  pelvisMesh.position.y = 0.58;
  pelvisMesh.castShadow = true;
  bodyPivot.add(pelvisMesh);

  // 2. Spine & Upper Torso Pivot (at waist height y = 0.64)
  const spinePivot = new THREE.Group();
  spinePivot.position.set(0, 0.64, 0);
  bodyPivot.add(spinePivot);

  const abdomenMesh = new THREE.Mesh(sharedGeo.abdomenGeo, shirtMat);
  abdomenMesh.position.y = 0.11;
  abdomenMesh.scale.set(1.04, 1.0, 0.86);
  abdomenMesh.castShadow = true;
  spinePivot.add(abdomenMesh);

  const chestMesh = new THREE.Mesh(sharedGeo.chestGeo, shirtMat);
  chestMesh.position.y = 0.32;
  chestMesh.scale.set(1.08, 1.0, 0.86);
  chestMesh.castShadow = true;
  spinePivot.add(chestMesh);

  // Distinct Clothing Silhouettes
  if (isDress) {
    // Flared A-line summer dress skirt + decorative waist sash
    const dressSkirt = new THREE.Mesh(sharedGeo.dressSkirtGeo, shirtMat);
    dressSkirt.position.y = -0.14;
    dressSkirt.castShadow = true;
    const sash = new THREE.Mesh(sharedGeo.sashGeo, accentMat);
    sash.position.y = 0.02;
    const neckline = new THREE.Mesh(sharedGeo.collarRingGeo, accentMat);
    neckline.position.y = 0.46;
    spinePivot.add(dressSkirt, sash, neckline);
  } else if (isKurta) {
    // Long traditional Kurta tunic skirt + mandarin collar + embroidered placket
    const kurtaSkirt = new THREE.Mesh(sharedGeo.kurtaSkirtGeo, shirtMat);
    kurtaSkirt.position.y = -0.12;
    kurtaSkirt.castShadow = true;
    const mandarinCollar = new THREE.Mesh(sharedGeo.mandarinCollarGeo, accentMat);
    mandarinCollar.position.y = 0.48;
    const placket = new THREE.Mesh(sharedGeo.placketGeo, accentMat);
    placket.position.set(0, 0.30, 0.145);
    spinePivot.add(kurtaSkirt, mandarinCollar, placket);
  } else {
    // Belt & Buckle for trousers / jeans / chinos
    const belt = new THREE.Mesh(sharedGeo.beltGeo, shoeMat);
    belt.position.y = 0.0;
    belt.scale.set(1.04, 1.0, 0.88);
    const buckle = new THREE.Mesh(sharedGeo.buckleGeo, accentMat);
    buckle.position.set(0, 0.0, 0.145);
    spinePivot.add(belt, buckle);

    if (isJacket) {
      // Smooth open-front layered street jacket over contrasting inner shirt
      const jacketShell = new THREE.Mesh(sharedGeo.jacketShellGeo, outerwearMat);
      jacketShell.position.y = 0.24;
      jacketShell.scale.set(1.09, 1.0, 0.89);
      jacketShell.castShadow = true;
      const jacketCollar = new THREE.Mesh(sharedGeo.shirtCollarGeo, outerwearMat);
      jacketCollar.position.y = 0.48;
      spinePivot.add(jacketShell, jacketCollar);
    } else if (isCollaredShirt) {
      const collar = new THREE.Mesh(sharedGeo.shirtCollarGeo, outerwearMat);
      collar.position.y = 0.48;
      const placket = new THREE.Mesh(sharedGeo.placketGeo, outerwearMat);
      placket.position.set(0, 0.29, 0.145);
      spinePivot.add(collar, placket);
    } else {
      // Crew neck T-shirt collar ring
      const collarRing = new THREE.Mesh(sharedGeo.collarRingGeo, accentMat);
      collarRing.position.y = 0.46;
      spinePivot.add(collarRing);
    }
  }

  // 3. Connected Neck & Sculpted Human Head (attached to spinePivot)
  const neckMesh = new THREE.Mesh(sharedGeo.neckGeo, skinMat);
  neckMesh.position.y = 0.51;
  spinePivot.add(neckMesh);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.65, 0);
  spinePivot.add(headGroup);

  const headMesh = new THREE.Mesh(sharedGeo.headGeo, skinMat);
  headMesh.scale.set(0.95, 1.04, 0.98);
  headMesh.castShadow = true;
  headGroup.add(headMesh);

  const jawMesh = new THREE.Mesh(sharedGeo.jawGeo, skinMat);
  jawMesh.position.set(0, -0.065, 0.016);
  jawMesh.scale.set(0.94, 1.0, 0.90);
  headGroup.add(jawMesh);

  // Expressive Eyes (Sclera + Iris/Pupil) & Eyebrows on +Z face
  const leftEyeWhite = new THREE.Mesh(sharedGeo.eyeWhiteGeo, eyeWhiteMat);
  leftEyeWhite.position.set(-0.054, 0.022, 0.142);
  const rightEyeWhite = new THREE.Mesh(sharedGeo.eyeWhiteGeo, eyeWhiteMat);
  rightEyeWhite.position.set(0.054, 0.022, 0.142);

  const leftPupil = new THREE.Mesh(sharedGeo.pupilGeo, featureDarkMat);
  leftPupil.position.set(-0.054, 0.022, 0.155);
  const rightPupil = new THREE.Mesh(sharedGeo.pupilGeo, featureDarkMat);
  rightPupil.position.set(0.054, 0.022, 0.155);

  const leftBrow = new THREE.Mesh(sharedGeo.browGeo, hairMat);
  leftBrow.position.set(-0.055, 0.058, 0.148);
  const rightBrow = new THREE.Mesh(sharedGeo.browGeo, hairMat);
  rightBrow.position.set(0.055, 0.058, 0.148);
  headGroup.add(leftEyeWhite, rightEyeWhite, leftPupil, rightPupil, leftBrow, rightBrow);

  // Sculpted Nose, Mouth & Ears
  const nose = new THREE.Mesh(sharedGeo.noseGeo, skinMat);
  nose.position.set(0, -0.006, 0.166);
  const mouthMesh = new THREE.Mesh(sharedGeo.smileGeo, featureDarkMat);
  mouthMesh.position.set(0, -0.054, 0.146);
  const leftEar = new THREE.Mesh(sharedGeo.earGeo, skinMat);
  leftEar.position.set(-0.152, 0.0, -0.005);
  const rightEar = new THREE.Mesh(sharedGeo.earGeo, skinMat);
  rightEar.position.set(0.152, 0.0, -0.005);
  headGroup.add(nose, mouthMesh, leftEar, rightEar);

  // 4. 6 Distinct 3D Hairstyles (tilted backward by -0.35 rad so forehead & face are 100% open)
  const hairCap = new THREE.Mesh(sharedGeo.hairCapGeo, hairMat);
  hairCap.position.set(0, 0.02, -0.01);
  hairCap.rotation.x = -0.36;
  hairCap.scale.set(0.97, 1.03, 1.01);
  headGroup.add(hairCap);

  if (app.hairStyle === 'short_parted') {
    const crest = new THREE.Mesh(sharedGeo.hairCrestGeo, hairMat);
    crest.position.set(0.02, 0.148, 0.045);
    crest.rotation.z = -0.14;
    const sbL = new THREE.Mesh(sharedGeo.hairSideburnGeo, hairMat);
    sbL.position.set(-0.146, 0.02, 0.015);
    const sbR = new THREE.Mesh(sharedGeo.hairSideburnGeo, hairMat);
    sbR.position.set(0.146, 0.02, 0.015);
    headGroup.add(crest, sbL, sbR);
  } else if (app.hairStyle === 'bun') {
    const bun = new THREE.Mesh(sharedGeo.hairBunGeo, hairMat);
    bun.position.set(0, 0.115, -0.155);
    const band = new THREE.Mesh(sharedGeo.collarRingGeo, accentMat);
    band.scale.set(0.68, 0.68, 0.68);
    band.position.set(0, 0.10, -0.12);
    band.rotation.x = Math.PI * 0.35;
    headGroup.add(bun, band);
  } else if (app.hairStyle === 'curly_top') {
    const curlPositions: [number, number, number][] = [
      [-0.055, 0.155, 0.04],
      [0.055, 0.155, 0.04],
      [0.0, 0.168, -0.01],
      [-0.06, 0.145, -0.05],
      [0.06, 0.145, -0.05],
    ];
    for (const [cx, cy, cz] of curlPositions) {
      const curl = new THREE.Mesh(sharedGeo.hairCurlGeo, hairMat);
      curl.position.set(cx, cy, cz);
      headGroup.add(curl);
    }
  } else if (app.hairStyle === 'ponytail') {
    const pony = new THREE.Mesh(sharedGeo.hairPonyGeo, hairMat);
    pony.position.set(0, 0.01, -0.20);
    const tie = new THREE.Mesh(sharedGeo.hairCurlGeo, accentMat);
    tie.scale.set(0.6, 0.6, 0.6);
    tie.position.set(0, 0.06, -0.15);
    headGroup.add(pony, tie);
  } else if (app.hairStyle === 'side_sweep') {
    const sweep = new THREE.Mesh(sharedGeo.hairSweepGeo, hairMat);
    sweep.position.set(0.025, 0.148, 0.04);
    sweep.rotation.z = -0.22;
    const sbL = new THREE.Mesh(sharedGeo.hairSideburnGeo, hairMat);
    sbL.position.set(-0.146, 0.018, 0.015);
    const sbR = new THREE.Mesh(sharedGeo.hairSideburnGeo, hairMat);
    sbR.position.set(0.146, 0.018, 0.015);
    headGroup.add(sweep, sbL, sbR);
  } else if (app.hairStyle === 'bob_cut') {
    const bobL = new THREE.Mesh(sharedGeo.hairBobSideGeo, hairMat);
    bobL.position.set(-0.135, -0.01, -0.03);
    const bobR = new THREE.Mesh(sharedGeo.hairBobSideGeo, hairMat);
    bobR.position.set(0.135, -0.01, -0.03);
    headGroup.add(bobL, bobR);
  }

  // 5. Open-Frame Eyeglasses & Accessories
  if (app.accessory === 'glasses') {
    const rimL = new THREE.Mesh(sharedGeo.glassesLensRimGeo, accentMat);
    rimL.position.set(-0.054, 0.022, 0.158);
    const rimR = new THREE.Mesh(sharedGeo.glassesLensRimGeo, accentMat);
    rimR.position.set(0.054, 0.022, 0.158);
    const bridge = new THREE.Mesh(sharedGeo.glassesBridgeGeo, accentMat);
    bridge.position.set(0, 0.026, 0.158);
    const templeL = new THREE.Mesh(sharedGeo.glassesTempleGeo, featureDarkMat);
    templeL.position.set(-0.146, 0.024, 0.075);
    const templeR = new THREE.Mesh(sharedGeo.glassesTempleGeo, featureDarkMat);
    templeR.position.set(0.146, 0.024, 0.075);
    headGroup.add(rimL, rimR, bridge, templeL, templeR);
  } else if (app.accessory === 'cap') {
    const dome = new THREE.Mesh(sharedGeo.visorCapDomeGeo, accentMat);
    dome.position.set(0, 0.038, 0);
    dome.rotation.x = -0.15;
    const brim = new THREE.Mesh(sharedGeo.visorBrimGeo, accentMat);
    brim.position.set(0, 0.108, 0.055);
    brim.rotation.x = -0.08;
    headGroup.add(dome, brim);
  } else if (app.accessory === 'dupatta') {
    const loop = new THREE.Mesh(sharedGeo.dupattaLoopGeo, accentMat);
    loop.position.set(0, 0.45, 0);
    const tailL = new THREE.Mesh(sharedGeo.dupattaTailGeo, accentMat);
    tailL.position.set(-0.10, 0.27, 0.142);
    tailL.rotation.z = 0.06;
    spinePivot.add(loop, tailL);
  } else if (app.accessory === 'headphones') {
    const band = new THREE.Mesh(sharedGeo.headphoneBandGeo, accentMat);
    band.position.set(0, 0.02, 0);
    const cupL = new THREE.Mesh(sharedGeo.headphoneCupGeo, outerwearMat);
    cupL.position.set(-0.168, 0.005, 0);
    const cupR = new THREE.Mesh(sharedGeo.headphoneCupGeo, outerwearMat);
    cupR.position.set(0.168, 0.005, 0);
    headGroup.add(band, cupL, cupR);
  }

  // 6. Multi-Joint Articulated Arms (Shoulder -> Upper Arm -> Elbow -> Forearm -> Hand)
  const sleeveMaterial = isJacket ? outerwearMat : shirtMat;
  const forearmMaterial = isJacket || isKurta || outfit === 'shirt_trousers' ? sleeveMaterial : skinMat;

  // Left Arm
  const leftShoulderPivot = new THREE.Group();
  leftShoulderPivot.position.set(-0.215, 0.42, 0);
  spinePivot.add(leftShoulderPivot);

  const leftShoulderCap = new THREE.Mesh(sharedGeo.shoulderCapGeo, sleeveMaterial);
  const leftUpperArm = new THREE.Mesh(sharedGeo.upperArmGeo, sleeveMaterial);
  leftUpperArm.position.y = -0.11;
  leftUpperArm.castShadow = true;
  leftShoulderPivot.add(leftShoulderCap, leftUpperArm);

  const leftElbowPivot = new THREE.Group();
  leftElbowPivot.position.set(0, -0.21, 0);
  leftShoulderPivot.add(leftElbowPivot);

  const leftElbowJoint = new THREE.Mesh(sharedGeo.elbowJointGeo, forearmMaterial);
  const leftForearm = new THREE.Mesh(sharedGeo.forearmGeo, forearmMaterial);
  leftForearm.position.y = -0.10;
  const leftHandPalm = new THREE.Mesh(sharedGeo.handPalmGeo, skinMat);
  leftHandPalm.position.set(0, -0.21, 0.008);
  const leftThumb = new THREE.Mesh(sharedGeo.thumbGeo, skinMat);
  leftThumb.position.set(0.028, -0.195, 0.028);
  leftThumb.rotation.x = -0.45;
  leftElbowPivot.add(leftElbowJoint, leftForearm, leftHandPalm, leftThumb);

  // Mini served plate held in the left hand during EATING state
  const eatingPlateGroup = new THREE.Group();
  eatingPlateGroup.position.set(0.05, -0.22, 0.08);
  eatingPlateGroup.visible = false;
  const miniPlate = new THREE.Mesh(sharedGeo.miniPlateGeo, steelMat);
  const miniPuri1 = new THREE.Mesh(sharedGeo.miniPuriGeo, puriMat);
  miniPuri1.position.set(-0.032, 0.022, 0);
  const miniPuri2 = new THREE.Mesh(sharedGeo.miniPuriGeo, puriMat);
  miniPuri2.position.set(0.032, 0.022, 0.02);
  const miniPuri3 = new THREE.Mesh(sharedGeo.miniPuriGeo, puriMat);
  miniPuri3.position.set(0, 0.022, -0.028);
  eatingPlateGroup.add(miniPlate, miniPuri1, miniPuri2, miniPuri3);
  leftElbowPivot.add(eatingPlateGroup);

  // Right Arm
  const rightShoulderPivot = new THREE.Group();
  rightShoulderPivot.position.set(0.215, 0.42, 0);
  spinePivot.add(rightShoulderPivot);

  const rightShoulderCap = new THREE.Mesh(sharedGeo.shoulderCapGeo, sleeveMaterial);
  const rightUpperArm = new THREE.Mesh(sharedGeo.upperArmGeo, sleeveMaterial);
  rightUpperArm.position.y = -0.11;
  rightUpperArm.castShadow = true;
  rightShoulderPivot.add(rightShoulderCap, rightUpperArm);

  const rightElbowPivot = new THREE.Group();
  rightElbowPivot.position.set(0, -0.21, 0);
  rightShoulderPivot.add(rightElbowPivot);

  const rightElbowJoint = new THREE.Mesh(sharedGeo.elbowJointGeo, forearmMaterial);
  const rightForearm = new THREE.Mesh(sharedGeo.forearmGeo, forearmMaterial);
  rightForearm.position.y = -0.10;
  const rightHandPalm = new THREE.Mesh(sharedGeo.handPalmGeo, skinMat);
  rightHandPalm.position.set(0, -0.21, 0.008);
  const rightThumb = new THREE.Mesh(sharedGeo.thumbGeo, skinMat);
  rightThumb.position.set(-0.028, -0.195, 0.028);
  rightThumb.rotation.x = -0.45;
  rightElbowPivot.add(rightElbowJoint, rightForearm, rightHandPalm, rightThumb);

  // Puri held in the right fingers during the hand-to-mouth EATING gesture
  const heldPuriMesh = new THREE.Mesh(sharedGeo.miniPuriGeo, puriMat);
  heldPuriMesh.position.set(-0.015, -0.225, 0.035);
  heldPuriMesh.visible = false;
  rightElbowPivot.add(heldPuriMesh);

  // 7. Multi-Joint Articulated Legs (Hip -> Thigh -> Knee -> Shin/Calf -> Sculpted Shoe)
  const thighMaterial = isDress ? shirtMat : bottomMat;
  const shinMaterial = isDress ? skinMat : bottomMat;

  // Left Leg
  const leftHipPivot = new THREE.Group();
  leftHipPivot.position.set(-0.092, 0.56, 0);
  bodyPivot.add(leftHipPivot);

  const leftHipJoint = new THREE.Mesh(sharedGeo.hipJointGeo, thighMaterial);
  const leftThigh = new THREE.Mesh(sharedGeo.thighGeo, thighMaterial);
  leftThigh.position.y = -0.13;
  leftThigh.castShadow = true;
  leftHipPivot.add(leftHipJoint, leftThigh);

  const leftKneePivot = new THREE.Group();
  leftKneePivot.position.set(0, -0.26, 0);
  leftHipPivot.add(leftKneePivot);

  const leftKneeJoint = new THREE.Mesh(sharedGeo.kneeJointGeo, shinMaterial);
  const leftShin = new THREE.Mesh(sharedGeo.shinGeo, shinMaterial);
  leftShin.position.y = -0.125;
  const leftShoeUpper = new THREE.Mesh(sharedGeo.shoeUpperGeo, shoeMat);
  leftShoeUpper.position.set(0, -0.255, 0.025);
  const leftShoeToe = new THREE.Mesh(sharedGeo.shoeToeGeo, shoeMat);
  leftShoeToe.position.set(0, -0.262, 0.095);
  const leftShoeSole = new THREE.Mesh(sharedGeo.shoeSoleGeo, soleMat);
  leftShoeSole.position.set(0, -0.285, 0.032);
  leftKneePivot.add(leftKneeJoint, leftShin, leftShoeUpper, leftShoeToe, leftShoeSole);

  // Right Leg
  const rightHipPivot = new THREE.Group();
  rightHipPivot.position.set(0.092, 0.56, 0);
  bodyPivot.add(rightHipPivot);

  const rightHipJoint = new THREE.Mesh(sharedGeo.hipJointGeo, thighMaterial);
  const rightThigh = new THREE.Mesh(sharedGeo.thighGeo, thighMaterial);
  rightThigh.position.y = -0.13;
  rightThigh.castShadow = true;
  rightHipPivot.add(rightHipJoint, rightThigh);

  const rightKneePivot = new THREE.Group();
  rightKneePivot.position.set(0, -0.26, 0);
  rightHipPivot.add(rightKneePivot);

  const rightKneeJoint = new THREE.Mesh(sharedGeo.kneeJointGeo, shinMaterial);
  const rightShin = new THREE.Mesh(sharedGeo.shinGeo, shinMaterial);
  rightShin.position.y = -0.125;
  const rightShoeUpper = new THREE.Mesh(sharedGeo.shoeUpperGeo, shoeMat);
  rightShoeUpper.position.set(0, -0.255, 0.025);
  const rightShoeToe = new THREE.Mesh(sharedGeo.shoeToeGeo, shoeMat);
  rightShoeToe.position.set(0, -0.262, 0.095);
  const rightShoeSole = new THREE.Mesh(sharedGeo.shoeSoleGeo, soleMat);
  rightShoeSole.position.set(0, -0.285, 0.032);
  rightKneePivot.add(rightKneeJoint, rightShin, rightShoeUpper, rightShoeToe, rightShoeSole);

  // 8. Positive Celebration Golden Halo Ring (visible during 4-5 star REACTING state)
  const happyStarRing = new THREE.Mesh(sharedGeo.starRingGeo, starGlowMat);
  happyStarRing.position.set(0, 1.72, 0);
  happyStarRing.visible = false;
  bodyPivot.add(happyStarRing);

  return {
    customerId: customer.id,
    root,
    bodyPivot,
    spinePivot,
    headGroup,
    leftBrow,
    rightBrow,
    mouthMesh,
    leftShoulderPivot,
    leftElbowPivot,
    rightShoulderPivot,
    rightElbowPivot,
    leftHipPivot,
    leftKneePivot,
    rightHipPivot,
    rightKneePivot,
    eatingPlateGroup,
    heldPuriMesh,
    happyStarRing,
    materials,
  };
}

function drawStarShape(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  outerRadius: number,
  innerRadius: number,
  filled: boolean
): void {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? outerRadius : innerRadius;
    const angle = (i * Math.PI) / 5 - Math.PI / 2;
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  if (filled) {
    ctx.fillStyle = '#facc15';
    ctx.fill();
  } else {
    ctx.fillStyle = '#44403c';
    ctx.fill();
  }
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

/**
 * Draws the 3D overhead speech/order/patience/reaction badge onto a CanvasTexture.
 */
function renderOverheadBadgeCanvas(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  customer: CustomerEntity
): void {
  ctx.clearRect(0, 0, w, h);

  const isReactingOrEating = customer.state === 'EATING' || customer.state === 'REACTING';
  const borderColor =
    customer.reactionMood === 'very_happy' || customer.reactionMood === 'happy'
      ? '#4ade80'
      : customer.reactionMood === 'unhappy' || customer.reactionMood === 'disappointed'
        ? '#f87171'
        : '#fbbf24';

  // Rounded dark speech card
  ctx.fillStyle = 'rgba(12, 10, 9, 0.92)';
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.roundRect(8, 8, w - 16, h - 26, 18);
  ctx.fill();
  ctx.stroke();

  // Speech pointer triangle at bottom center
  ctx.fillStyle = borderColor;
  ctx.beginPath();
  ctx.moveTo(w / 2 - 14, h - 18);
  ctx.lineTo(w / 2 + 14, h - 18);
  ctx.lineTo(w / 2, h - 2);
  ctx.closePath();
  ctx.fill();

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  if (isReactingOrEating) {
    const stars = customer.starRating ?? 0;
    if (stars > 0) {
      const startX = 95;
      for (let i = 0; i < 5; i++) {
        drawStarShape(ctx, startX + i * 28, 42, 11, 5, i < stars);
      }
      ctx.fillStyle = stars >= 4 ? '#4ade80' : stars >= 3 ? '#facc15' : '#f87171';
      ctx.font = '800 24px "Outfit", system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`+${customer.coinsAwarded} COINS`, startX + 5 * 28 + 10, 43);
      ctx.textAlign = 'center';
    } else {
      ctx.fillStyle = '#f87171';
      ctx.font = '800 25px "Outfit", system-ui, sans-serif';
      ctx.fillText('PATIENCE EXPIRED! (0 COINS)', w / 2, 42);
    }

    ctx.fillStyle = '#fef3c7';
    ctx.font = '700 20px "Plus Jakarta Sans", system-ui, sans-serif';
    const text =
      customer.state === 'EATING'
        ? `${customer.name} is tasting the ${RECIPES[customer.orderRecipeId].name}...`
        : customer.reactionText || 'Thank you!';
    ctx.fillText(text, w / 2, 82);
    return;
  }

  // Active Ordering / Waiting for Food Badge
  const recipe = RECIPES[customer.orderRecipeId];
  ctx.fillStyle = '#fef08a';
  ctx.font = '800 26px "Outfit", system-ui, sans-serif';
  ctx.fillText(`${customer.name.toUpperCase()}: ${recipe.shortTitle}`, w / 2, 36);

  // Patience bar background
  const barX = 36;
  const barY = 66;
  const barW = w - 72;
  const barH = 18;
  const ratio = Math.max(0, Math.min(1, customer.patience / customer.maxPatience));

  ctx.fillStyle = '#292524';
  ctx.fillRect(barX, barY, barW, barH);

  ctx.fillStyle = ratio > 0.5 ? '#22c55e' : ratio > 0.25 ? '#f59e0b' : '#ef4444';
  ctx.fillRect(barX, barY, Math.round(barW * ratio), barH);

  ctx.strokeStyle = '#78716c';
  ctx.lineWidth = 2;
  ctx.strokeRect(barX, barY, barW, barH);

  ctx.fillStyle = '#f5f5f4';
  ctx.font = '700 15px "JetBrains Mono", monospace';
  ctx.fillText(`PATIENCE ${Math.round(ratio * 100)}%`, w / 2, 102);
}

/**
 * Creates the 3D NPC Customer World Rig that manages all active 3D human customer characters,
 * their articulated procedural animations, and the floating 3D speech/order/patience billboard.
 */
export function createCustomerWorldRig(maxAnisotropy: number): CustomerWorldRig {
  const rootGroup = new THREE.Group();
  rootGroup.name = 'CustomerWorldRig';

  const sharedGeo = createSharedCharacterGeometries();
  const shadowTex = createContactShadowTexture();
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity: 0.6,
    depthWrite: false,
  });

  const characterMap = new Map<string, CharacterNodeRig>();
  const raycastTargets: THREE.Object3D[] = [];

  // Active customer raycast hitbox at Slot 0 so aiming at the active customer also resolves to 'serving_area'
  const activeCustomerHitGeo = new THREE.CylinderGeometry(0.36, 0.36, 1.75, 10);
  const activeCustomerHitMat = new THREE.MeshBasicMaterial({
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  const activeCustomerHitbox = new THREE.Mesh(activeCustomerHitGeo, activeCustomerHitMat);
  activeCustomerHitbox.userData.interactiveId = 'serving_area';
  activeCustomerHitbox.visible = false;
  rootGroup.add(activeCustomerHitbox);
  raycastTargets.push(activeCustomerHitbox);

  // Floating 3D Speech Bubble / Order & Patience Indicator above the active customer
  const badgeCanvas = document.createElement('canvas');
  badgeCanvas.width = 448;
  badgeCanvas.height = 136;
  const badgeCtx = badgeCanvas.getContext('2d');
  const badgeTexture = new THREE.CanvasTexture(badgeCanvas);
  badgeTexture.colorSpace = THREE.SRGBColorSpace;
  badgeTexture.anisotropy = maxAnisotropy;

  const badgeGeo = new THREE.PlaneGeometry(1.55, 0.47);
  const badgeMat = new THREE.MeshBasicMaterial({
    map: badgeTexture,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const badgeMesh = new THREE.Mesh(badgeGeo, badgeMat);
  badgeMesh.visible = false;
  rootGroup.add(badgeMesh);

  let lastBadgeSignature = '';

  return {
    rootGroup,
    raycastTargets,
    syncWithCustomers: (
      customerSystem: CustomerSystemState,
      camera: THREE.Camera,
      dt: number,
      elapsedTime: number
    ) => {
      const activeIds = new Set<string>();
      const blend = Math.min(1, Math.max(0.18, dt * 12));

      // 1. Add or update each customer's articulated 3D human character rig
      for (const cust of customerSystem.customers) {
        activeIds.add(cust.id);
        let rig = characterMap.get(cust.id);
        if (!rig) {
          rig = buildCustomerCharacterNode(cust, sharedGeo, shadowMat);
          characterMap.set(cust.id, rig);
          rootGroup.add(rig.root);
        }

        rig.root.position.set(cust.x, 0, cust.z);
        rig.root.rotation.y = cust.yaw;

        const phase = cust.animPhase;
        const isWalking = cust.state === 'WALKING_TO_QUEUE' || cust.state === 'LEAVING';
        const isEating = cust.state === 'EATING';
        const isReacting = cust.state === 'REACTING';

        rig.eatingPlateGroup.visible = isEating;
        rig.heldPuriMesh.visible = isEating;
        rig.happyStarRing.visible =
          isReacting && (cust.reactionMood === 'very_happy' || cust.reactionMood === 'happy');

        // Target joint angles
        let targetBodyY = 0;
        let targetSpineX = 0;
        let targetSpineY = 0;
        let targetSpineZ = 0;
        let targetHeadX = 0;
        let targetHeadY = 0;
        let targetHeadZ = 0;

        let targetLShoulderX = 0;
        let targetLShoulderY = 0;
        let targetLShoulderZ = 0.05;
        let targetLElbowX = -0.18;

        let targetRShoulderX = 0;
        let targetRShoulderY = 0;
        let targetRShoulderZ = -0.05;
        let targetRElbowX = -0.18;

        let targetLHipX = 0;
        let targetLKneeX = 0;
        let targetRHipX = 0;
        let targetRKneeX = 0;

        let targetBrowTilt = 0;
        let targetMouthScaleY = 1.0;

        if (isWalking) {
          // Coordinated human gait: opposite hip/shoulder swing + realistic knee & elbow flexion
          const swing = Math.sin(phase) * 0.56;
          const liftL = Math.max(0, -Math.cos(phase));
          const liftR = Math.max(0, Math.cos(phase));

          targetLHipX = swing;
          targetLKneeX = liftL * 0.68;
          targetRHipX = -swing;
          targetRKneeX = liftR * 0.68;

          targetLShoulderX = -swing * 0.72;
          targetLElbowX = -0.26 - Math.max(0, -swing) * 0.38;
          targetRShoulderX = swing * 0.72;
          targetRElbowX = -0.26 - Math.max(0, swing) * 0.38;

          targetSpineY = -swing * 0.12;
          targetSpineX = 0.03;
          targetBodyY = Math.abs(Math.cos(phase)) * 0.04;
          targetHeadY = Math.sin(phase * 0.5) * 0.05;
        } else if (isEating) {
          // Believable hand-to-mouth eating animation:
          // Left arm holds the mini plate of puris steady in front of chest;
          // Right arm picks a puri from the plate and brings it up to the mouth while chewing.
          const eatWave = 0.5 + 0.5 * Math.sin(elapsedTime * 9.0);

          targetLShoulderX = -0.62;
          targetLShoulderY = 0.32;
          targetLShoulderZ = 0.08;
          targetLElbowX = -1.18;

          targetRShoulderX = -0.58 - eatWave * 0.68;
          targetRShoulderY = -0.34 - eatWave * 0.08;
          targetRShoulderZ = -0.12;
          targetRElbowX = -1.05 - eatWave * 0.48;

          targetHeadX = 0.12 - eatWave * 0.18;
          targetHeadY = -0.06;
          targetSpineX = 0.04;
          targetMouthScaleY = 0.75 + Math.abs(Math.sin(elapsedTime * 14.0)) * 0.65;
          targetBrowTilt = -0.08;
        } else if (isReacting) {
          if (cust.reactionMood === 'very_happy' || cust.reactionMood === 'happy') {
            // Enthusiastic 4-5 star celebration wave with bent elbows & happy bounce
            const cheer = Math.abs(Math.sin(elapsedTime * 8.5));
            targetLShoulderX = -2.15;
            targetLShoulderZ = -0.28 - cheer * 0.22;
            targetLElbowX = -0.55 - cheer * 0.25;

            targetRShoulderX = -2.15;
            targetRShoulderZ = 0.28 + cheer * 0.22;
            targetRElbowX = -0.55 - cheer * 0.25;

            targetBodyY = cheer * 0.085;
            targetHeadX = -0.10;
            targetHeadY = Math.sin(elapsedTime * 6.5) * 0.14;
            targetBrowTilt = -0.14;
            targetMouthScaleY = 1.25;
            rig.happyStarRing.rotation.z = elapsedTime * 3.5;
          } else if (cust.reactionMood === 'neutral') {
            // Polite 3-star nod and wave
            targetRShoulderX = -0.85;
            targetRElbowX = -0.95;
            targetHeadX = Math.sin(elapsedTime * 6.0) * 0.14;
          } else {
            // Disappointed / unhappy slumped shoulders and head shake
            targetSpineX = 0.14;
            targetLShoulderX = 0.12;
            targetLShoulderZ = 0.08;
            targetRShoulderX = 0.12;
            targetRShoulderZ = -0.08;
            targetHeadX = 0.18;
            targetHeadY = Math.sin(elapsedTime * 9.5) * 0.30;
            targetBrowTilt = 0.22;
            targetMouthScaleY = -0.85;
          }
        } else {
          // Idle / Waiting in Queue / Ordering:
          // Natural breathing, subtle weight shift, and looking toward the Pani Puri Stall
          const breath = Math.sin(phase) * 0.035;
          const weightShift = Math.sin(phase * 0.65) * 0.025;

          targetSpineX = breath * 0.4;
          targetSpineZ = weightShift;
          targetBodyY = Math.sin(phase * 1.6) * 0.01;

          // Orient head toward the Pani Puri Stall counter while waiting in queue
          const worldAngleToStall = Math.atan2(
            STALL_LOOK_TARGET_X - cust.x,
            STALL_LOOK_TARGET_Z - cust.z
          );
          const relYawToStall = THREE.MathUtils.clamp(
            normalizeAngleDiff(worldAngleToStall - cust.yaw),
            -0.55,
            0.55
          );
          targetHeadY = relYawToStall * 0.72 + Math.sin(phase * 0.7) * 0.06;
          targetHeadX = Math.cos(phase * 0.5) * 0.03;

          targetLShoulderX = breath;
          targetLShoulderZ = 0.06;
          targetLElbowX = -0.22;

          if (cust.state === 'ORDERING') {
            // Friendly greeting wave when placing order at the counter
            targetRShoulderX = -1.45;
            targetRShoulderZ = -0.22 - Math.sin(elapsedTime * 10.0) * 0.18;
            targetRElbowX = -0.75 + Math.cos(elapsedTime * 10.0) * 0.22;
          } else {
            targetRShoulderX = -breath;
            targetRShoulderZ = -0.06;
            targetRElbowX = -0.22;
          }
        }

        // Smoothly interpolate all joints so transitions never snap
        rig.bodyPivot.position.y = dampValue(rig.bodyPivot.position.y, targetBodyY, blend);
        rig.spinePivot.rotation.x = dampValue(rig.spinePivot.rotation.x, targetSpineX, blend);
        rig.spinePivot.rotation.y = dampValue(rig.spinePivot.rotation.y, targetSpineY, blend);
        rig.spinePivot.rotation.z = dampValue(rig.spinePivot.rotation.z, targetSpineZ, blend);

        rig.headGroup.rotation.x = dampValue(rig.headGroup.rotation.x, targetHeadX, blend);
        rig.headGroup.rotation.y = dampValue(rig.headGroup.rotation.y, targetHeadY, blend);
        rig.headGroup.rotation.z = dampValue(rig.headGroup.rotation.z, targetHeadZ, blend);

        rig.leftShoulderPivot.rotation.x = dampValue(rig.leftShoulderPivot.rotation.x, targetLShoulderX, blend);
        rig.leftShoulderPivot.rotation.y = dampValue(rig.leftShoulderPivot.rotation.y, targetLShoulderY, blend);
        rig.leftShoulderPivot.rotation.z = dampValue(rig.leftShoulderPivot.rotation.z, targetLShoulderZ, blend);
        rig.leftElbowPivot.rotation.x = dampValue(rig.leftElbowPivot.rotation.x, targetLElbowX, blend);

        rig.rightShoulderPivot.rotation.x = dampValue(rig.rightShoulderPivot.rotation.x, targetRShoulderX, blend);
        rig.rightShoulderPivot.rotation.y = dampValue(rig.rightShoulderPivot.rotation.y, targetRShoulderY, blend);
        rig.rightShoulderPivot.rotation.z = dampValue(rig.rightShoulderPivot.rotation.z, targetRShoulderZ, blend);
        rig.rightElbowPivot.rotation.x = dampValue(rig.rightElbowPivot.rotation.x, targetRElbowX, blend);

        rig.leftHipPivot.rotation.x = dampValue(rig.leftHipPivot.rotation.x, targetLHipX, blend);
        rig.leftKneePivot.rotation.x = dampValue(rig.leftKneePivot.rotation.x, targetLKneeX, blend);
        rig.rightHipPivot.rotation.x = dampValue(rig.rightHipPivot.rotation.x, targetRHipX, blend);
        rig.rightKneePivot.rotation.x = dampValue(rig.rightKneePivot.rotation.x, targetRKneeX, blend);

        rig.leftBrow.rotation.z = dampValue(rig.leftBrow.rotation.z, -targetBrowTilt, blend);
        rig.rightBrow.rotation.z = dampValue(rig.rightBrow.rotation.z, targetBrowTilt, blend);
        rig.mouthMesh.scale.y = dampValue(rig.mouthMesh.scale.y, targetMouthScaleY, blend);
      }

      // 2. Clean up despawned customers without memory leaks
      for (const [id, rig] of characterMap.entries()) {
        if (!activeIds.has(id)) {
          rootGroup.remove(rig.root);
          for (const m of rig.materials) m.dispose();
          characterMap.delete(id);
        }
      }

      // 3. Update Floating 3D Speech Bubble & Hitbox above the Active Customer (Slot 0)
      const frontCustomer = customerSystem.customers.find(
        (c) =>
          c.queueSlotIndex === 0 &&
          (c.state === 'ORDERING' ||
            c.state === 'WAITING_FOR_FOOD' ||
            c.state === 'EATING' ||
            c.state === 'REACTING')
      );

      if (frontCustomer && badgeCtx) {
        badgeMesh.visible = true;
        badgeMesh.position.set(
          frontCustomer.x,
          1.92 + Math.sin(elapsedTime * 3.2) * 0.025,
          frontCustomer.z
        );
        badgeMesh.lookAt(camera.position.x, badgeMesh.position.y, camera.position.z);

        activeCustomerHitbox.visible = true;
        activeCustomerHitbox.position.set(frontCustomer.x, 0.88, frontCustomer.z);

        const patienceBucket = Math.ceil(frontCustomer.patience);
        const sig = `${frontCustomer.id}:${frontCustomer.state}:${frontCustomer.orderRecipeId}:${patienceBucket}:${frontCustomer.starRating ?? -1}`;
        if (sig !== lastBadgeSignature) {
          lastBadgeSignature = sig;
          renderOverheadBadgeCanvas(
            badgeCtx,
            badgeCanvas.width,
            badgeCanvas.height,
            frontCustomer
          );
          badgeTexture.needsUpdate = true;
        }
      } else {
        badgeMesh.visible = false;
        activeCustomerHitbox.visible = false;
        lastBadgeSignature = '';
      }
    },
    dispose: () => {
      for (const rig of characterMap.values()) {
        for (const m of rig.materials) m.dispose();
      }
      characterMap.clear();
      for (const g of Object.values(sharedGeo)) {
        g.dispose();
      }
      activeCustomerHitGeo.dispose();
      activeCustomerHitMat.dispose();
      badgeGeo.dispose();
      badgeMat.dispose();
      badgeTexture.dispose();
      shadowMat.dispose();
      shadowTex.dispose();
    },
  };
}
