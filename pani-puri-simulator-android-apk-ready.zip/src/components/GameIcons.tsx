import React from 'react';
import { ShopItemId } from '../game/foodPrepEngine';

interface IconProps {
  size?: number;
  className?: string;
}

export const SprintIcon: React.FC<IconProps> = ({ size = 24, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="15.5" cy="4.5" r="2.2" fill="currentColor" stroke="none" />
    <path d="M7 11.5L10.5 8.5L14.5 10.5L18.5 8" />
    <path d="M12.5 9.8L10 15L6 16.5" />
    <path d="M11 13.5L15 15.5L16.5 20" />
    <path d="M3 9.5H6.5" strokeOpacity="0.65" />
    <path d="M2 13H5.5" strokeOpacity="0.65" />
  </svg>
);

export const JumpIcon: React.FC<IconProps> = ({ size = 24, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M12 16V4" />
    <path d="M6.5 9.5L12 4L17.5 9.5" />
    <path d="M5 20C7.5 18.2 16.5 18.2 19 20" strokeOpacity="0.8" />
  </svg>
);

export const PickDropIcon: React.FC<IconProps> = ({ size = 24, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.1"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11" />
    <path d="M11 11V4.5a1.5 1.5 0 0 1 3 0V11" />
    <path d="M14 11V5.5a1.5 1.5 0 0 1 3 0V13" />
    <path d="M17 11.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-2a6 6 0 0 1-5.2-3L4.3 13.5a1.5 1.5 0 0 1 2.5-1.6L8 13.5" />
  </svg>
);

export const PourIcon: React.FC<IconProps> = ({ size = 24, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.1"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    {/* Tilted pitcher / matka vessel */}
    <path d="M10.5 4.5L17.5 9.5L13 15.5C11.5 17.2 8.5 17.2 6.8 15.8C5.1 14.3 5 11.4 6.5 9.5L10.5 4.5Z" />
    <path d="M14.5 7.2L17.8 4.8C18.8 4.2 20 5 19.6 6.2L17.5 9.5" />
    {/* Pouring droplets */}
    <circle cx="6.2" cy="18.2" r="1.2" fill="currentColor" stroke="none" />
    <circle cx="4.5" cy="21" r="1.3" fill="currentColor" stroke="none" />
    <circle cx="8.2" cy="20.8" r="1.1" fill="currentColor" stroke="none" />
  </svg>
);

export const PutDownIcon: React.FC<IconProps> = ({ size = 24, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M12 4V15" />
    <path d="M7.5 11L12 15.5L16.5 11" />
    <rect x="4" y="18.5" width="16" height="2.5" rx="1" fill="currentColor" stroke="none" />
  </svg>
);

export const ShopCartIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="9" cy="20" r="1.6" fill="currentColor" />
    <circle cx="18" cy="20" r="1.6" fill="currentColor" />
    <path d="M2.5 4h2.8l2.4 11.2a1.8 1.8 0 0 0 1.8 1.4h8.8a1.8 1.8 0 0 0 1.7-1.3L21.5 7H6.2" />
  </svg>
);

export const PauseBarsIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <rect x="6" y="4" width="4.2" height="16" rx="1.4" />
    <rect x="13.8" y="4" width="4.2" height="16" rx="1.4" />
  </svg>
);

export const SettingsGearIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.1"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="3.2" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.6.85 1 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);

export const CloseIcon: React.FC<IconProps> = ({ size = 18, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M18 6L6 18" />
    <path d="M6 6L18 18" />
  </svg>
);

export const ConfirmCheckIcon: React.FC<IconProps> = ({ size = 18, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.6"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M20 6L9 17L4 12" />
  </svg>
);

export const ResetArrowIcon: React.FC<IconProps> = ({ size = 16, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.3"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
    <path d="M3 3v5h5" />
  </svg>
);

export const SaveDiskIcon: React.FC<IconProps> = ({ size = 16, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
    <polyline points="17 21 17 13 7 13 7 21" />
    <polyline points="7 3 7 8 15 8" />
  </svg>
);

export const BackArrowIcon: React.FC<IconProps> = ({ size = 18, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M19 12H5" />
    <path d="M12 19L5 12L12 5" />
  </svg>
);

export const CoinIcon: React.FC<IconProps> = ({ size = 16, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="9.5" fill="#facc15" stroke="#b45309" strokeWidth="2" />
    <circle cx="12" cy="12" r="6.5" stroke="#fef08a" strokeWidth="1.2" />
    <path d="M9.5 9.5h5M9.5 12h4.5M10.5 9.5l3.5 6" stroke="#78350f" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const ShopItemSymbol: React.FC<{ itemId: ShopItemId; size?: number }> = ({
  itemId,
  size = 26,
}) => {
  switch (itemId) {
    case 'sukhi_puri':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="15" r="9" fill="#fbbf24" stroke="#78350f" strokeWidth="2" />
          <ellipse cx="14" cy="11.5" rx="4.5" ry="2.4" fill="#451a03" />
        </svg>
      );
    case 'aloo':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <path d="M5 15a9 7 0 0 1 18 0Z" fill="#fde047" stroke="#ca8a04" strokeWidth="1.8" />
          <path d="M4 15h20l-2 7H6Z" fill="#cbd5e1" stroke="#475569" strokeWidth="1.8" />
        </svg>
      );
    case 'sev':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <path d="M5 15a9 6 0 0 1 18 0Z" fill="#f59e0b" stroke="#92400e" strokeWidth="1.8" />
          <path d="M4 15h20l-2 7H6Z" fill="#fcd34d" stroke="#92400e" strokeWidth="1.8" />
        </svg>
      );
    case 'curd':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <path d="M5 15a9 7 0 0 1 18 0Z" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1.8" />
          <path d="M4 15h20l-2 7H6Z" fill="#fef3c7" stroke="#b45309" strokeWidth="1.8" />
        </svg>
      );
    case 'jeera_jal':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="16.5" r="8" fill="#fbbf24" stroke="#92400e" strokeWidth="1.8" />
          <rect x="9.5" y="6" width="9" height="3.5" rx="1" fill="#f59e0b" stroke="#92400e" strokeWidth="1.5" />
          <ellipse cx="14" cy="6.5" rx="3.8" ry="1.4" fill="#22c55e" />
        </svg>
      );
    case 'sweet_chatni':
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <circle cx="14" cy="16.5" r="8" fill="#ea580c" stroke="#7c2d12" strokeWidth="1.8" />
          <rect x="9.5" y="6" width="9" height="3.5" rx="1" fill="#d97706" stroke="#7c2d12" strokeWidth="1.5" />
          <ellipse cx="14" cy="6.5" rx="3.8" ry="1.4" fill="#9a3412" />
        </svg>
      );
    case 'plate':
    default:
      return (
        <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
          <ellipse cx="14" cy="16" rx="10" ry="4.5" fill="#e2e8f0" stroke="#475569" strokeWidth="2" />
          <ellipse cx="14" cy="13" rx="9.5" ry="4" fill="#f8fafc" stroke="#64748b" strokeWidth="1.8" />
        </svg>
      );
  }
};
