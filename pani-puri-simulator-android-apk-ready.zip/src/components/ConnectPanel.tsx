import React, { useState } from 'react';
import { SOCIAL_LINKS, isSocialUrlConfigured, SocialLinkConfig } from '../config/socialLinks';
import { soundManager } from '../utils/sound';

interface ConnectPanelProps {
  onBack: () => void;
}

export const ConnectPanel: React.FC<ConnectPanelProps> = ({ onBack }) => {
  const [noticeMessage, setNoticeMessage] = useState<string | null>(null);

  const handleSocialClick = (link: SocialLinkConfig) => {
    soundManager.playUiClick();
    if (isSocialUrlConfigured(link.url)) {
      window.location.assign(link.url);
    } else {
      soundManager.playNotice();
      setNoticeMessage(
        `The official ${link.label} account URL has not been configured yet. You can set the live URL in src/config/socialLinks.ts when ready.`
      );
    }
  };

  return (
    <section
      className="fixed inset-0 z-30 flex items-center justify-center p-3 sm:p-6"
      style={{ backgroundColor: 'rgba(12, 10, 9, 0.82)' }}
      aria-labelledby="connect-panel-heading"
    >
      <div
        className="flex max-h-[92vh] w-full max-w-xl flex-col overflow-y-auto rounded-2xl border border-amber-400/25 p-4 sm:p-6 text-stone-100 shadow-2xl"
        style={{ backgroundColor: 'rgba(28, 25, 23, 0.96)' }}
      >
        <div className="flex items-center justify-between gap-4 border-b border-stone-800 pb-3">
          <div>
            <h2
              id="connect-panel-heading"
              className="font-display text-xl sm:text-2xl font-bold text-amber-400"
            >
              Connect With Us
            </h2>
            <p className="mt-0.5 text-xs text-stone-300">
              Follow Pani Puri Simulator 3D development updates and community channels.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              soundManager.playUiClick();
              onBack();
            }}
            className="min-h-[42px] shrink-0 cursor-pointer rounded-xl bg-amber-500 px-5 py-2 font-display text-sm font-bold text-stone-950 transition-colors hover:bg-amber-400 active:scale-[0.98] whitespace-nowrap"
          >
            Back
          </button>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* YouTube Button */}
          <button
            type="button"
            onClick={() => handleSocialClick(SOCIAL_LINKS.youtube)}
            className="flex min-h-[54px] w-full cursor-pointer items-center justify-between rounded-xl border border-stone-700/80 bg-stone-900 px-4 py-3 text-left transition-colors hover:border-red-500/50 hover:bg-stone-800 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-600/20 text-red-400">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden="true">
                  <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31.5 31.5 0 0 0 0 12a31.5 31.5 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31.5 31.5 0 0 0 24 12a31.5 31.5 0 0 0-.5-5.8zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z" />
                </svg>
              </span>
              <div>
                <div className="font-display text-sm sm:text-base font-bold text-stone-100">
                  {SOCIAL_LINKS.youtube.label}
                </div>
                <div className="text-[11px] text-stone-400">{SOCIAL_LINKS.youtube.handle}</div>
              </div>
            </div>
            <span className="text-xs font-semibold text-amber-400 whitespace-nowrap">
              Open
            </span>
          </button>

          {/* Instagram Button */}
          <button
            type="button"
            onClick={() => handleSocialClick(SOCIAL_LINKS.instagram)}
            className="flex min-h-[54px] w-full cursor-pointer items-center justify-between rounded-xl border border-stone-700/80 bg-stone-900 px-4 py-3 text-left transition-colors hover:border-pink-500/50 hover:bg-stone-800 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-pink-600/20 text-pink-400">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden="true">
                  <path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.2 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.3 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.2 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .3-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.2-2.2-.4a3.9 3.9 0 0 1-2.3-2.3c-.2-.4-.3-1-.4-2.2-.1-1.3-.1-1.7-.1-4.9s0-3.6.1-4.9c.1-1.2.2-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.3 2.2-.4 1.3-.1 1.7-.1 4.9-.1zM12 0C8.7 0 8.3 0 7 .1 5.7.1 4.8.3 4.1.6c-.8.3-1.4.7-2.1 1.4C1.3 2.7.9 3.3.6 4.1.3 4.8.1 5.7.1 7 0 8.3 0 8.7 0 12s0 3.7.1 5c.1 1.3.2 2.2.5 2.9.3.8.7 1.4 1.4 2.1.7.7 1.3 1.1 2.1 1.4.7.3 1.6.5 2.9.5 1.3.1 1.7.1 5 .1s3.7 0 5-.1c1.3-.1 2.2-.2 2.9-.5.8-.3 1.4-.7 2.1-1.4.7-.7 1.1-1.3 1.4-2.1.3-.7.5-1.6.5-2.9.1-1.3.1-1.7.1-5s0-3.7-.1-5c-.1-1.3-.2-2.2-.5-2.9-.3-.8-.7-1.4-1.4-2.1A5.8 5.8 0 0 0 19.9.6C19.2.3 18.3.1 17 .1 15.7 0 15.3 0 12 0zm0 5.8a6.2 6.2 0 1 0 0 12.4 6.2 6.2 0 0 0 0-12.4zm0 10.2a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.4-11.8a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8z" />
                </svg>
              </span>
              <div>
                <div className="font-display text-sm sm:text-base font-bold text-stone-100">
                  {SOCIAL_LINKS.instagram.label}
                </div>
                <div className="text-[11px] text-stone-400">{SOCIAL_LINKS.instagram.handle}</div>
              </div>
            </div>
            <span className="text-xs font-semibold text-amber-400 whitespace-nowrap">
              Open
            </span>
          </button>
        </div>

        {/* Friendly Notice When Placeholder URL Is Clicked */}
        {noticeMessage && (
          <div
            role="status"
            aria-live="polite"
            className="mt-3 rounded-xl border border-amber-400/40 bg-amber-950/50 p-3 text-xs text-amber-100"
          >
            {noticeMessage}
          </div>
        )}
      </div>
    </section>
  );
};
