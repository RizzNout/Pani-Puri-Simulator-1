import React, { useEffect } from 'react';
import { PlayerTelemetry } from '../types/game';
import { PlayerInputController } from '../game/playerController';
import { MobileControls } from './MobileControls';
import { soundManager } from '../utils/sound';
import {
  ALL_POURABLE_IDS,
  calculateRecipeAccuracy,
  ITEM_DISPLAY_NAMES,
  POURABLE_INGREDIENTS,
  RecipeId,
  RECIPES,
  RECIPE_LIST,
  REQUIRED_PURIS_PER_PLATE,
} from '../game/recipes';
import { FoodPrepSessionState, isContainerItem } from '../game/foodPrepEngine';
import { ControlId, ControlLayoutMap } from '../game/controlLayout';
import {
  BackArrowIcon,
  CloseIcon,
  CoinIcon,
  ConfirmCheckIcon,
  PauseBarsIcon,
  PutDownIcon,
  SettingsGearIcon,
  ShopCartIcon,
} from './GameIcons';

interface GameHUDProps {
  telemetry: PlayerTelemetry;
  foodPrep: FoodPrepSessionState;
  isPointerLocked: boolean;
  inputController: PlayerInputController;
  controlLayout: ControlLayoutMap;
  isCustomizing?: boolean;
  selectedControlId?: ControlId;
  overlappingIds?: Set<ControlId>;
  onSelectControl?: (id: ControlId) => void;
  onMoveControl?: (id: ControlId, xPercent: number, yPercent: number) => void;
  orientationNotice: string | null;
  onDismissOrientationNotice: () => void;
  onDismissStatusBanner: () => void;
  onPickOrDrop: () => void;
  onPutDownContainer: () => void;
  onPourStart: () => void;
  onPourEnd: () => void;
  onSelectRecipe: (recipeId: RecipeId) => void;
  onDiscardPlate: (confirmed?: boolean) => void;
  onCancelDiscard: () => void;
  onCompletePlate: () => void;
  onOpenShop: () => void;
  onOpenCustomizeControls: () => void;
  onPause: () => void;
  onReturnToMenu: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  telemetry,
  foodPrep,
  isPointerLocked,
  inputController,
  controlLayout,
  isCustomizing = false,
  selectedControlId,
  overlappingIds,
  onSelectControl,
  onMoveControl,
  orientationNotice,
  onDismissOrientationNotice,
  onDismissStatusBanner,
  onPickOrDrop,
  onPutDownContainer,
  onPourStart,
  onPourEnd,
  onSelectRecipe,
  onDiscardPlate,
  onCancelDiscard,
  onCompletePlate,
  onOpenShop,
  onOpenCustomizeControls,
  onPause,
  onReturnToMenu,
}) => {
  useEffect(() => {
    if (!foodPrep.statusBanner) return;
    const timer = window.setTimeout(() => {
      onDismissStatusBanner();
    }, 3400);
    return () => window.clearTimeout(timer);
  }, [foodPrep.statusBanner, onDismissStatusBanner]);

  useEffect(() => {
    if (!orientationNotice) return;
    const timer = window.setTimeout(() => {
      onDismissOrientationNotice();
    }, 4500);
    return () => window.clearTimeout(timer);
  }, [orientationNotice, onDismissOrientationNotice]);

  // Desktop keyboard shortcuts for Pick/Drop (F), Put Down (Q), and Hold Pour (E)
  useEffect(() => {
    if (isCustomizing) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'KeyF') {
        e.preventDefault();
        onPickOrDrop();
      } else if (e.code === 'KeyQ') {
        e.preventDefault();
        onPutDownContainer();
      } else if (e.code === 'KeyE') {
        e.preventDefault();
        onPourStart();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'KeyE') {
        e.preventDefault();
        onPourEnd();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isCustomizing, onPickOrDrop, onPutDownContainer, onPourStart, onPourEnd]);

  const custSys = foodPrep.customerSystem;
  const activeCustomer =
    custSys.customers.find(
      (c) =>
        c.queueSlotIndex === 0 &&
        (c.state === 'ORDERING' ||
          c.state === 'WAITING_FOR_FOOD' ||
          c.state === 'EATING' ||
          c.state === 'REACTING')
    ) ?? null;

  const effectiveRecipeId = activeCustomer ? activeCustomer.orderRecipeId : foodPrep.selectedRecipeId;
  const currentRecipe = RECIPES[effectiveRecipeId];
  const activePlate = foodPrep.activePlate;
  const accuracyEval = activePlate
    ? calculateRecipeAccuracy(activePlate, effectiveRecipeId)
    : null;

  const requiredIngredientEntries = ALL_POURABLE_IDS.filter(
    (id) => currentRecipe.targetIngredients[id] > 0
  );
  const wrongIngredientEntries = activePlate
    ? ALL_POURABLE_IDS.filter(
        (id) =>
          currentRecipe.targetIngredients[id] === 0 &&
          activePlate.ingredients[id] > 0
      )
    : [];

  const inv = foodPrep.inventory;
  const patiencePct = activeCustomer
    ? Math.max(0, Math.min(100, Math.round((activeCustomer.patience / activeCustomer.maxPatience) * 100)))
    : 100;

  return (
    <div
      className="pointer-events-none fixed inset-0 z-10 overflow-hidden"
      aria-label="In-Game HUD"
      data-testid="game-hud"
      data-held-item={foodPrep.heldItem || 'none'}
      data-aimed-target={foodPrep.aimedTarget || 'none'}
      data-selected-recipe={effectiveRecipeId}
      data-active-puris={activePlate ? activePlate.puris : 0}
      data-active-accuracy={accuracyEval ? accuracyEval.accuracy : 0}
      data-is-pouring={foodPrep.isPouring}
      data-coins={foodPrep.coins}
      data-active-customers={custSys.customers.length}
      data-customer-limit={foodPrep.customerLimit}
      data-active-customer-state={activeCustomer ? activeCustomer.state : 'none'}
    >
      {!isCustomizing && (
        <>
          {/* 1. Top Perimeter Status, Inventory Bar & Symbol Navigation Cluster */}
          <div
            className="flex items-start justify-between gap-2"
            style={{
              paddingTop: 'max(8px, env(safe-area-inset-top))',
              paddingLeft: 'max(14px, env(safe-area-inset-left))',
              paddingRight: 'max(14px, env(safe-area-inset-right))',
            }}
          >
            {/* Top-Left World Location, Coins & Compact Inventory Strip */}
            <div
              className="pointer-events-auto flex flex-col gap-0.5 rounded-xl border border-amber-400/30 px-2.5 py-1 text-stone-100 shadow-md"
              style={{ backgroundColor: 'rgba(12, 10, 9, 0.84)' }}
              data-testid="inventory-panel"
            >
              <div className="flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-amber-300 whitespace-nowrap">
                <span>{telemetry.zoneName}</span>
                <span aria-hidden="true" className="text-stone-500">·</span>
                <span className="font-mono tabular-nums text-stone-200">
                  Stall {telemetry.distanceToStall}m
                </span>
                <span aria-hidden="true" className="text-stone-500">·</span>
                <span
                  data-testid="hud-coins"
                  className="inline-flex items-center gap-1 font-mono tabular-nums text-amber-300"
                >
                  <CoinIcon size={13} />
                  <span>{foodPrep.coins}</span>
                </span>
                <span aria-hidden="true" className="text-stone-500">·</span>
                <span
                  data-testid="hud-customer-limit"
                  className="font-mono text-[10px] tabular-nums text-stone-300"
                >
                  Cust:{custSys.customers.length}/{foodPrep.customerLimit}
                </span>
                {foodPrep.heldItem && (
                  <>
                    <span aria-hidden="true" className="text-stone-500">·</span>
                    <span className="text-emerald-300" data-testid="held-item-badge">
                      Holding: {ITEM_DISPLAY_NAMES[foodPrep.heldItem]}
                    </span>
                  </>
                )}
                <span className="hidden xl:inline text-[10px] font-normal text-stone-400 ml-1">
                  {isPointerLocked ? '(ESC Pause)' : '(Drag right to look)'}
                </span>
              </div>

              {/* Compact Inventory Stock Readout */}
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-[10px] text-stone-300 tabular-nums">
                <span data-testid="stock-plates">Plates:{inv.emptyPlates}</span>
                <span data-testid="stock-sukhi_puri">Puris:{inv.sukhi_puri}</span>
                <span data-testid="stock-aloo">Aloo:{inv.aloo}</span>
                <span data-testid="stock-sev">Sev:{inv.sev}</span>
                <span data-testid="stock-curd">Curd:{inv.curd}</span>
                <span data-testid="stock-jeera_jal">Jeera:{inv.jeera_jal}</span>
                <span data-testid="stock-sweet_chatni">Chatni:{inv.sweet_chatni}</span>
              </div>
            </div>

            {/* Top-Right Symbol Buttons: Shop (🛒), Customize Controls (⚙️), Return to Menu (←), Pause (Ⅱ) */}
            <div className="pointer-events-auto flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                data-testid="hud-shop-btn"
                aria-label="Shop"
                title="Open In-Game Shop"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  soundManager.playUiClick();
                  onOpenShop();
                }}
                className="flex min-h-[42px] min-w-[44px] cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-amber-400/50 px-2.5 py-1.5 font-display text-xs font-bold text-amber-200 shadow-md transition-colors hover:bg-stone-800 active:scale-95 whitespace-nowrap"
                style={{ backgroundColor: 'rgba(28, 25, 23, 0.92)' }}
              >
                <ShopCartIcon size={18} />
                <span className="hidden sm:inline text-[11px]">Shop</span>
              </button>

              <button
                type="button"
                data-testid="hud-customize-btn"
                aria-label="Customize Controls"
                title="Customize Button Positions & Size"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  soundManager.playUiClick();
                  onOpenCustomizeControls();
                }}
                className="flex min-h-[42px] min-w-[42px] cursor-pointer items-center justify-center rounded-xl border border-stone-600/60 p-2 text-stone-200 shadow-md transition-colors hover:bg-stone-800 active:scale-95"
                style={{ backgroundColor: 'rgba(28, 25, 23, 0.90)' }}
              >
                <SettingsGearIcon size={18} />
              </button>

              <button
                type="button"
                data-testid="hud-menu-btn"
                aria-label="Return to Menu"
                title="Return to Main Menu"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  soundManager.playUiClick();
                  onReturnToMenu();
                }}
                className="flex min-h-[42px] min-w-[42px] cursor-pointer items-center justify-center rounded-xl border border-stone-600/60 p-2 text-stone-200 shadow-md transition-colors hover:bg-stone-800 active:scale-95"
                style={{ backgroundColor: 'rgba(28, 25, 23, 0.90)' }}
              >
                <BackArrowIcon size={18} />
              </button>

              <button
                type="button"
                data-testid="hud-pause-btn"
                aria-label="Pause"
                title="Pause Game (Esc)"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  soundManager.playUiClick();
                  onPause();
                }}
                className="flex min-h-[42px] min-w-[44px] cursor-pointer items-center justify-center rounded-xl border border-amber-300/45 p-2 text-amber-100 shadow-md transition-colors hover:bg-stone-800 active:scale-95"
                style={{ backgroundColor: 'rgba(28, 25, 23, 0.92)' }}
              >
                <PauseBarsIcon size={18} />
              </button>
            </div>
          </div>

          {/* 2. Compact Customer Order, Patience & Recipe Progress Card (Upper-Left below Top Bar) */}
          <aside
            aria-label="Order and Recipe Panel"
            data-testid="order-panel"
            className="pointer-events-auto fixed left-3.5 top-[46px] z-20 flex w-[252px] sm:w-[272px] flex-col gap-0.5 rounded-xl border border-amber-400/35 px-2 py-1 text-stone-100 shadow-xl"
            style={{ backgroundColor: 'rgba(16, 14, 12, 0.88)' }}
          >
            {/* Active Customer Order, Patience & Live Accuracy Strip */}
            {activeCustomer ? (
              <div
                data-testid="active-customer-banner"
                className="flex flex-col gap-0.5 rounded-md bg-stone-900/95 px-1.5 py-0.5 border border-stone-800"
              >
                {activeCustomer.state === 'EATING' || activeCustomer.state === 'REACTING' ? (
                  <div
                    data-testid="customer-reaction-banner"
                    className="flex items-center justify-between gap-1 text-[10px]"
                  >
                    <span className="font-display font-bold text-emerald-300 truncate">
                      {activeCustomer.name}: {activeCustomer.reactionText || 'Tasting...'}
                    </span>
                    {activeCustomer.starRating !== null && activeCustomer.starRating > 0 && (
                      <span
                        data-testid="customer-star-rating"
                        data-stars={activeCustomer.starRating}
                        className="inline-flex items-center gap-0.5 font-mono font-bold text-amber-300 shrink-0"
                      >
                        {Array.from({ length: activeCustomer.starRating }).map((_, idx) => (
                          <svg
                            key={idx}
                            viewBox="0 0 20 20"
                            className="h-2.5 w-2.5 fill-amber-400"
                            aria-hidden="true"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="ml-0.5">+{activeCustomer.coinsAwarded}</span>
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-between gap-1 text-[10px]">
                    <span className="font-display font-extrabold text-amber-300 truncate">
                      {activeCustomer.name}: {currentRecipe.shortTitle}
                    </span>
                    <div className="flex items-center gap-1 shrink-0">
                      {accuracyEval && (
                        <span
                          data-testid="plate-accuracy-badge"
                          className={`rounded px-1 font-mono text-[9px] font-bold ${
                            accuracyEval.isWithinTolerance
                              ? 'bg-emerald-500/25 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-200'
                          }`}
                        >
                          {accuracyEval.accuracy}%
                        </span>
                      )}
                      <div
                        className="h-1.5 w-10 overflow-hidden rounded-full bg-stone-800"
                        title={`Customer Patience: ${patiencePct}%`}
                      >
                        <div
                          data-testid="customer-patience-bar"
                          className={`h-full transition-all ${
                            patiencePct > 50
                              ? 'bg-emerald-400'
                              : patiencePct > 25
                                ? 'bg-amber-400'
                                : 'bg-red-500'
                          }`}
                          style={{ width: `${patiencePct}%` }}
                        />
                      </div>
                      <span
                        data-testid="customer-patience-pct"
                        className="font-mono text-[9px] tabular-nums text-stone-300"
                      >
                        {patiencePct}%
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div
                data-testid="waiting-customer-banner"
                className="flex items-center justify-between rounded-md bg-stone-900/90 px-1.5 py-0.5 text-[10px] text-stone-400"
              >
                <span>ORDER: {currentRecipe.shortTitle}</span>
                <span className="font-mono text-amber-300">
                  Queue: {custSys.customers.length}
                </span>
              </div>
            )}

            {/* Recipe Selector Tabs: Sweet Puri | Pani Puri | Sev Puri */}
            <div className="grid grid-cols-3 gap-1 rounded-md bg-stone-900/95 p-0.5">
              {RECIPE_LIST.map((r) => {
                const selected = r.id === effectiveRecipeId;
                return (
                  <button
                    key={r.id}
                    type="button"
                    data-testid={`recipe-tab-${r.id}`}
                    tabIndex={-1}
                    onClick={(e) => {
                      e.currentTarget.blur();
                      onSelectRecipe(r.id);
                    }}
                    className={`min-h-[19px] cursor-pointer rounded px-1 py-0.5 font-display text-[10px] font-bold transition-colors whitespace-nowrap ${
                      selected
                        ? 'bg-amber-500 text-stone-950'
                        : 'text-stone-300 hover:text-amber-200'
                    }`}
                  >
                    {r.name}
                  </button>
                );
              })}
            </div>

            {/* Required Ingredients & Target Quantities Grid */}
            <div className="grid grid-cols-2 gap-x-2 gap-y-0 font-mono text-[10px] leading-tight tabular-nums">
              <div
                data-testid="puri-counter-label"
                className="flex items-center justify-between text-stone-200"
              >
                <span>Puris:</span>
                <span
                  className={
                    (activePlate?.puris ?? 0) === REQUIRED_PURIS_PER_PLATE
                      ? 'font-bold text-emerald-400'
                      : 'text-amber-200'
                  }
                >
                  {activePlate ? activePlate.puris : 0}/{REQUIRED_PURIS_PER_PLATE}
                </span>
              </div>

              {requiredIngredientEntries.map((ingId) => {
                const target = currentRecipe.targetIngredients[ingId];
                const current = activePlate ? activePlate.ingredients[ingId] : 0;
                const withinTol = current > 0 && Math.abs(current - target) <= 5;
                const overTol = current > target + 5;
                return (
                  <div
                    key={ingId}
                    data-testid={`order-req-${ingId}`}
                    className="flex items-center justify-between text-stone-200"
                  >
                    <span className="truncate">{POURABLE_INGREDIENTS[ingId].name}:</span>
                    <span
                      className={
                        withinTol
                          ? 'font-bold text-emerald-400'
                          : overTol
                            ? 'font-bold text-red-400'
                            : 'text-amber-200'
                      }
                    >
                      {current}/{target}
                    </span>
                  </div>
                );
              })}

              {wrongIngredientEntries.map((ingId) => (
                <div
                  key={ingId}
                  data-testid={`order-wrong-${ingId}`}
                  className="flex items-center justify-between text-red-400 font-bold"
                >
                  <span className="truncate">{POURABLE_INGREDIENTS[ingId].name}:</span>
                  <span>{activePlate ? activePlate.ingredients[ingId] : 0}/0!</span>
                </div>
              ))}
            </div>

            {/* Discard Confirmation Prompt or Plate Action Buttons */}
            {foodPrep.discardConfirmOpen ? (
              <div
                data-testid="discard-confirm-box"
                className="mt-0.5 flex items-center justify-between gap-1 rounded-lg border border-red-400/50 bg-red-950/70 px-1.5 py-0.5 text-[10px]"
              >
                <span className="font-semibold text-red-100 truncate">
                  {foodPrep.pendingRecipeSwitch
                    ? 'Discard plate to switch?'
                    : 'Discard current plate?'}
                </span>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    data-testid="confirm-discard-btn"
                    title="Confirm Discard"
                    onClick={() => onDiscardPlate(true)}
                    className="flex cursor-pointer items-center gap-0.5 rounded bg-red-500 px-1.5 py-0.5 font-bold text-white hover:bg-red-400"
                  >
                    <ConfirmCheckIcon size={11} />
                    <span>Discard</span>
                  </button>
                  <button
                    type="button"
                    data-testid="cancel-discard-btn"
                    title="Cancel Discard"
                    onClick={onCancelDiscard}
                    className="flex cursor-pointer items-center gap-0.5 rounded bg-stone-700 px-1.5 py-0.5 font-bold text-stone-200 hover:bg-stone-600"
                  >
                    <CloseIcon size={11} />
                    <span>Cancel</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-0.5 flex items-center gap-1">
                <button
                  type="button"
                  data-testid="complete-plate-btn"
                  title="Serve Order to Customer"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onCompletePlate();
                  }}
                  className={`flex min-h-[21px] flex-1 cursor-pointer items-center justify-center gap-1 rounded-md px-1.5 py-0.5 font-display text-[10px] font-bold transition-colors whitespace-nowrap ${
                    accuracyEval?.isComplete
                      ? 'bg-emerald-500 text-stone-950 hover:bg-emerald-400'
                      : 'border border-stone-700 bg-stone-800/90 text-stone-300 hover:bg-stone-700'
                  }`}
                >
                  <ConfirmCheckIcon size={12} />
                  <span>{activeCustomer ? `Serve ${activeCustomer.name}` : 'Complete Plate'}</span>
                </button>

                {activePlate && (
                  <button
                    type="button"
                    data-testid="discard-plate-btn"
                    title="Discard Plate"
                    tabIndex={-1}
                    onClick={(e) => {
                      e.currentTarget.blur();
                      onDiscardPlate(false);
                    }}
                    className="flex min-h-[22px] cursor-pointer items-center gap-0.5 rounded-md border border-red-500/40 bg-red-950/60 px-2 py-0.5 font-display text-[10px] font-bold text-red-200 hover:bg-red-900/60 whitespace-nowrap"
                  >
                    <CloseIcon size={11} />
                    <span>Discard</span>
                  </button>
                )}

                {isContainerItem(foodPrep.heldItem) && (
                  <button
                    type="button"
                    data-testid="order-put-down-btn"
                    title="Put Down Container (Q)"
                    tabIndex={-1}
                    onClick={(e) => {
                      e.currentTarget.blur();
                      onPutDownContainer();
                    }}
                    className="flex min-h-[22px] cursor-pointer items-center gap-0.5 rounded-md border border-amber-400/40 bg-stone-800 px-1.5 py-0.5 font-display text-[10px] font-bold text-amber-200 hover:bg-stone-700 whitespace-nowrap"
                  >
                    <PutDownIcon size={11} />
                    <span>Put Down</span>
                  </button>
                )}
              </div>
            )}
          </aside>
        </>
      )}

      {/* 3. Center Crosshair (Fixed at Exact Center of Viewport) + Contextual Raycast Label */}
      <div
        data-testid="center-crosshair"
        className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center"
      >
        <svg viewBox="0 0 24 24" className="h-6 w-6 drop-shadow" aria-hidden="true">
          <circle
            cx="12"
            cy="12"
            r="2.2"
            fill={foodPrep.aimedTarget ? '#4ade80' : '#fef08a'}
            stroke="#0c0a09"
            strokeWidth="1.2"
          />
          <line x1="12" y1="3" x2="12" y2="7" stroke="#fef08a" strokeWidth="1.8" strokeLinecap="round" />
          <line x1="12" y1="17" x2="12" y2="21" stroke="#fef08a" strokeWidth="1.8" strokeLinecap="round" />
          <line x1="3" y1="12" x2="7" y2="12" stroke="#fef08a" strokeWidth="1.8" strokeLinecap="round" />
          <line x1="17" y1="12" x2="21" y2="12" stroke="#fef08a" strokeWidth="1.8" strokeLinecap="round" />
        </svg>

        {!isCustomizing && foodPrep.contextualPrompt && (
          <div
            data-testid="crosshair-prompt"
            className="mt-2 rounded-lg border border-amber-300/60 px-2.5 py-1 text-center font-display text-xs font-bold text-amber-100 shadow-lg whitespace-nowrap"
            style={{ backgroundColor: 'rgba(12, 10, 9, 0.88)' }}
          >
            {foodPrep.contextualPrompt}
          </div>
        )}
      </div>

      {/* 4. Serving Reward Popup & Status Notification Banner */}
      {!isCustomizing &&
        activeCustomer &&
        (activeCustomer.state === 'EATING' || activeCustomer.state === 'REACTING') &&
        activeCustomer.starRating !== null &&
        activeCustomer.starRating > 0 && (
          <div
            role="status"
            aria-live="polite"
            data-testid="serving-reward-popup"
            className="pointer-events-none fixed left-[58%] sm:left-[55%] top-[44px] -translate-x-1/2 z-30 flex items-center gap-2.5 rounded-xl border border-emerald-400/60 px-3 py-1.5 text-stone-100 shadow-2xl"
            style={{ backgroundColor: 'rgba(14, 24, 18, 0.94)' }}
          >
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-300">
                <span>
                  {activeCustomer.state === 'EATING'
                    ? `${activeCustomer.name} is enjoying ${RECIPES[activeCustomer.orderRecipeId].name}!`
                    : `${activeCustomer.name}: "${activeCustomer.reactionText}"`}
                </span>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <div
                  className="inline-flex items-center gap-0.5"
                  aria-label={`${activeCustomer.starRating} out of 5 stars`}
                >
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <svg
                      key={idx}
                      viewBox="0 0 20 20"
                      className={`h-3 w-3 ${
                        idx < (activeCustomer.starRating ?? 0)
                          ? 'fill-amber-400'
                          : 'fill-stone-700'
                      }`}
                      aria-hidden="true"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="font-mono text-[10px] font-bold text-amber-200">
                  {activeCustomer.starRating}/5 Stars
                </span>
              </div>
            </div>

            <div
              data-testid="coin-reward-popup"
              className="flex items-center gap-1 rounded-lg border border-amber-400/60 bg-amber-500/20 px-2 py-1 font-mono text-xs font-extrabold text-amber-300 tabular-nums whitespace-nowrap"
            >
              <CoinIcon size={13} />
              <span>+{activeCustomer.coinsAwarded} Coins</span>
            </div>
          </div>
        )}

      {!isCustomizing &&
        !(
          activeCustomer &&
          (activeCustomer.state === 'EATING' || activeCustomer.state === 'REACTING') &&
          activeCustomer.starRating !== null &&
          activeCustomer.starRating > 0
        ) &&
        ((foodPrep.statusBanner && foodPrep.statusBanner !== foodPrep.contextualPrompt) ||
          orientationNotice) && (
          <div
            role="status"
            aria-live="polite"
            data-testid="hud-toast-message"
            className={`pointer-events-none fixed left-[58%] sm:left-[55%] top-[50px] -translate-x-1/2 z-30 max-w-[330px] rounded-xl border px-3 py-1 text-center text-[11px] font-semibold shadow-xl ${
              foodPrep.statusBanner &&
              (foodPrep.statusBanner.includes('Incomplete') ||
                foodPrep.statusBanner.includes('ordered') ||
                foodPrep.statusBanner.includes('Out of') ||
                foodPrep.statusBanner.includes('Not enough') ||
                foodPrep.statusBanner.includes('ran out of patience'))
                ? 'border-red-400/70 text-red-100'
                : 'border-amber-400/60 text-amber-100'
            }`}
            style={{ backgroundColor: 'rgba(28, 25, 23, 0.94)' }}
          >
            {foodPrep.statusBanner || orientationNotice}
          </div>
        )}

      {/* 5. Customizable Symbol-Based Landscape Mobile Controls */}
      <MobileControls
        inputController={inputController}
        isSprinting={telemetry.isSprinting}
        heldItem={foodPrep.heldItem}
        isPouring={foodPrep.isPouring}
        controlLayout={controlLayout}
        isCustomizing={isCustomizing}
        selectedControlId={selectedControlId}
        overlappingIds={overlappingIds}
        onSelectControl={onSelectControl}
        onMoveControl={onMoveControl}
        onPickOrDrop={onPickOrDrop}
        onPutDownContainer={onPutDownContainer}
        onPourStart={onPourStart}
        onPourEnd={onPourEnd}
      />
    </div>
  );
};
