import React, { useEffect } from 'react';
import { soundManager } from '../utils/sound';

interface MainMenuProps {
  onStartGame: () => void;
  onOpenShop: () => void;
  onOpenConnect: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onOpenShop,
  onOpenConnect,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        const activeTag = document.activeElement?.tagName.toLowerCase();
        if (activeTag === 'button' && !document.activeElement?.hasAttribute('data-start')) {
          return;
        }
        e.preventDefault();
        soundManager.playUiClick();
        onStartGame();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStartGame]);

  return (
    <main
      className="fixed inset-0 z-20 flex flex-col justify-between px-5 py-3.5 sm:px-10 sm:py-6"
      style={{
        background:
          'linear-gradient(90deg, rgba(12, 10, 9, 0.86) 0%, rgba(12, 10, 9, 0.58) 42%, rgba(12, 10, 9, 0.08) 100%)',
      }}
      aria-label="Main Menu"
    >
      {/* Top Bar: Left Subtitle & Right Phase Indicator */}
      <div className="flex items-center justify-between gap-4 text-[11px] sm:text-xs font-semibold tracking-wider text-amber-200/95">
        <span className="whitespace-nowrap">INDIAN STREET FOOD SIMULATOR</span>
        <span
          className="rounded-lg border border-amber-400/30 px-2.5 py-1 font-mono tabular-nums whitespace-nowrap"
          style={{ backgroundColor: 'rgba(12, 10, 9, 0.72)' }}
        >
          PHASE 1 · LANDSCAPE 3D
        </span>
      </div>

      {/* Main Landscape Content: Left/Upper-Left Title & Menu Panel, Right Side Open 3D Stall Showcase */}
      <div
        className="my-auto flex w-full max-w-md flex-col items-start rounded-2xl border border-amber-400/25 p-4 sm:p-6 shadow-2xl transition-transform duration-200"
        style={{ backgroundColor: 'rgba(20, 17, 15, 0.88)' }}
      >
        <div className="flex items-center gap-4">
          {/* Bespoke Inline SVG Indian Street Cart & Golgappa Emblem */}
          <div className="shrink-0">
            <svg
              viewBox="0 0 120 72"
              className="h-12 w-20 sm:h-16 sm:w-28"
              role="img"
              aria-label="Pani Puri Stall Emblem"
            >
              <path
                d="M16 24 L26 8 L94 8 L104 24 Z"
                fill="#dc2626"
                stroke="#fbbf24"
                strokeWidth="2.5"
                strokeLinejoin="round"
              />
              <path d="M38 8 L34 24 L50 24 L52 8 Z" fill="#facc15" />
              <path d="M68 8 L66 24 L82 24 L78 8 Z" fill="#facc15" />
              <line x1="24" y1="24" x2="24" y2="48" stroke="#e2e8f0" strokeWidth="3" />
              <line x1="96" y1="24" x2="96" y2="48" stroke="#e2e8f0" strokeWidth="3" />
              <circle cx="44" cy="40" r="8" fill="#fbbf24" stroke="#78350f" strokeWidth="2" />
              <ellipse cx="44" cy="33" rx="5" ry="2.2" fill="#16a34a" />
              <circle cx="72" cy="42" r="5" fill="#f59e0b" stroke="#78350f" strokeWidth="1.5" />
              <circle cx="81" cy="42" r="5" fill="#f59e0b" stroke="#78350f" strokeWidth="1.5" />
              <circle cx="76.5" cy="36" r="5" fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
              <rect
                x="18"
                y="47"
                width="84"
                height="14"
                rx="3"
                fill="#d97706"
                stroke="#fef08a"
                strokeWidth="2"
              />
              <circle cx="32" cy="62" r="7" fill="#451a03" stroke="#fbbf24" strokeWidth="2.5" />
              <circle cx="88" cy="62" r="7" fill="#451a03" stroke="#fbbf24" strokeWidth="2.5" />
            </svg>
          </div>

          <div className="text-left">
            <h1
              className="font-display text-2xl sm:text-4xl font-extrabold tracking-tight text-amber-50"
              style={{
                textShadow: '0 3px 14px rgba(0, 0, 0, 0.75)',
              }}
            >
              PANI PURI SIMULATOR 3D
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-stone-300">
              Explore the modern Indian neighborhood and inspect your central street stall.
            </p>
          </div>
        </div>

        {/* Three Required Menu Buttons: START, SHOP, CONNECT arranged for Landscape ergonomics */}
        <nav
          className="mt-5 grid w-full grid-cols-1 sm:grid-cols-3 gap-3"
          aria-label="Primary Game Actions"
        >
          <button
            type="button"
            data-start="true"
            onClick={(e) => {
              e.currentTarget.blur();
              soundManager.playUiClick();
              onStartGame();
            }}
            className="min-h-[48px] w-full cursor-pointer rounded-xl bg-amber-500 px-5 py-3 font-display text-base sm:text-lg font-bold tracking-wide text-stone-950 shadow-lg transition-transform duration-150 hover:bg-amber-400 active:scale-[0.98] whitespace-nowrap"
          >
            START
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playUiClick();
              onOpenShop();
            }}
            className="min-h-[48px] w-full cursor-pointer rounded-xl border border-amber-300/35 px-5 py-3 font-display text-sm sm:text-base font-bold tracking-wide text-amber-100 transition-colors duration-150 hover:bg-stone-800/90 active:scale-[0.98] whitespace-nowrap"
            style={{ backgroundColor: 'rgba(28, 25, 23, 0.92)' }}
          >
            SHOP
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playUiClick();
              onOpenConnect();
            }}
            className="min-h-[48px] w-full cursor-pointer rounded-xl border border-stone-600/60 px-5 py-3 font-display text-sm sm:text-base font-bold tracking-wide text-stone-200 transition-colors duration-150 hover:bg-stone-800/90 active:scale-[0.98] whitespace-nowrap"
            style={{ backgroundColor: 'rgba(28, 25, 23, 0.92)' }}
          >
            CONNECT
          </button>
        </nav>
      </div>

      {/* Bottom Flat Control Hint Line */}
      <div className="text-left text-[11px] sm:text-xs text-stone-200/90">
        WASD / Left Stick Move · Mouse / Right Touch Look · Shift Sprint · Space Jump · Esc Pause
      </div>
    </main>
  );
};
