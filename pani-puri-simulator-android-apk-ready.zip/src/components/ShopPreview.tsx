import React from 'react';
import {
  FoodPrepSessionState,
  getShopItemEffectivePrice,
  SHOP_ITEMS,
  SHOP_UPGRADES,
  ShopItemId,
  ShopUpgradeId,
} from '../game/foodPrepEngine';
import { RECIPES } from '../game/recipes';
import { soundManager } from '../utils/sound';
import {
  BackArrowIcon,
  CloseIcon,
  CoinIcon,
  ConfirmCheckIcon,
  ShopCartIcon,
  ShopItemSymbol,
} from './GameIcons';

interface ShopPreviewProps {
  foodPrep: FoodPrepSessionState;
  isInGame?: boolean;
  onBuyItem: (itemId: ShopItemId) => void;
  onBuyUpgrade: (upgradeId: ShopUpgradeId) => void;
  onBack: () => void;
}

export const ShopPreview: React.FC<ShopPreviewProps> = ({
  foodPrep,
  isInGame = false,
  onBuyItem,
  onBuyUpgrade,
  onBack,
}) => {
  const {
    coins,
    inventory,
    upgrades,
    customerLimit,
    selectedRecipeId,
    activePlate,
    statusBanner,
  } = foodPrep;

  const lastTxTimeRef = React.useRef<number>(0);

  const handleSafeBuyItem = (itemId: ShopItemId) => {
    const now = performance.now();
    if (now - lastTxTimeRef.current < 90) return;
    lastTxTimeRef.current = now;
    onBuyItem(itemId);
  };

  const handleSafeBuyUpgrade = (upgradeId: ShopUpgradeId) => {
    const now = performance.now();
    if (now - lastTxTimeRef.current < 90) return;
    lastTxTimeRef.current = now;
    onBuyUpgrade(upgradeId);
  };

  const isErrorBanner =
    statusBanner &&
    (statusBanner.includes('Not enough coins') || statusBanner.includes('already active'));

  return (
    <section
      role="dialog"
      aria-modal="true"
      aria-labelledby="shop-modal-heading"
      data-testid="in-game-shop-modal"
      className="fixed inset-0 z-30 flex items-center justify-center p-2 sm:p-4"
      style={{ backgroundColor: 'rgba(12, 10, 9, 0.84)' }}
    >
      <div
        className="flex max-h-[96vh] w-full max-w-3xl flex-col overflow-y-auto rounded-2xl border border-amber-400/35 px-3.5 py-2.5 sm:p-4 text-stone-100 shadow-2xl"
        style={{ backgroundColor: 'rgba(24, 21, 19, 0.97)' }}
      >
        {/* Top Header: Title, Active Order/Plate Preservation Badge, Coin Balance & Close/Back */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-amber-400/40 bg-amber-500/15 text-amber-300">
              <ShopCartIcon size={18} />
            </div>
            <div>
              <h2
                id="shop-modal-heading"
                className="font-display text-sm sm:text-lg font-extrabold text-amber-300 leading-tight"
              >
                Pani Puri Stall Supply Shop
              </h2>
              <p className="text-[10px] sm:text-[11px] text-stone-300 leading-tight">
                Restock +10 units per purchase · Order:{' '}
                <span className="font-semibold text-amber-200">
                  {RECIPES[selectedRecipeId].name}
                </span>
                {activePlate
                  ? ` · Active Plate (${activePlate.puris}/6 Puris preserved)`
                  : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Live Coin Balance & Customer Limit Readout */}
            <div
              data-testid="shop-coins-display"
              className="flex items-center gap-1.5 rounded-xl border border-amber-400/45 bg-stone-900 px-2.5 py-1 font-mono text-xs sm:text-sm font-bold text-amber-300 tabular-nums"
            >
              <CoinIcon size={15} />
              <span data-testid="shop-coin-value">{coins}</span>
              <span className="text-[10px] font-normal text-stone-300">Coins</span>
            </div>

            <div
              data-testid="shop-customer-limit"
              className="flex items-center gap-1 rounded-xl border border-stone-700 bg-stone-900 px-2.5 py-1 font-mono text-[11px] text-stone-200 tabular-nums"
            >
              <span>Max Customers:</span>
              <span className="font-bold text-emerald-400">{customerLimit}</span>
            </div>

            <button
              type="button"
              data-testid="close-shop-btn"
              aria-label={isInGame ? 'Close Shop' : 'Back to Menu'}
              title={isInGame ? 'Close Shop and Resume Game' : 'Back to Main Menu'}
              onClick={() => {
                soundManager.playUiClick();
                onBack();
              }}
              className="flex min-h-[34px] cursor-pointer items-center gap-1.5 rounded-xl bg-amber-500 px-3 py-1 font-display text-xs font-bold text-stone-950 transition-colors hover:bg-amber-400 active:scale-95 whitespace-nowrap"
            >
              {isInGame ? <CloseIcon size={15} /> : <BackArrowIcon size={15} />}
              <span>{isInGame ? 'Close' : 'Back'}</span>
            </button>
          </div>
        </div>

        {/* Purchase Feedback Banner */}
        {statusBanner &&
          (statusBanner.includes('Purchased') ||
            statusBanner.includes('Unlocked') ||
            statusBanner.includes('Not enough coins') ||
            statusBanner.includes('already active')) && (
            <div
              role="status"
              data-testid="shop-feedback-banner"
              className={`mt-1.5 flex items-center justify-between rounded-xl border px-3 py-1 text-[11px] font-semibold ${
                isErrorBanner
                  ? 'border-red-500/45 bg-red-950/60 text-red-200'
                  : 'border-emerald-500/45 bg-emerald-950/60 text-emerald-200'
              }`}
            >
              <span>{statusBanner}</span>
            </div>
          )}

        {/* Ingredients & Plates Grid (7 Items, +10 units per purchase) */}
        <div className="mt-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <h3 className="font-display font-bold text-amber-200">
              Ingredients & Serving Plates (+10 Units / Purchase)
            </h3>
            {upgrades.discount50 && (
              <span
                data-testid="discount-active-badge"
                className="font-mono text-[10px] font-bold text-emerald-400"
              >
                50% Discount Active! (Ingredients Only)
              </span>
            )}
          </div>

          <div className="mt-1 grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {SHOP_ITEMS.map((item) => {
              const effectivePrice = getShopItemEffectivePrice(
                item.basePrice,
                upgrades.discount50
              );
              const availableStock = inventory[item.inventoryKey];
              const canAfford = coins >= effectivePrice;

              return (
                <div
                  key={item.id}
                  data-testid={`shop-item-card-${item.id}`}
                  className="flex flex-col justify-between rounded-xl border border-stone-800 bg-stone-900/95 px-2.5 py-1.5 shadow"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-stone-700 bg-stone-950">
                      <ShopItemSymbol itemId={item.id} size={19} />
                    </div>
                    <div className="min-w-0">
                      <div className="truncate font-display text-[11px] font-bold text-stone-100 leading-tight">
                        {item.name}
                      </div>
                      <div
                        data-testid={`shop-stock-${item.id}`}
                        className="font-mono text-[10px] text-stone-300 tabular-nums leading-tight"
                      >
                        Stock: {availableStock}
                      </div>
                    </div>
                  </div>

                  <div className="mt-1.5 flex items-center justify-between gap-1.5 border-t border-stone-800/80 pt-1">
                    <div
                      data-testid={`shop-price-${item.id}`}
                      className="flex items-center gap-1 font-mono text-[11px] font-bold text-amber-300 tabular-nums"
                    >
                      <CoinIcon size={12} />
                      <span>{effectivePrice}</span>
                      {upgrades.discount50 && (
                        <span className="text-[9px] text-stone-500 line-through">
                          {item.basePrice}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      data-testid={`buy-item-${item.id}`}
                      disabled={!canAfford}
                      aria-label={`Buy 10 ${item.name} for ${effectivePrice} coins`}
                      title={`Buy +10 ${item.name} (${effectivePrice} coins)`}
                      onClick={() => handleSafeBuyItem(item.id)}
                      className={`flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg px-2 py-0.5 font-display text-[10px] font-bold transition-colors whitespace-nowrap ${
                        canAfford
                          ? 'bg-emerald-500 text-stone-950 hover:bg-emerald-400 active:scale-95'
                          : 'cursor-not-allowed bg-stone-800 text-stone-500'
                      }`}
                    >
                      <ShopCartIcon size={12} />
                      <span>+10</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* One-Time Stall Upgrades Section */}
        <div className="mt-2 border-t border-stone-800 pt-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <h3 className="font-display font-bold text-amber-200">
              Stall Upgrades (One-Time Unlock)
            </h3>
            <span className="font-mono text-[10px] text-stone-300 tabular-nums">
              Customer Limit: {customerLimit}
            </span>
          </div>

          <div className="mt-1 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {SHOP_UPGRADES.map((up) => {
              const isOwned =
                up.id === 'more_customers'
                  ? upgrades.moreCustomers
                  : upgrades.discount50;
              const canAfford = coins >= up.price && !isOwned;

              return (
                <div
                  key={up.id}
                  data-testid={`shop-upgrade-card-${up.id}`}
                  className="flex items-center justify-between gap-2 rounded-xl border border-stone-800 bg-stone-900/95 px-2.5 py-1.5"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-display text-[11px] font-bold text-amber-200">
                        {up.name}
                      </span>
                      {isOwned && (
                        <span
                          data-testid={`upgrade-owned-${up.id}`}
                          className="font-mono text-[10px] font-bold text-emerald-400"
                        >
                          · Owned
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-stone-400 leading-tight">
                      {up.description}
                    </p>
                  </div>

                  <button
                    type="button"
                    data-testid={`buy-upgrade-${up.id}`}
                    disabled={isOwned || !canAfford}
                    aria-label={
                      isOwned
                        ? `${up.name} Already Owned`
                        : `Buy ${up.name} for ${up.price} coins`
                    }
                    onClick={() => handleSafeBuyUpgrade(up.id)}
                    className={`flex min-h-[28px] shrink-0 cursor-pointer items-center gap-1 rounded-lg px-2.5 py-1 font-display text-[11px] font-bold transition-colors whitespace-nowrap ${
                      isOwned
                        ? 'cursor-default border border-emerald-500/40 bg-emerald-950/60 text-emerald-300'
                        : canAfford
                          ? 'bg-amber-500 text-stone-950 hover:bg-amber-400 active:scale-95'
                          : 'cursor-not-allowed bg-stone-800 text-stone-500'
                    }`}
                  >
                    {isOwned ? (
                      <>
                        <ConfirmCheckIcon size={13} />
                        <span>Active</span>
                      </>
                    ) : (
                      <>
                        <CoinIcon size={12} />
                        <span>{up.price}</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
