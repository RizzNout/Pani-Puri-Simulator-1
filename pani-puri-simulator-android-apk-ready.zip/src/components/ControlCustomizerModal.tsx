import React from 'react';
import {
  ALL_CONTROL_IDS,
  CONTROL_METADATA,
  CONTROL_SIZE_PRESETS,
  ControlId,
  ControlLayoutMap,
  ControlOverlapPair,
  getMatchingSizePreset,
} from '../game/controlLayout';
import { soundManager } from '../utils/sound';
import {
  CloseIcon,
  ConfirmCheckIcon,
  ResetArrowIcon,
  SaveDiskIcon,
  SettingsGearIcon,
} from './GameIcons';

interface ControlCustomizerModalProps {
  draftLayout: ControlLayoutMap;
  selectedControlId: ControlId;
  overlaps: ControlOverlapPair[];
  savedFeedbackMessage: string | null;
  onSelectControl: (id: ControlId) => void;
  onResizeControl: (id: ControlId, scale: number) => void;
  onResetSelected: () => void;
  onResetAll: () => void;
  onSaveLayout: () => void;
  onCancel: () => void;
  onDone: () => void;
}

export const ControlCustomizerModal: React.FC<ControlCustomizerModalProps> = ({
  draftLayout,
  selectedControlId,
  overlaps,
  savedFeedbackMessage,
  onSelectControl,
  onResizeControl,
  onResetSelected,
  onResetAll,
  onSaveLayout,
  onCancel,
  onDone,
}) => {
  const selectedPlacement = draftLayout[selectedControlId];
  const selectedMeta = CONTROL_METADATA[selectedControlId];
  const currentPercent = Math.round((selectedPlacement?.scale ?? 1.0) * 100);
  const matchingPreset = getMatchingSizePreset(selectedPlacement?.scale ?? 1.0);

  return (
    <section
      role="dialog"
      aria-modal="false"
      aria-label="Control Customization"
      data-testid="control-customizer-panel"
      className="pointer-events-none fixed inset-x-0 top-0 z-30 flex flex-col items-center px-3 pt-1.5"
    >
      <div
        className="pointer-events-auto flex w-full max-w-2xl flex-col gap-1 rounded-2xl border border-amber-400/50 px-3 py-2 text-stone-100 shadow-2xl"
        style={{ backgroundColor: 'rgba(18, 16, 14, 0.94)' }}
      >
        {/* Header Row + Exact Required Instruction */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-800 pb-1">
          <div className="flex items-center gap-1.5">
            <SettingsGearIcon size={15} className="text-amber-400 shrink-0" />
            <h2 className="font-display text-xs font-extrabold text-amber-300">
              Customize Controls
            </h2>
          </div>
          <p
            data-testid="customizer-instruction"
            className="text-[10px] font-medium text-stone-200"
          >
            Drag buttons to move them. Select a button to resize it. Save when finished.
          </p>
        </div>

        {/* Control Selector Pills + Current Coordinates */}
        <div className="flex flex-wrap items-center justify-between gap-1">
          <div className="flex items-center gap-1 flex-wrap">
            <span className="text-[10px] font-semibold text-stone-400 mr-0.5">
              Selected Button:
            </span>
            {ALL_CONTROL_IDS.map((id) => {
              const isSelected = id === selectedControlId;
              return (
                <button
                  key={id}
                  type="button"
                  data-testid={`select-control-${id}`}
                  onClick={() => {
                    soundManager.playUiClick();
                    onSelectControl(id);
                  }}
                  className={`cursor-pointer rounded-lg px-2 py-0.5 font-display text-[10px] font-bold transition-colors whitespace-nowrap ${
                    isSelected
                      ? 'bg-amber-400 text-stone-950 shadow'
                      : 'border border-stone-700 bg-stone-900 text-stone-300 hover:text-amber-200'
                  }`}
                >
                  {CONTROL_METADATA[id].shortLabel}
                </button>
              );
            })}
          </div>

          <span
            data-testid="selected-control-readout"
            className="font-mono text-[10px] text-amber-200 tabular-nums whitespace-nowrap"
          >
            {selectedMeta.label} · X:{Math.round(selectedPlacement.xPercent)}% Y:
            {Math.round(selectedPlacement.yPercent)}% · {currentPercent}%
          </span>
        </div>

        {/* Size Presets (4-column single row) + Dropdown + Continuous Slider (70% to 150%) */}
        <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 rounded-xl border border-stone-800 bg-stone-900/90 px-2.5 py-1">
          {/* Quick Size Preset Segmented Buttons */}
          <div className="grid grid-cols-4 gap-1 shrink-0">
            {CONTROL_SIZE_PRESETS.map((preset) => {
              const active = matchingPreset === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  data-testid={`size-preset-${preset.id}`}
                  onClick={() => {
                    soundManager.playUiClick();
                    onResizeControl(selectedControlId, preset.scale);
                  }}
                  className={`min-h-[24px] cursor-pointer rounded-lg px-1.5 py-0.5 font-display text-[10px] font-bold transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-amber-500 text-stone-950'
                      : 'border border-stone-700 bg-stone-800 text-stone-300 hover:bg-stone-700'
                  }`}
                >
                  {preset.shortLabel} ({preset.percent}%)
                </button>
              );
            })}
          </div>

          {/* Continuous Size Slider (70% - 150%) + Preset Dropdown */}
          <div className="flex flex-1 items-center gap-1.5 min-w-[180px]">
            <label
              htmlFor="control-size-slider"
              className="text-[10px] font-semibold text-stone-300 whitespace-nowrap"
            >
              Size:
            </label>
            <input
              id="control-size-slider"
              data-testid="control-size-slider"
              type="range"
              min={70}
              max={150}
              step={1}
              value={currentPercent}
              onChange={(e) => {
                const nextPct = parseInt(e.target.value, 10);
                onResizeControl(selectedControlId, nextPct / 100);
              }}
              className="w-full cursor-pointer accent-amber-500"
            />
            <select
              aria-label="Button Size Preset Dropdown"
              data-testid="control-size-dropdown"
              value={matchingPreset}
              onChange={(e) => {
                const val = e.target.value;
                const found = CONTROL_SIZE_PRESETS.find((p) => p.id === val);
                if (found) {
                  soundManager.playUiClick();
                  onResizeControl(selectedControlId, found.scale);
                }
              }}
              className="rounded border border-stone-700 bg-stone-800 px-1 py-0.5 font-mono text-[10px] text-amber-200"
            >
              {CONTROL_SIZE_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.shortLabel} ({p.percent}%)
                </option>
              ))}
              {matchingPreset === 'custom' && (
                <option value="custom">Custom ({currentPercent}%)</option>
              )}
            </select>
          </div>
        </div>

        {/* Significant Overlap Warning (if any controls overlap significantly) */}
        {overlaps.length > 0 && (
          <div
            role="alert"
            data-testid="control-overlap-warning"
            className="rounded-lg border border-amber-400/60 bg-amber-950/80 px-2 py-0.5 text-[10px] font-semibold text-amber-200"
          >
            Warning: Controls overlap significantly (
            {overlaps
              .map((o) => `${o.firstLabel} & ${o.secondLabel}`)
              .join(', ')}
            ). Intentional overlap is allowed, or drag them apart.
          </div>
        )}

        {savedFeedbackMessage && (
          <div
            role="status"
            data-testid="customizer-save-feedback"
            className="rounded-lg border border-emerald-400/50 bg-emerald-950/80 px-2 py-0.5 text-center text-[10px] font-bold text-emerald-200"
          >
            {savedFeedbackMessage}
          </div>
        )}

        {/* Action Bar: Reset Selected | Reset All | Save Layout | Cancel | Done */}
        <div className="flex flex-wrap items-center justify-between gap-1.5">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              data-testid="reset-selected-control-btn"
              title="Reset Selected Button"
              onClick={() => {
                soundManager.playUiClick();
                onResetSelected();
              }}
              className="flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg border border-stone-700 bg-stone-800 px-2 py-0.5 font-display text-[10px] font-bold text-stone-200 hover:bg-stone-700 whitespace-nowrap"
            >
              <ResetArrowIcon size={12} />
              <span>Reset Selected Button</span>
            </button>

            <button
              type="button"
              data-testid="reset-all-controls-btn"
              title="Reset All Controls"
              onClick={() => {
                soundManager.playUiClick();
                onResetAll();
              }}
              className="flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg border border-stone-700 bg-stone-800 px-2 py-0.5 font-display text-[10px] font-bold text-stone-200 hover:bg-stone-700 whitespace-nowrap"
            >
              <ResetArrowIcon size={12} />
              <span>Reset All Controls</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              data-testid="save-layout-btn"
              title="Save Layout"
              onClick={() => {
                soundManager.playUiClick();
                onSaveLayout();
              }}
              className="flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg border border-emerald-400/50 bg-emerald-700/90 px-2.5 py-0.5 font-display text-[10px] font-bold text-white hover:bg-emerald-600 whitespace-nowrap"
            >
              <SaveDiskIcon size={12} />
              <span>Save Layout</span>
            </button>

            <button
              type="button"
              data-testid="cancel-customizer-btn"
              title="Cancel and Discard Unsaved Changes"
              onClick={() => {
                soundManager.playUiClick();
                onCancel();
              }}
              className="flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg border border-red-400/40 bg-red-950/60 px-2.5 py-0.5 font-display text-[10px] font-bold text-red-200 hover:bg-red-900/60 whitespace-nowrap"
            >
              <CloseIcon size={12} />
              <span>Cancel</span>
            </button>

            <button
              type="button"
              data-testid="done-customizer-btn"
              title="Save and Finish Customization"
              onClick={() => {
                soundManager.playUiClick();
                onDone();
              }}
              className="flex min-h-[26px] cursor-pointer items-center gap-1 rounded-lg bg-amber-500 px-3 py-0.5 font-display text-[11px] font-extrabold text-stone-950 hover:bg-amber-400 whitespace-nowrap"
            >
              <ConfirmCheckIcon size={13} />
              <span>Done</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
