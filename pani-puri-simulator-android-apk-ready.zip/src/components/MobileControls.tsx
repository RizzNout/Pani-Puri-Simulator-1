import React, { useEffect, useRef, useState } from 'react';
import { PlayerInputController } from '../game/playerController';
import { soundManager } from '../utils/sound';
import { HeldItemId, ITEM_DISPLAY_NAMES } from '../game/recipes';
import { isContainerItem } from '../game/foodPrepEngine';
import {
  clampControlPlacement,
  CONTROL_METADATA,
  ControlId,
  ControlLayoutMap,
} from '../game/controlLayout';
import {
  JumpIcon,
  PickDropIcon,
  PourIcon,
  PutDownIcon,
  SprintIcon,
} from './GameIcons';

interface MobileControlsProps {
  inputController: PlayerInputController;
  isSprinting: boolean;
  heldItem: HeldItemId | null;
  isPouring: boolean;
  controlLayout: ControlLayoutMap;
  isCustomizing?: boolean;
  selectedControlId?: ControlId;
  overlappingIds?: Set<ControlId>;
  onSelectControl?: (id: ControlId) => void;
  onMoveControl?: (id: ControlId, xPercent: number, yPercent: number) => void;
  onPickOrDrop: () => void;
  onPutDownContainer: () => void;
  onPourStart: () => void;
  onPourEnd: () => void;
}

const BASE_JOYSTICK_MAX_RADIUS = 42;

export const MobileControls: React.FC<MobileControlsProps> = ({
  inputController,
  isSprinting,
  heldItem,
  isPouring,
  controlLayout,
  isCustomizing = false,
  selectedControlId,
  overlappingIds,
  onSelectControl,
  onMoveControl,
  onPickOrDrop,
  onPutDownContainer,
  onPourStart,
  onPourEnd,
}) => {
  const joystickBaseRef = useRef<HTMLDivElement | null>(null);
  const activeJoystickTouchId = useRef<number | null>(null);
  const activeLookTouchId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isPointerJoystickActive = useRef(false);
  const isPointerLookActive = useRef(false);

  // Dragging state for Control Customization mode
  const draggingControlRef = useRef<{
    id: ControlId;
    offsetX: number;
    offsetY: number;
  } | null>(null);

  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [sprintLocked, setSprintLocked] = useState(false);
  const [viewportSize, setViewportSize] = useState<{ w: number; h: number }>(() => ({
    w: typeof window !== 'undefined' ? window.innerWidth : 844,
    h: typeof window !== 'undefined' ? window.innerHeight : 390,
  }));

  useEffect(() => {
    const onResize = () => {
      setViewportSize({
        w: window.innerWidth,
        h: window.innerHeight,
      });
    };
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
    };
  }, []);

  // Reset active inputs if entering customization mode
  useEffect(() => {
    if (isCustomizing) {
      activeJoystickTouchId.current = null;
      isPointerJoystickActive.current = false;
      setKnobOffset({ x: 0, y: 0 });
      inputController.clearAllInputs();
    }
  }, [isCustomizing, inputController]);

  // Global window pointer/touch move & up handlers for smooth dragging in Customization Mode
  useEffect(() => {
    if (!isCustomizing) {
      draggingControlRef.current = null;
      return;
    }

    const updateDraggedPosition = (clientX: number, clientY: number) => {
      const drag = draggingControlRef.current;
      if (!drag || !onMoveControl) return;
      const w = Math.max(320, window.innerWidth);
      const h = Math.max(240, window.innerHeight);
      const rawXPercent = ((clientX - drag.offsetX) / w) * 100;
      const rawYPercent = ((clientY - drag.offsetY) / h) * 100;
      const currentScale = controlLayout[drag.id]?.scale ?? 1.0;
      const clamped = clampControlPlacement(
        drag.id,
        { xPercent: rawXPercent, yPercent: rawYPercent, scale: currentScale },
        w,
        h
      );
      onMoveControl(drag.id, clamped.xPercent, clamped.yPercent);
    };

    const handleWindowPointerMove = (e: PointerEvent) => {
      if (!draggingControlRef.current) return;
      e.preventDefault();
      updateDraggedPosition(e.clientX, e.clientY);
    };

    const handleWindowPointerUp = () => {
      draggingControlRef.current = null;
    };

    const handleWindowTouchMove = (e: TouchEvent) => {
      if (!draggingControlRef.current || e.touches.length === 0) return;
      e.preventDefault();
      const t = e.touches[0];
      updateDraggedPosition(t.clientX, t.clientY);
    };

    const handleWindowTouchEnd = () => {
      draggingControlRef.current = null;
    };

    window.addEventListener('pointermove', handleWindowPointerMove, { passive: false });
    window.addEventListener('pointerup', handleWindowPointerUp);
    window.addEventListener('pointercancel', handleWindowPointerUp);
    window.addEventListener('touchmove', handleWindowTouchMove, { passive: false });
    window.addEventListener('touchend', handleWindowTouchEnd);
    window.addEventListener('touchcancel', handleWindowTouchEnd);

    return () => {
      window.removeEventListener('pointermove', handleWindowPointerMove);
      window.removeEventListener('pointerup', handleWindowPointerUp);
      window.removeEventListener('pointercancel', handleWindowPointerUp);
      window.removeEventListener('touchmove', handleWindowTouchMove);
      window.removeEventListener('touchend', handleWindowTouchEnd);
      window.removeEventListener('touchcancel', handleWindowTouchEnd);
    };
  }, [isCustomizing, controlLayout, onMoveControl]);

  const startCustomDrag = (
    id: ControlId,
    clientX: number,
    clientY: number,
    element: HTMLElement
  ) => {
    onSelectControl?.(id);
    const rect = element.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    draggingControlRef.current = {
      id,
      offsetX: clientX - centerX,
      offsetY: clientY - centerY,
    };
  };

  const joystickPlacement = clampControlPlacement(
    'joystick',
    controlLayout.joystick,
    viewportSize.w,
    viewportSize.h
  );
  const joystickMaxRadius = BASE_JOYSTICK_MAX_RADIUS * joystickPlacement.scale;

  const updateJoystickFromClientXY = (clientX: number, clientY: number) => {
    if (isCustomizing) return;
    const baseEl = joystickBaseRef.current;
    if (!baseEl) return;
    const rect = baseEl.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);

    if (dist > joystickMaxRadius) {
      dx = (dx / dist) * joystickMaxRadius;
      dy = (dy / dist) * joystickMaxRadius;
    }

    setKnobOffset({ x: dx, y: dy });

    // Normalize to -1..1 so resizing never changes movement speed
    const normX = joystickMaxRadius > 0 ? dx / joystickMaxRadius : 0;
    const normZ = joystickMaxRadius > 0 ? -dy / joystickMaxRadius : 0;
    inputController.setJoystickVector(normX, normZ);
  };

  const resetJoystick = () => {
    activeJoystickTouchId.current = null;
    isPointerJoystickActive.current = false;
    setKnobOffset({ x: 0, y: 0 });
    inputController.setJoystickVector(0, 0);
  };

  // --- Multi-touch handlers for Left Movement Joystick ---
  const handleJoystickTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const touch = e.changedTouches[0];
    if (!touch) return;
    if (isCustomizing) {
      startCustomDrag('joystick', touch.clientX, touch.clientY, e.currentTarget);
      return;
    }
    if (activeJoystickTouchId.current !== null) return;
    activeJoystickTouchId.current = touch.identifier;
    updateJoystickFromClientXY(touch.clientX, touch.clientY);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (isCustomizing || activeJoystickTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === activeJoystickTouchId.current) {
        updateJoystickFromClientXY(t.clientX, t.clientY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (isCustomizing || activeJoystickTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === activeJoystickTouchId.current) {
        resetJoystick();
        break;
      }
    }
  };

  const handleJoystickPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (isCustomizing) {
      startCustomDrag('joystick', e.clientX, e.clientY, e.currentTarget);
      return;
    }
    if (e.pointerType === 'touch') return;
    e.currentTarget.setPointerCapture(e.pointerId);
    isPointerJoystickActive.current = true;
    updateJoystickFromClientXY(e.clientX, e.clientY);
  };

  const handleJoystickPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isCustomizing || e.pointerType === 'touch' || !isPointerJoystickActive.current) return;
    e.stopPropagation();
    updateJoystickFromClientXY(e.clientX, e.clientY);
  };

  const handleJoystickPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isCustomizing || e.pointerType === 'touch' || !isPointerJoystickActive.current) return;
    e.stopPropagation();
    resetJoystick();
  };

  // --- Multi-touch handlers for Right Camera-Look Area ---
  const handleLookTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (isCustomizing || activeLookTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    if (!touch) return;
    activeLookTouchId.current = touch.identifier;
    lastLookPos.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (isCustomizing || activeLookTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === activeLookTouchId.current) {
        const dx = t.clientX - lastLookPos.current.x;
        const dy = t.clientY - lastLookPos.current.y;
        lastLookPos.current = { x: t.clientX, y: t.clientY };
        inputController.addTouchLookDelta(dx, dy);
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (activeLookTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === activeLookTouchId.current) {
        activeLookTouchId.current = null;
        break;
      }
    }
  };

  const handleLookPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isCustomizing || e.pointerType === 'touch') return;
    e.currentTarget.setPointerCapture(e.pointerId);
    isPointerLookActive.current = true;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
  };

  const handleLookPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isCustomizing || e.pointerType === 'touch' || !isPointerLookActive.current) return;
    const dx = e.clientX - lastLookPos.current.x;
    const dy = e.clientY - lastLookPos.current.y;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
    inputController.addTouchLookDelta(dx, dy);
  };

  const handleLookPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    isPointerLookActive.current = false;
  };

  const toggleSprint = () => {
    if (isCustomizing) return;
    const next = !sprintLocked;
    setSprintLocked(next);
    inputController.setMobileSprint(next);
    soundManager.playUiClick();
  };

  const sprintActive = sprintLocked || isSprinting;
  const heldLabel = heldItem ? ITEM_DISPLAY_NAMES[heldItem] : 'Pick/Drop';
  const showPutDown = isCustomizing || isContainerItem(heldItem);

  const getControlStyle = (id: ControlId): React.CSSProperties => {
    const p = clampControlPlacement(id, controlLayout[id], viewportSize.w, viewportSize.h);
    const meta = CONTROL_METADATA[id];
    const widthPx = Math.round(meta.baseWidth * p.scale);
    const heightPx = Math.round(meta.baseHeight * p.scale);

    return {
      left: `${p.xPercent}%`,
      top: `${p.yPercent}%`,
      width: `${widthPx}px`,
      height: `${heightPx}px`,
      transform: 'translate(-50%, -50%)',
      touchAction: 'none',
    };
  };

  const getCustomOutlineClass = (id: ControlId) => {
    if (!isCustomizing) return '';
    const isSelected = selectedControlId === id;
    const isOverlapping = overlappingIds?.has(id);
    if (isSelected) {
      return 'ring-4 ring-amber-400 border-amber-200 shadow-[0_0_20px_rgba(251,191,36,0.55)] z-40';
    }
    if (isOverlapping) {
      return 'ring-2 ring-red-400 border-red-300 z-30';
    }
    return 'ring-2 ring-stone-400/50 hover:ring-amber-300/80 z-30';
  };

  const renderCustomizationBadge = (id: ControlId) => {
    if (!isCustomizing) return null;
    const scalePct = Math.round((controlLayout[id]?.scale ?? 1) * 100);
    const isSelected = selectedControlId === id;
    return (
      <span
        className={`pointer-events-none absolute -top-5 left-1/2 -translate-x-1/2 rounded px-1.5 py-0.5 font-mono text-[9px] font-bold whitespace-nowrap shadow ${
          isSelected ? 'bg-amber-400 text-stone-950' : 'bg-stone-900/95 text-stone-200'
        }`}
      >
        {CONTROL_METADATA[id].shortLabel} · {scalePct}%
      </span>
    );
  };

  const sprintScale = controlLayout.sprint?.scale ?? 1;
  const jumpScale = controlLayout.jump?.scale ?? 1;
  const pickDropScale = controlLayout.pick_drop?.scale ?? 1;
  const pourScale = controlLayout.pour?.scale ?? 1;
  const putDownScale = controlLayout.put_down?.scale ?? 1;

  return (
    <>
      {/* RIGHT SIDE: Dedicated Camera-Look Touch Area (Disabled during Customization Mode) */}
      {!isCustomizing && (
        <div
          data-testid="camera-look-zone"
          role="region"
          aria-label="Camera Look Touch Area"
          onTouchStart={handleLookTouchStart}
          onTouchMove={handleLookTouchMove}
          onTouchEnd={handleLookTouchEnd}
          onTouchCancel={handleLookTouchEnd}
          onPointerDown={handleLookPointerDown}
          onPointerMove={handleLookPointerMove}
          onPointerUp={handleLookPointerUp}
          onPointerCancel={handleLookPointerUp}
          className="pointer-events-auto fixed top-14 right-0 bottom-0 w-1/2 z-10"
        />
      )}

      {/* 1. VIRTUAL JOYSTICK (Directional Symbol Graphic) */}
      <div
        ref={joystickBaseRef}
        data-testid="movement-joystick"
        data-control-id="joystick"
         data-scale={joystickPlacement.scale}
        role="slider"
        aria-label="Movement Joystick"
        title="Movement Joystick (WASD / Drag)"
        aria-valuetext={`X ${knobOffset.x.toFixed(0)}, Y ${knobOffset.y.toFixed(0)}`}
        tabIndex={-1}
        style={{
          ...getControlStyle('joystick'),
          backgroundColor: 'rgba(12, 10, 9, 0.68)',
        }}
        onTouchStart={handleJoystickTouchStart}
        onTouchMove={handleJoystickTouchMove}
        onTouchEnd={handleJoystickTouchEnd}
        onTouchCancel={handleJoystickTouchEnd}
        onPointerDown={handleJoystickPointerDown}
        onPointerMove={handleJoystickPointerMove}
        onPointerUp={handleJoystickPointerUp}
        onPointerCancel={handleJoystickPointerUp}
        className={`pointer-events-auto fixed z-20 flex cursor-grab active:cursor-grabbing items-center justify-center rounded-full border-2 border-amber-300/50 shadow-xl ${getCustomOutlineClass(
          'joystick'
        )}`}
      >
        {renderCustomizationBadge('joystick')}
        <span className="pointer-events-none absolute top-1.5 text-[10px] font-bold text-amber-200/70">
          ▲
        </span>
        <span className="pointer-events-none absolute bottom-1.5 text-[10px] font-bold text-amber-200/70">
          ▼
        </span>
        <span className="pointer-events-none absolute left-2 text-[10px] font-bold text-amber-200/70">
          ◀
        </span>
        <span className="pointer-events-none absolute right-2 text-[10px] font-bold text-amber-200/70">
          ▶
        </span>

        <div
          className="pointer-events-none flex items-center justify-center rounded-full border-2 border-amber-100 bg-amber-500 shadow-md transition-transform duration-75"
          style={{
            width: `${Math.round(44 * joystickPlacement.scale)}px`,
            height: `${Math.round(44 * joystickPlacement.scale)}px`,
            transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
          }}
        >
          <div
            className="rounded-full bg-stone-950/35"
            style={{
              width: `${Math.round(14 * joystickPlacement.scale)}px`,
              height: `${Math.round(14 * joystickPlacement.scale)}px`,
            }}
          />
        </div>
      </div>

      {/* 2. SPRINT BUTTON (Symbol: Running Person Icon) */}
      <button
        type="button"
        data-testid="sprint-btn"
        data-control-id="sprint"
        data-scale={sprintScale}
        tabIndex={-1}
        aria-label="Sprint"
        title="Sprint (Shift)"
        aria-pressed={sprintActive}
        style={{
          ...getControlStyle('sprint'),
          backgroundColor: sprintActive ? undefined : 'rgba(28, 25, 23, 0.90)',
        }}
        onPointerDown={(e) => {
          e.stopPropagation();
          if (isCustomizing) {
            startCustomDrag('sprint', e.clientX, e.clientY, e.currentTarget);
          }
        }}
        onTouchStart={(e) => {
          e.stopPropagation();
          const t = e.changedTouches[0];
          if (isCustomizing && t) {
            startCustomDrag('sprint', t.clientX, t.clientY, e.currentTarget);
            return;
          }
          inputController.setMobileSprint(true);
        }}
        onTouchEnd={(e) => {
          e.stopPropagation();
          if (isCustomizing) return;
          if (!sprintLocked) inputController.setMobileSprint(false);
        }}
        onClick={(e) => {
          e.currentTarget.blur();
          if (isCustomizing) {
            onSelectControl?.('sprint');
            return;
          }
          toggleSprint();
        }}
        className={`pointer-events-auto fixed z-20 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 shadow-lg transition-transform active:scale-95 ${
          sprintActive
            ? 'border-amber-200 bg-amber-500 text-stone-950'
            : 'border-amber-300/45 text-amber-100'
        } ${getCustomOutlineClass('sprint')}`}
      >
        {renderCustomizationBadge('sprint')}
        <SprintIcon size={Math.round(24 * sprintScale)} />
        <span
          className="mt-0.5 font-display font-bold leading-none whitespace-nowrap"
          style={{ fontSize: `${Math.max(9, Math.round(10 * sprintScale))}px` }}
        >
          Sprint
        </span>
      </button>

      {/* 3. INTERACT / PUT DOWN BUTTON (Symbol: Put Down Icon) */}
      {showPutDown && (
        <button
          type="button"
          data-testid="put-down-btn"
          data-control-id="put_down"
          data-scale={putDownScale}
          tabIndex={-1}
          aria-label="Put Down"
          title="Put Down Container (Q)"
          style={{
            ...getControlStyle('put_down'),
            backgroundColor: 'rgba(28, 25, 23, 0.90)',
          }}
          onPointerDown={(e) => {
            e.stopPropagation();
            if (isCustomizing) {
              startCustomDrag('put_down', e.clientX, e.clientY, e.currentTarget);
            }
          }}
          onTouchStart={(e) => {
            e.stopPropagation();
            const t = e.changedTouches[0];
            if (isCustomizing && t) {
              startCustomDrag('put_down', t.clientX, t.clientY, e.currentTarget);
            }
          }}
          onClick={(e) => {
            e.currentTarget.blur();
            if (isCustomizing) {
              onSelectControl?.('put_down');
              return;
            }
            onPutDownContainer();
          }}
          className={`pointer-events-auto fixed z-20 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-amber-400/50 text-amber-200 shadow-lg transition-transform active:scale-95 ${getCustomOutlineClass(
            'put_down'
          )}`}
        >
          {renderCustomizationBadge('put_down')}
          <PutDownIcon size={Math.round(21 * putDownScale)} />
          <span
            className="mt-0.5 font-display font-bold leading-none whitespace-nowrap"
            style={{ fontSize: `${Math.max(8, Math.round(9 * putDownScale))}px` }}
          >
            Put Down
          </span>
        </button>
      )}

      {/* 4. PICK / DROP BUTTON (Symbol: Hand Icon) */}
      <button
        type="button"
        data-testid="pick-drop-btn"
        data-control-id="pick_drop"
        data-scale={pickDropScale}
        tabIndex={-1}
        aria-label="Pick/Drop"
        title={`Pick Up or Drop (${heldLabel})`}
        style={{
          ...getControlStyle('pick_drop'),
          backgroundColor: 'rgba(28, 25, 23, 0.90)',
        }}
        onPointerDown={(e) => {
          e.stopPropagation();
          if (isCustomizing) {
            startCustomDrag('pick_drop', e.clientX, e.clientY, e.currentTarget);
          }
        }}
        onTouchStart={(e) => {
          e.stopPropagation();
          const t = e.changedTouches[0];
          if (isCustomizing && t) {
            startCustomDrag('pick_drop', t.clientX, t.clientY, e.currentTarget);
          }
        }}
        onClick={(e) => {
          e.currentTarget.blur();
          if (isCustomizing) {
            onSelectControl?.('pick_drop');
            return;
          }
          onPickOrDrop();
        }}
        className={`pointer-events-auto fixed z-20 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-amber-300/55 text-amber-100 shadow-lg transition-transform active:scale-95 ${getCustomOutlineClass(
          'pick_drop'
        )}`}
      >
        {renderCustomizationBadge('pick_drop')}
        <PickDropIcon size={Math.round(24 * pickDropScale)} />
        <span
          className="mt-0.5 max-w-[92%] truncate font-display font-bold leading-none text-amber-300"
          style={{ fontSize: `${Math.max(9, Math.round(10 * pickDropScale))}px` }}
        >
          {heldLabel}
        </span>
      </button>

      {/* 5. JUMP BUTTON (Symbol: Upward Jump Icon, Directly Above Pour by Default) */}
      <button
        type="button"
        data-testid="jump-btn"
        data-control-id="jump"
        data-scale={jumpScale}
        tabIndex={-1}
        aria-label="Jump"
        title="Jump (Space)"
        style={getControlStyle('jump')}
        onTouchStart={(e) => {
          e.stopPropagation();
          const t = e.changedTouches[0];
          if (isCustomizing && t) {
            startCustomDrag('jump', t.clientX, t.clientY, e.currentTarget);
            return;
          }
          inputController.setMobileJump(true);
        }}
        onTouchEnd={(e) => {
          e.stopPropagation();
          if (isCustomizing) return;
          inputController.setMobileJump(false);
        }}
        onTouchCancel={(e) => {
          e.stopPropagation();
          inputController.setMobileJump(false);
        }}
        onPointerDown={(e) => {
          e.stopPropagation();
          if (isCustomizing) {
            startCustomDrag('jump', e.clientX, e.clientY, e.currentTarget);
            return;
          }
          inputController.setMobileJump(true);
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          if (isCustomizing) return;
          inputController.setMobileJump(false);
        }}
        onPointerCancel={() => inputController.setMobileJump(false)}
        onClick={(e) => {
          e.currentTarget.blur();
          if (isCustomizing) {
            onSelectControl?.('jump');
            return;
          }
          inputController.setMobileJump(true);
          window.setTimeout(() => inputController.setMobileJump(false), 90);
        }}
        className={`pointer-events-auto fixed z-20 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-amber-300/60 bg-amber-500/95 text-stone-950 shadow-lg transition-transform active:scale-95 ${getCustomOutlineClass(
          'jump'
        )}`}
      >
        {renderCustomizationBadge('jump')}
        <JumpIcon size={Math.round(24 * jumpScale)} />
        <span
          className="mt-0.5 font-display font-bold leading-none whitespace-nowrap"
          style={{ fontSize: `${Math.max(9, Math.round(10 * jumpScale))}px` }}
        >
          Jump
        </span>
      </button>

      {/* 6. POUR BUTTON (Symbol: Tilted Pouring Vessel & Droplets) */}
      <button
        type="button"
        data-testid="pour-btn"
        data-control-id="pour"
        data-scale={pourScale}
        tabIndex={-1}
        aria-label="Pour"
        title="Hold to Pour Ingredient (E)"
        aria-pressed={isPouring}
        style={{
          ...getControlStyle('pour'),
          backgroundColor: isPouring ? undefined : 'rgba(20, 38, 28, 0.92)',
        }}
        onTouchStart={(e) => {
          e.stopPropagation();
          const t = e.changedTouches[0];
          if (isCustomizing && t) {
            startCustomDrag('pour', t.clientX, t.clientY, e.currentTarget);
            return;
          }
          onPourStart();
        }}
        onTouchEnd={(e) => {
          e.stopPropagation();
          if (isCustomizing) return;
          onPourEnd();
        }}
        onTouchCancel={(e) => {
          e.stopPropagation();
          onPourEnd();
        }}
        onPointerDown={(e) => {
          e.stopPropagation();
          if (isCustomizing) {
            startCustomDrag('pour', e.clientX, e.clientY, e.currentTarget);
            return;
          }
          if (e.pointerType === 'touch') return;
          onPourStart();
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          if (isCustomizing || e.pointerType === 'touch') return;
          onPourEnd();
        }}
        onPointerCancel={(e) => {
          e.stopPropagation();
          if (isCustomizing || e.pointerType === 'touch') return;
          onPourEnd();
        }}
        onPointerLeave={(e) => {
          if (isCustomizing || e.pointerType === 'touch') return;
          if (isPouring) onPourEnd();
        }}
        onClick={(e) => {
          e.currentTarget.blur();
          if (isCustomizing) {
            onSelectControl?.('pour');
          }
        }}
        className={`pointer-events-auto fixed z-20 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 shadow-lg transition-transform active:scale-95 ${
          isPouring
            ? 'border-emerald-200 bg-emerald-500 text-stone-950'
            : 'border-emerald-400/50 text-emerald-100'
        } ${getCustomOutlineClass('pour')}`}
      >
        {renderCustomizationBadge('pour')}
        <PourIcon size={Math.round(24 * pourScale)} />
        <span
          className="mt-0.5 font-display font-bold leading-none whitespace-nowrap"
          style={{ fontSize: `${Math.max(9, Math.round(10 * pourScale))}px` }}
        >
          {isPouring ? 'Pouring' : 'Pour'}
        </span>
      </button>
    </>
  );
};
