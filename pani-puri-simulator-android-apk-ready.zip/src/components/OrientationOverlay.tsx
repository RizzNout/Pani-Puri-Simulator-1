import React from 'react';

export const OrientationOverlay: React.FC = () => {
  return (
    <div
      data-testid="orientation-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rotate-device-title"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 text-center text-stone-100 select-none"
      style={{ backgroundColor: 'rgba(12, 10, 9, 0.94)' }}
    >
      <div className="flex max-w-xs flex-col items-center rounded-2xl border border-amber-400/30 bg-stone-900/95 px-6 py-8 shadow-2xl">
        {/* Rotate-Device SVG Icon */}
        <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-2xl border border-amber-400/25 bg-amber-500/10 text-amber-400">
          <svg
            viewBox="0 0 64 64"
            className="h-12 w-12"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            {/* Portrait Phone Outline (faded) */}
            <rect
              x="12"
              y="8"
              width="20"
              height="34"
              rx="3"
              stroke="currentColor"
              strokeOpacity="0.35"
              strokeDasharray="3 3"
            />
            {/* Landscape Phone Outline (highlighted) */}
            <rect
              x="20"
              y="28"
              width="36"
              height="22"
              rx="3.5"
              fill="rgba(245, 158, 11, 0.16)"
              stroke="#fbbf24"
              strokeWidth="3"
            />
            <circle cx="51" cy="39" r="1.5" fill="#fbbf24" stroke="none" />
            {/* Rotation Arrow */}
            <path d="M38 12 C46 12 52 17 52 24" stroke="#f59e0b" strokeWidth="3" />
            <polyline points="47 21 52 25 56 20" stroke="#f59e0b" strokeWidth="3" />
          </svg>
        </div>

        <h1
          id="rotate-device-title"
          className="font-display text-xl font-extrabold tracking-wide text-amber-400"
        >
          PLEASE ROTATE YOUR DEVICE
        </h1>

        <p className="mt-2.5 text-sm leading-relaxed text-stone-300">
          Pani Puri Simulator is best played in landscape mode.
        </p>
      </div>
    </div>
  );
};
