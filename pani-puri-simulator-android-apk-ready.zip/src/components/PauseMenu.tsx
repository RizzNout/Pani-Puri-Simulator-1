import React, { useState } from 'react';
import { GameSettings, GraphicsQuality } from '../types/game';
import { soundManager } from '../utils/sound';
import {
  BackArrowIcon,
  ConfirmCheckIcon,
  SettingsGearIcon,
  ShopCartIcon,
} from './GameIcons';

interface PauseMenuProps {
  settings: GameSettings;
  onUpdateSettings: (next: GameSettings) => void;
  onResume: () => void;
  onOpenCustomizeControls: () => void;
  onOpenShop: () => void;
  onReturnToMainMenu: () => void;
}

type PauseSubPanel = 'MAIN' | 'CONTROLS' | 'SOUND';

export const PauseMenu: React.FC<PauseMenuProps> = ({
  settings,
  onUpdateSettings,
  onResume,
  onOpenCustomizeControls,
  onOpenShop,
  onReturnToMainMenu,
}) => {
  const [activeSubPanel, setActiveSubPanel] = useState<PauseSubPanel>('MAIN');
  const activeQuality: GraphicsQuality = settings.graphicsQuality ?? 'medium';

  const handleGraphicsQualityChange = (quality: GraphicsQuality) => {
    soundManager.playUiClick();
    onUpdateSettings({
      ...settings,
      graphicsQuality: quality,
    });
  };

  const handleVolumeChange = (newVolume: number) => {
    const updated: GameSettings = {
      ...settings,
      volume: newVolume,
      muted: newVolume === 0 ? true : false,
      sfxEnabled: newVolume === 0 ? false : true,
    };
    onUpdateSettings(updated);
  };

  const handleToggleMute = () => {
    const nextMuted = !settings.muted;
    const updated: GameSettings = {
      ...settings,
      muted: nextMuted,
      sfxEnabled: !nextMuted,
    };
    onUpdateSettings(updated);
    if (!nextMuted) {
      soundManager.updateSettings(updated);
      soundManager.playUiClick();
    }
  };

  const handleToggleSfx = () => {
    const currentSfx = settings.sfxEnabled !== false && !settings.muted;
    const nextSfx = !currentSfx;
    const updated: GameSettings = {
      ...settings,
      sfxEnabled: nextSfx,
      muted: !nextSfx,
      volume: nextSfx && settings.volume === 0 ? 75 : settings.volume,
    };
    onUpdateSettings(updated);
    if (nextSfx) {
      soundManager.updateSettings(updated);
      soundManager.playUiClick();
    }
  };

  const handleSensitivityChange = (newSens: number) => {
    onUpdateSettings({
      ...settings,
      lookSensitivity: newSens,
    });
  };

  const handleToggleInvertY = () => {
    soundManager.playUiClick();
    onUpdateSettings({
      ...settings,
      invertY: !settings.invertY,
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pause-modal-title"
      data-testid="pause-menu-modal"
      className="fixed inset-0 z-30 flex items-center justify-center p-3 sm:p-6"
      style={{ backgroundColor: 'rgba(12, 10, 9, 0.82)' }}
    >
      <div
        className="flex max-h-[92vh] w-full max-w-lg flex-col overflow-y-auto rounded-2xl border border-amber-400/30 p-4 sm:p-5 text-stone-100 shadow-2xl"
        style={{ backgroundColor: 'rgba(28, 25, 23, 0.96)' }}
      >
        <div className="flex items-center justify-between border-b border-stone-800 pb-2.5">
          <div>
            <h2
              id="pause-modal-title"
              className="font-display text-lg sm:text-xl font-bold text-amber-400"
            >
              Game Paused
            </h2>
            <p className="mt-0.5 text-xs text-stone-400">
              Simulation and player movement are paused.
            </p>
          </div>
          <span className="font-mono text-xs text-stone-400 tabular-nums">
            VOL {settings.muted ? 'MUTE' : `${settings.volume}%`}
          </span>
        </div>

        {/* Sub-navigation tabs inside Pause Modal */}
        <div className="mt-2.5 grid grid-cols-3 gap-1.5 rounded-xl bg-stone-900 p-1">
          <button
            type="button"
            onClick={() => {
              soundManager.playUiClick();
              setActiveSubPanel('MAIN');
            }}
            className={`min-h-[36px] cursor-pointer rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap ${
              activeSubPanel === 'MAIN'
                ? 'bg-amber-500 text-stone-950'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            Pause Menu
          </button>
          <button
            type="button"
            data-testid="pause-tab-controls"
            onClick={() => {
              soundManager.playUiClick();
              setActiveSubPanel('CONTROLS');
            }}
            className={`min-h-[36px] cursor-pointer rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap ${
              activeSubPanel === 'CONTROLS'
                ? 'bg-amber-500 text-stone-950'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            Controls
          </button>
          <button
            type="button"
            data-testid="pause-tab-sound"
            onClick={() => {
              soundManager.playUiClick();
              setActiveSubPanel('SOUND');
            }}
            className={`min-h-[36px] cursor-pointer rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap ${
              activeSubPanel === 'SOUND'
                ? 'bg-amber-500 text-stone-950'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            Sound Settings
          </button>
        </div>

        {/* MAIN PAUSE PANEL (2x2 Grid for Landscape Ergonomics) */}
        {activeSubPanel === 'MAIN' && (
          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              data-testid="pause-resume-btn"
              onClick={() => {
                soundManager.playUiClick();
                onResume();
              }}
              className="flex min-h-[44px] w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-amber-500 px-5 py-2 font-display text-sm sm:text-base font-bold text-stone-950 transition-colors hover:bg-amber-400 active:scale-[0.99] whitespace-nowrap sm:col-span-2"
            >
              <ConfirmCheckIcon size={18} />
              <span>Resume</span>
            </button>

            <button
              type="button"
              data-testid="pause-customize-controls-btn"
              onClick={() => {
                soundManager.playUiClick();
                onOpenCustomizeControls();
              }}
              className="flex min-h-[42px] w-full cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-amber-400/50 bg-stone-900 px-3.5 py-2 font-display text-xs sm:text-sm font-bold text-amber-200 transition-colors hover:bg-stone-800 whitespace-nowrap"
            >
              <SettingsGearIcon size={16} />
              <span>Customize Controls</span>
            </button>

            <button
              type="button"
              data-testid="pause-open-shop-btn"
              onClick={() => {
                soundManager.playUiClick();
                onOpenShop();
              }}
              className="flex min-h-[42px] w-full cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-stone-700 bg-stone-900 px-3.5 py-2 font-display text-xs sm:text-sm font-bold text-stone-100 transition-colors hover:bg-stone-800 whitespace-nowrap"
            >
              <ShopCartIcon size={16} />
              <span>Stall Shop</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playUiClick();
                setActiveSubPanel('CONTROLS');
              }}
              className="min-h-[40px] w-full cursor-pointer rounded-xl border border-stone-700 bg-stone-900 px-3.5 py-2 font-display text-xs sm:text-sm font-bold text-stone-100 transition-colors hover:bg-stone-800 whitespace-nowrap"
            >
              Look & Sensitivity
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playUiClick();
                setActiveSubPanel('SOUND');
              }}
              className="min-h-[40px] w-full cursor-pointer rounded-xl border border-stone-700 bg-stone-900 px-3.5 py-2 font-display text-xs sm:text-sm font-bold text-stone-100 transition-colors hover:bg-stone-800 whitespace-nowrap"
            >
              Sound Settings
            </button>

            <button
              type="button"
              data-testid="pause-return-menu-btn"
              onClick={() => {
                soundManager.playUiClick();
                onReturnToMainMenu();
              }}
              className="flex min-h-[42px] w-full cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-red-500/40 bg-red-950/40 px-4 py-2 font-display text-xs sm:text-sm font-bold text-red-200 transition-colors hover:bg-red-900/50 whitespace-nowrap sm:col-span-2"
            >
              <BackArrowIcon size={16} />
              <span>Return to Main Menu</span>
            </button>
          </div>
        )}

        {/* CONTROLS SUB-PANEL */}
        {activeSubPanel === 'CONTROLS' && (
          <div className="mt-3 flex flex-col gap-2.5 text-xs">
            {/* Button Position & Size Customization Launcher */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-400/40 bg-amber-950/25 p-3">
              <div>
                <h3 className="font-display text-xs sm:text-sm font-bold text-amber-300">
                  Button Position & Size Layout
                </h3>
                <p className="text-[11px] text-stone-300">
                  Drag buttons anywhere on screen and resize between 70% and 150%.
                </p>
              </div>
              <button
                type="button"
                data-testid="controls-tab-customize-btn"
                onClick={() => {
                  soundManager.playUiClick();
                  onOpenCustomizeControls();
                }}
                className="flex min-h-[36px] cursor-pointer items-center gap-1.5 rounded-xl bg-amber-500 px-3.5 py-1.5 font-display text-xs font-bold text-stone-950 hover:bg-amber-400 whitespace-nowrap"
              >
                <SettingsGearIcon size={15} />
                <span>Customize Controls</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="rounded-xl border border-stone-800 bg-stone-900/90 p-3">
                <h3 className="font-display text-xs font-bold text-amber-300">
                  Control Bindings
                </h3>
                <ul className="mt-1.5 space-y-1 text-[11px] text-stone-300">
                  <li className="flex justify-between gap-2">
                    <span>Move</span>
                    <span className="font-mono text-stone-100">Joystick / WASD</span>
                  </li>
                  <li className="flex justify-between gap-2">
                    <span>Look</span>
                    <span className="font-mono text-stone-100">Right Touch / Mouse</span>
                  </li>
                  <li className="flex justify-between gap-2">
                    <span>Sprint / Jump</span>
                    <span className="font-mono text-stone-100">Shift / Space</span>
                  </li>
                  <li className="flex justify-between gap-2">
                    <span>Pick / Pour / Put Down</span>
                    <span className="font-mono text-stone-100">F / E / Q</span>
                  </li>
                </ul>
              </div>

              <div className="rounded-xl border border-stone-800 bg-stone-900/90 p-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <label htmlFor="look-sensitivity-slider" className="font-semibold text-stone-200">
                      Look Sensitivity
                    </label>
                    <span className="font-mono tabular-nums text-amber-300">
                      {settings.lookSensitivity.toFixed(1)}x
                    </span>
                  </div>
                  <input
                    id="look-sensitivity-slider"
                    type="range"
                    min={0.3}
                    max={2.2}
                    step={0.1}
                    value={settings.lookSensitivity}
                    onChange={(e) => handleSensitivityChange(parseFloat(e.target.value))}
                    className="mt-2 w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div className="mt-2 flex items-center justify-between border-t border-stone-800 pt-2">
                  <span className="font-semibold text-stone-200">Invert Y-Axis</span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={settings.invertY}
                    onClick={handleToggleInvertY}
                    className={`min-h-[30px] cursor-pointer rounded-lg px-2.5 py-1 text-xs font-bold transition-colors ${
                      settings.invertY
                        ? 'bg-amber-500 text-stone-950'
                        : 'bg-stone-800 text-stone-300'
                    }`}
                  >
                    {settings.invertY ? 'Inverted' : 'Standard'}
                  </button>
                </div>

                <div className="mt-2 flex items-center justify-between border-t border-stone-800 pt-2">
                  <span className="font-semibold text-stone-200">Graphics Quality</span>
                  <div className="flex items-center gap-1" role="group" aria-label="Graphics Quality Presets">
                    {(['low', 'medium', 'high'] as GraphicsQuality[]).map((q) => (
                      <button
                        key={q}
                        type="button"
                        data-testid={`graphics-quality-${q}`}
                        onClick={() => handleGraphicsQualityChange(q)}
                        className={`min-h-[28px] cursor-pointer rounded-lg px-2 py-0.5 text-[11px] font-bold uppercase transition-colors ${
                          activeQuality === q
                            ? 'bg-amber-500 text-stone-950'
                            : 'bg-stone-800 text-stone-300 hover:text-white'
                        }`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                soundManager.playUiClick();
                onResume();
              }}
              className="min-h-[42px] w-full cursor-pointer rounded-xl bg-amber-500 px-5 py-2 font-display text-sm font-bold text-stone-950 hover:bg-amber-400 whitespace-nowrap"
            >
              Resume
            </button>
          </div>
        )}

        {/* SOUND SETTINGS SUB-PANEL */}
        {activeSubPanel === 'SOUND' && (
          <div className="mt-3 flex flex-col gap-3 text-xs">
            <div className="rounded-xl border border-stone-800 bg-stone-900/90 p-3.5">
              <div className="flex items-center justify-between">
                <label htmlFor="master-volume-slider" className="font-semibold text-stone-200">
                  Master Sound Volume
                </label>
                <span className="font-mono font-bold tabular-nums text-amber-300">
                  {settings.muted ? '0% (Muted)' : `${settings.volume}%`}
                </span>
              </div>

              <input
                id="master-volume-slider"
                type="range"
                min={0}
                max={100}
                step={5}
                value={settings.muted ? 0 : settings.volume}
                onChange={(e) => handleVolumeChange(parseInt(e.target.value, 10))}
                onMouseUp={() => soundManager.playUiClick()}
                onTouchEnd={() => soundManager.playUiClick()}
                className="mt-2.5 w-full accent-amber-500 cursor-pointer"
              />

              <div className="mt-3 flex items-center justify-between border-t border-stone-800 pt-2.5">
                <div>
                  <div className="font-semibold text-stone-200">Sound Effects (SFX)</div>
                  <div className="text-[11px] text-stone-400">
                    Serving, eating, star ratings, purchases & coin rewards
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="toggle-sfx-btn"
                  role="switch"
                  aria-checked={settings.sfxEnabled !== false && !settings.muted}
                  onClick={handleToggleSfx}
                  className={`min-h-[34px] cursor-pointer rounded-lg px-3.5 py-1 text-xs font-bold transition-colors ${
                    settings.sfxEnabled !== false && !settings.muted
                      ? 'bg-emerald-600/85 text-white'
                      : 'bg-stone-800 text-stone-400'
                  }`}
                >
                  {settings.sfxEnabled !== false && !settings.muted ? 'SFX On' : 'SFX Off'}
                </button>
              </div>

              <div className="mt-2.5 flex items-center justify-between border-t border-stone-800 pt-2.5">
                <div>
                  <div className="font-semibold text-stone-200">Mute All Audio</div>
                  <div className="text-[11px] text-stone-400">
                    Saved automatically in browser localStorage
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="toggle-mute-btn"
                  role="switch"
                  aria-checked={settings.muted}
                  onClick={handleToggleMute}
                  className={`min-h-[36px] cursor-pointer rounded-lg px-3.5 py-1.5 text-xs font-bold transition-colors ${
                    settings.muted
                      ? 'bg-red-500/80 text-white'
                      : 'bg-emerald-600/80 text-white'
                  }`}
                >
                  {settings.muted ? 'Muted' : 'Sound On'}
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                soundManager.playUiClick();
                onResume();
              }}
              className="min-h-[42px] w-full cursor-pointer rounded-xl bg-amber-500 px-5 py-2 font-display text-sm font-bold text-stone-950 hover:bg-amber-400 whitespace-nowrap"
            >
              Resume
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
