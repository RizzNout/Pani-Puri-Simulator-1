import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameSettings, GameState, PlayerState, PlayerTelemetry } from '../types/game';
import { buildCityWorld } from '../game/cityBuilder';
import { createStallInteractiveRig } from '../game/stallRig';
import { createCustomerWorldRig } from '../game/customerRig';
import { stepCustomerSystem } from '../game/customerSystem';
import {
  computeContextualPrompt,
  FoodPrepSessionState,
  POUR_RATE_PER_SECOND,
  stepIngredientPourUnits,
  stopIngredientPour,
} from '../game/foodPrepEngine';
import { hasAnyPlateContents, InteractiveTargetId, RECIPES } from '../game/recipes';
import {
  createInitialPlayerState,
  getPlayerTelemetry,
  stepPlayerPhysics,
} from '../game/physics';
import { PlayerInputController } from '../game/playerController';
import { PLAYER_EYE_HEIGHT, STALL_POSITION } from '../game/worldData';
import { soundManager } from '../utils/sound';

interface CitySceneProps {
  gameState: GameState;
  isPortraitBlocked: boolean;
  isOverlayPaused?: boolean;
  settings: GameSettings;
  inputController: PlayerInputController;
  playerStateRef: React.MutableRefObject<PlayerState>;
  foodPrepRef: React.MutableRefObject<FoodPrepSessionState>;
  resetSignal: number;
  onTelemetryUpdate: (telemetry: PlayerTelemetry) => void;
  onFoodPrepSync: () => void;
  onPointerLockChange: (locked: boolean) => void;
}

const _menuLookTarget = new THREE.Vector3(STALL_POSITION.x - 1.55, 1.45, STALL_POSITION.z);
const _centerNDC = new THREE.Vector2(0, 0);
const MAX_INTERACTION_DISTANCE = 4.6;

export const CityScene: React.FC<CitySceneProps> = ({
  gameState,
  isPortraitBlocked,
  isOverlayPaused = false,
  settings,
  inputController,
  playerStateRef,
  foodPrepRef,
  resetSignal,
  onTelemetryUpdate,
  onFoodPrepSync,
  onPointerLockChange,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const gameStateRef = useRef<GameState>(gameState);
  const portraitBlockedRef = useRef<boolean>(isPortraitBlocked);
  const overlayPausedRef = useRef<boolean>(isOverlayPaused);
  const graphicsQualityRef = useRef(settings.graphicsQuality ?? 'medium');
  const applyQualityPresetRef = useRef<((q: 'low' | 'medium' | 'high') => void) | null>(null);
  const telemetryCallbackRef = useRef(onTelemetryUpdate);
  const foodPrepSyncCallbackRef = useRef(onFoodPrepSync);
  const pointerLockCallbackRef = useRef(onPointerLockChange);

  useEffect(() => {
    gameStateRef.current = gameState;
    portraitBlockedRef.current = isPortraitBlocked;
    overlayPausedRef.current = isOverlayPaused;
    const canPlay = gameState === GameState.PLAYING && !isPortraitBlocked && !isOverlayPaused;
    inputController.setEnabled(canPlay);

    if (!canPlay) {
      if (stopIngredientPour(foodPrepRef.current)) {
        foodPrepSyncCallbackRef.current();
      }
      if (document.pointerLockElement) {
        document.exitPointerLock?.();
      }
    }
  }, [gameState, isPortraitBlocked, isOverlayPaused, inputController, foodPrepRef]);

  useEffect(() => {
    inputController.setConfig(settings.lookSensitivity, settings.invertY);
    soundManager.updateSettings(settings);
    const nextQuality = settings.graphicsQuality ?? 'medium';
    graphicsQualityRef.current = nextQuality;
    applyQualityPresetRef.current?.(nextQuality);
  }, [settings, inputController]);

  useEffect(() => {
    telemetryCallbackRef.current = onTelemetryUpdate;
  }, [onTelemetryUpdate]);

  useEffect(() => {
    foodPrepSyncCallbackRef.current = onFoodPrepSync;
  }, [onFoodPrepSync]);

  useEffect(() => {
    pointerLockCallbackRef.current = onPointerLockChange;
  }, [onPointerLockChange]);

  // Reset player position only when explicitly starting a fresh session from Main Menu
  useEffect(() => {
    if (resetSignal > 0) {
      playerStateRef.current = createInitialPlayerState();
      telemetryCallbackRef.current(getPlayerTelemetry(playerStateRef.current));
    }
  }, [resetSignal, playerStateRef]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect Software WebGL (SwiftShader / llvmpipe)
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize WebGLRenderer with ACES Filmic Tone Mapping
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const initialW = Math.max(1, container.clientWidth || window.innerWidth);
    const initialH = Math.max(1, container.clientHeight || window.innerHeight);
    renderer.setSize(initialW, initialH);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.setAttribute('data-testid', 'city-3d-canvas');
    container.appendChild(renderer.domElement);

    // 3. Initialize Scene, Sky Fog & Studio Environment Map
    const scene = new THREE.Scene();
    const skyHorizonColor = 0xdbeafe;
    scene.background = new THREE.Color(skyHorizonColor);
    const sceneFog = new THREE.Fog(skyHorizonColor, 38, 104);
    scene.fog = sceneFog;

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    // 4. Phase 5 Natural Golden-Hour Daylight Rig & Stall Canopy Lighting
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0xd6d0c4, 0.88);
    hemiLight.position.set(0, 42, 0);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff7ed, 2.2);
    sunLight.position.set(18, 30, 18);
    sunLight.shadow.camera.left = -28;
    sunLight.shadow.camera.right = 28;
    sunLight.shadow.camera.top = 28;
    sunLight.shadow.camera.bottom = -28;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 80;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.02;
    scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.58);
    fillLight.position.set(-18, 15, -14);
    scene.add(fillLight);

    // Warm overhead point light inside the Expanded Pani Puri Stall canopy + counter fill
    const stallWarmLight = new THREE.PointLight(0xfbbf24, 2.5, 11.5, 1.65);
    stallWarmLight.position.set(STALL_POSITION.x, 2.28, STALL_POSITION.z + 0.2);
    scene.add(stallWarmLight);

    const applyGraphicsQuality = (quality: 'low' | 'medium' | 'high') => {
      const dpr = window.devicePixelRatio || 1;
      if (isSoftwareGl) {
        renderer.setPixelRatio(1);
        renderer.shadowMap.enabled = false;
        sunLight.castShadow = false;
      } else if (quality === 'low') {
        renderer.setPixelRatio(Math.min(dpr, 1.0));
        renderer.shadowMap.enabled = false;
        sunLight.castShadow = false;
        sceneFog.near = 30;
        sceneFog.far = 82;
      } else if (quality === 'high') {
        renderer.setPixelRatio(Math.min(dpr, 2.0));
        renderer.shadowMap.enabled = true;
        sunLight.castShadow = true;
        if (sunLight.shadow.mapSize.width !== 2048) {
          sunLight.shadow.mapSize.set(2048, 2048);
          sunLight.shadow.map?.dispose();
          sunLight.shadow.map = null;
        }
        sceneFog.near = 42;
        sceneFog.far = 115;
      } else {
        // 'medium' (default)
        renderer.setPixelRatio(Math.min(dpr, 1.5));
        renderer.shadowMap.enabled = true;
        sunLight.castShadow = true;
        if (sunLight.shadow.mapSize.width !== 1024) {
          sunLight.shadow.mapSize.set(1024, 1024);
          sunLight.shadow.map?.dispose();
          sunLight.shadow.map = null;
        }
        sceneFog.near = 38;
        sceneFog.far = 104;
      }
      renderer.shadowMap.needsUpdate = true;
    };

    applyQualityPresetRef.current = applyGraphicsQuality;
    applyGraphicsQuality(graphicsQualityRef.current);

    // 5. Build the Expanded 60x60 (72m x 72m) City & 1.5x Central Pani Puri Stall
    const builtWorld = buildCityWorld(renderer);
    scene.add(builtWorld.worldGroup);

    // 6. Initialize First-Person Camera & Stall Interactive Food Prep Rig
    const camera = new THREE.PerspectiveCamera(70, initialW / initialH, 0.1, 160);
    camera.rotation.order = 'YXZ';
    scene.add(camera);

    const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const stallRig = createStallInteractiveRig(maxAnisotropy);
    scene.add(stallRig.rootGroup);
    camera.add(stallRig.cameraHeldGroup);

    const customerRig = createCustomerWorldRig(maxAnisotropy);
    scene.add(customerRig.rootGroup);

    const allRaycastTargets = [...stallRig.raycastTargets, ...customerRig.raycastTargets];

    const raycaster = new THREE.Raycaster();
    raycaster.near = 0.05;
    raycaster.far = MAX_INTERACTION_DISTANCE;

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // 7. Attach Input Listeners & Pointer Lock Handler
    const detachInput = inputController.attachListeners(renderer.domElement);

    const handleCanvasClick = () => {
      if (
        gameStateRef.current === GameState.PLAYING &&
        !portraitBlockedRef.current &&
        !overlayPausedRef.current
      ) {
        try {
          renderer.domElement.requestPointerLock?.();
        } catch {
          // Ignore pointer lock rejection in automated/mobile browsers
        }
      }
    };
    renderer.domElement.addEventListener('click', handleCanvasClick);

    const handlePointerLockChange = () => {
      const isLocked = document.pointerLockElement === renderer.domElement;
      pointerLockCallbackRef.current(isLocked);
    };
    document.addEventListener('pointerlockchange', handlePointerLockChange);

    // 8. Responsive Resize & Orientation Change Handling (prevents any stretching/distortion)
    const updateCameraAndRendererSize = () => {
      if (!container) return;
      const w = Math.max(1, container.clientWidth || window.innerWidth);
      const h = Math.max(1, container.clientHeight || window.innerHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      applyGraphicsQuality(graphicsQualityRef.current);
    };

    window.addEventListener('resize', updateCameraAndRendererSize);
    window.addEventListener('orientationchange', updateCameraAndRendererSize);

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        updateCameraAndRendererSize();
      });
      resizeObserver.observe(container);
    }

    // 9. Animation Loop (with software-WebGL afterDraw pacing)
    let frameId = 0;
    let isUnmounted = false;
    let lastTimestamp = performance.now();
    let elapsedTime = 0;
    let lastTelemetryTime = 0;
    let menuOrbitAngle = 0.55;
    let pourUnitAccumulator = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (gl && typeof gl.fenceSync === 'function') {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (isUnmounted) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } else {
        frameId = window.setTimeout(cb, 80);
      }
    }

    function hasVisibleAncestors(obj: THREE.Object3D): boolean {
      let cur: THREE.Object3D | null = obj;
      while (cur) {
        if (!cur.visible) return false;
        cur = cur.parent;
      }
      return true;
    }

    function tick() {
      if (isUnmounted) return;
      const now = performance.now();
      const rawDt = (now - lastTimestamp) / 1000;
      lastTimestamp = now;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      elapsedTime += dt;

      const currentMode = gameStateRef.current;
      const isBlockedByPortrait = portraitBlockedRef.current;
      const isOverlayModalOpen = overlayPausedRef.current;
      const fpState = foodPrepRef.current;

      if (currentMode === GameState.PLAYING && !isBlockedByPortrait && !isOverlayModalOpen) {
        const frameInput = inputController.consumeFrameInput();
        const pState = playerStateRef.current;
        const stepRes = stepPlayerPhysics(pState, frameInput, dt);

        if (stepRes.jumped) soundManager.playJump();
        if (stepRes.landed) soundManager.playLand();
        if (stepRes.footstepTriggered) soundManager.playFootstep(pState.isSprinting);

        const headBobY =
          pState.isGrounded && (Math.abs(pState.vx) > 0.1 || Math.abs(pState.vz) > 0.1)
            ? Math.sin(pState.walkCycle * 2) * (pState.isSprinting ? 0.055 : 0.032)
            : 0;

        camera.position.set(pState.x, PLAYER_EYE_HEIGHT + pState.y + headBobY, pState.z);
        camera.rotation.set(pState.pitch, pState.yaw, 0, 'YXZ');
        camera.updateMatrixWorld();

        const targetFov = pState.isSprinting ? 75 : 70;
        if (Math.abs(camera.fov - targetFov) > 0.05) {
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 10, dt);
          camera.updateProjectionMatrix();
        }

        // First-Person Center Crosshair Raycast for Stall Food Preparation & Active Customer
        raycaster.setFromCamera(_centerNDC, camera);
        const hits = raycaster.intersectObjects(allRaycastTargets, true);
        let detectedTarget: InteractiveTargetId | null = null;

        for (const hit of hits) {
          if (!hasVisibleAncestors(hit.object)) continue;
          const id = hit.object.userData?.interactiveId as InteractiveTargetId | undefined;
          if (!id) continue;
          // If aiming at prep_counter while an active plate is placed on it, resolve to active_plate
          if (id === 'prep_counter' && fpState.activePlate) {
            detectedTarget = 'active_plate';
          } else {
            detectedTarget = id;
          }
          break;
        }

        let needsUISync = false;

        // Step Phase 3 NPC Customer AI, Queue, Orders & Patience System
        const customerDt = Math.min(Math.max(rawDt, 0.001), 0.15);
        const custSummary = stepCustomerSystem(fpState.customerSystem, customerDt, false);
        if (custSummary.uiChanged) {
          needsUISync = true;
        }
        if (custSummary.NewlyActiveOrderRecipeId) {
          const activeCust = fpState.customerSystem.customers.find(
            (c) => c.id === custSummary.newlyActiveCustomerId
          );
          if (!hasAnyPlateContents(fpState.activePlate)) {
            fpState.selectedRecipeId = custSummary.NewlyActiveOrderRecipeId;
          }
          if (activeCust) {
            fpState.statusBanner = `${activeCust.name} stepped up and ordered ${RECIPES[activeCust.orderRecipeId].name}!`;
            soundManager.playFoodPrepCue('pickup');
          }
        }
        if (custSummary.patienceExpiredCustomerId) {
          fpState.statusBanner = "Customer ran out of patience and left! (0 Coins)";
          soundManager.playFoodPrepCue('discard');
        }

        if (fpState.aimedTarget !== detectedTarget) {
          fpState.aimedTarget = detectedTarget;
          fpState.contextualPrompt = computeContextualPrompt(fpState, detectedTarget);
          needsUISync = true;
        }

        // Step continuous ingredient pouring when Pour button is held
        if (fpState.isPouring) {
          const pourDt = Math.min(Math.max(rawDt, 0.001), 0.15);
          pourUnitAccumulator += pourDt * POUR_RATE_PER_SECOND;
          const wholeUnits = Math.floor(pourUnitAccumulator);
          if (wholeUnits >= 1) {
            pourUnitAccumulator -= wholeUnits;
            const pourRes = stepIngredientPourUnits(fpState, wholeUnits);
            if (pourRes.soundCue) {
              soundManager.playFoodPrepCue(pourRes.soundCue);
            }
            if (pourRes.changed) {
              needsUISync = true;
            }
          }
        } else {
          pourUnitAccumulator = 0;
        }

        if (needsUISync) {
          foodPrepSyncCallbackRef.current();
        }

        if (now - lastTelemetryTime > 125) {
          lastTelemetryTime = now;
          telemetryCallbackRef.current(getPlayerTelemetry(pState));
        }
      } else if (
        currentMode === GameState.MAIN_MENU ||
        currentMode === GameState.SHOP_PREVIEW ||
        currentMode === GameState.CONNECT_PANEL
      ) {
        stallRig.cameraHeldGroup.visible = false;
        menuOrbitAngle += dt * 0.16;
        const radius = 6.0;
        const camX = STALL_POSITION.x - 0.8 + Math.sin(menuOrbitAngle) * radius * 0.55;
        const camZ = STALL_POSITION.z + 2.4 + Math.cos(menuOrbitAngle) * radius * 0.55;
        camera.position.set(camX, 2.85, camZ);
        camera.lookAt(_menuLookTarget);
      }

      if (currentMode === GameState.PLAYING || currentMode === GameState.PAUSED) {
        stallRig.cameraHeldGroup.visible = true;
      }

      stallRig.syncWithState(fpState, dt, elapsedTime);
      customerRig.syncWithCustomers(fpState.customerSystem, camera, dt, elapsedTime);
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    telemetryCallbackRef.current(getPlayerTelemetry(playerStateRef.current));
    tick();

    return () => {
      isUnmounted = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', updateCameraAndRendererSize);
      window.removeEventListener('orientationchange', updateCameraAndRendererSize);
      resizeObserver?.disconnect();
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
      renderer.domElement.removeEventListener('click', handleCanvasClick);
      detachInput();
      customerRig.dispose();
      stallRig.dispose();
      builtWorld.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [inputController, playerStateRef, foodPrepRef]);

  return (
    <div
      ref={mountRef}
      className="fixed inset-0 w-full h-full overflow-hidden bg-sky-100"
      aria-label="3D Game World Viewport"
    />
  );
};
