/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { GameSettings, GameState, PlayerState, PlayerTelemetry } from './types/game';
import { loadGameSettings, saveGameSettings } from './utils/settings';
import { soundManager } from './utils/sound';
import {
  evaluateViewportOrientation,
  tryLockLandscapeOrientation,
  ViewportOrientationState,
} from './utils/orientation';
import { PlayerInputController } from './game/playerController';
import { createInitialPlayerState, getPlayerTelemetry } from './game/physics';
import {
  completeActivePlate,
  createInitialFoodPrepState,
  discardActivePlate,
  FoodPrepSessionState,
  performPickOrDrop,
  purchaseShopItem,
  purchaseShopUpgrade,
  requestRecipeSelection,
  returnOrDropHeldContainer,
  saveGameProgress,
  ShopItemId,
  ShopUpgradeId,
  startIngredientPour,
  stopIngredientPour,
} from './game/foodPrepEngine';
import { writeVersionedSaveBundle } from './game/saveSystem';
import {
  clampControlPlacement,
  cloneControlLayout,
  ControlId,
  ControlLayoutMap,
  detectControlOverlaps,
  loadControlLayout,
  resetAllControlsInLayout,
  resetSingleControlInLayout,
  saveControlLayout,
} from './game/controlLayout';
import { RecipeId } from './game/recipes';
import { CityScene } from './components/CityScene';
import { MainMenu } from './components/MainMenu';
import { ShopPreview } from './components/ShopPreview';
import { ConnectPanel } from './components/ConnectPanel';
import { GameHUD } from './components/GameHUD';
import { PauseMenu } from './components/PauseMenu';
import { OrientationOverlay } from './components/OrientationOverlay';
import { ControlCustomizerModal } from './components/ControlCustomizerModal';

function getInitialGameState(): GameState {
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      return GameState.PLAYING;
    }
  }
  return GameState.MAIN_MENU;
}

function getCurrentViewportOrientation(): ViewportOrientationState {
  if (typeof window === 'undefined') {
    return evaluateViewportOrientation(1440, 900);
  }
  return evaluateViewportOrientation(window.innerWidth, window.innerHeight);
}

function cloneFoodPrepSnapshot(state: FoodPrepSessionState): FoodPrepSessionState {
  return {
    ...state,
    inventory: { ...state.inventory },
    upgrades: { ...state.upgrades },
    containerPlacements: { ...state.containerPlacements },
    activePlate: state.activePlate
      ? {
          ...state.activePlate,
          ingredients: { ...state.activePlate.ingredients },
        }
      : null,
    customerSystem: {
      ...state.customerSystem,
      customers: state.customerSystem.customers.map((c) => ({
        ...c,
        appearance: { ...c.appearance },
        waypoints: c.waypoints.map((w) => ({ ...w })),
      })),
      lastServedSummary: state.customerSystem.lastServedSummary
        ? { ...state.customerSystem.lastServedSummary }
        : null,
    },
  };
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>(getInitialGameState);
  const [settings, setSettings] = useState<GameSettings>(() => loadGameSettings());
  const [controlLayout, setControlLayout] = useState<ControlLayoutMap>(() => loadControlLayout());
  const [draftControlLayout, setDraftControlLayout] = useState<ControlLayoutMap>(() =>
    cloneControlLayout(loadControlLayout())
  );
  const [selectedControlId, setSelectedControlId] = useState<ControlId>('jump');
  const [isCustomizingControls, setIsCustomizingControls] = useState(false);
  const [savedLayoutFeedback, setSavedLayoutFeedback] = useState<string | null>(null);
  const [isInGameShopOpen, setIsInGameShopOpen] = useState(false);

  const playerStateRef = useRef<PlayerState>(createInitialPlayerState());
  const foodPrepRef = useRef<FoodPrepSessionState>(
    createInitialFoodPrepState(undefined, undefined, { loadFromStorage: true })
  );
  const [foodPrepUI, setFoodPrepUI] = useState<FoodPrepSessionState>(() =>
    cloneFoodPrepSnapshot(foodPrepRef.current)
  );
  const [telemetry, setTelemetry] = useState<PlayerTelemetry>(() =>
    getPlayerTelemetry(playerStateRef.current)
  );
  const [isPointerLocked, setIsPointerLocked] = useState(false);
  const [resetSignal, setResetSignal] = useState(0);
  const [viewportOrientation, setViewportOrientation] = useState<ViewportOrientationState>(
    getCurrentViewportOrientation
  );
  const [orientationNotice, setOrientationNotice] = useState<string | null>(null);

  const syncFoodPrepUI = useCallback(() => {
    setFoodPrepUI(cloneFoodPrepSnapshot(foodPrepRef.current));
  }, []);

  const handlePauseRequest = useCallback(() => {
    setIsInGameShopOpen(false);
    setIsCustomizingControls(false);
    setGameState((prev) => (prev === GameState.PLAYING ? GameState.PAUSED : prev));
  }, []);

  const inputController = useMemo(
    () => new PlayerInputController(handlePauseRequest),
    [handlePauseRequest]
  );

  // Expose non-intrusive debug bridge for automated E2E verification
  useEffect(() => {
    if (typeof window === 'undefined') return;
    (window as unknown as Record<string, unknown>).__PANI_PURI_DEBUG__ = {
      getPlayerState: () => playerStateRef.current,
      setPlayerPose: (pose: Partial<PlayerState>) => {
        Object.assign(playerStateRef.current, pose);
        setTelemetry(getPlayerTelemetry(playerStateRef.current));
      },
      getFoodPrepState: () => foodPrepRef.current,
      getCustomerSystem: () => foodPrepRef.current.customerSystem,
      setInventoryStock: (stock: Partial<FoodPrepSessionState['inventory']>) => {
        Object.assign(foodPrepRef.current.inventory, stock);
        saveGameProgress(foodPrepRef.current);
        syncFoodPrepUI();
      },
      setCoins: (coins: number) => {
        foodPrepRef.current.coins = Math.max(0, Number(coins));
        saveGameProgress(foodPrepRef.current);
        syncFoodPrepUI();
      },
      setActiveCustomerOrder: (recipeId: RecipeId) => {
        const cust = foodPrepRef.current.customerSystem.customers.find(
          (c) => c.queueSlotIndex === 0
        );
        if (cust) {
          cust.orderRecipeId = recipeId;
          foodPrepRef.current.selectedRecipeId = recipeId;
          syncFoodPrepUI();
        }
      },
    };
  }, [syncFoodPrepUI]);

  // Track viewport resize & orientation changes without resetting game state or progress
  useEffect(() => {
    const handleViewportChange = () => {
      setViewportOrientation(
        evaluateViewportOrientation(window.innerWidth, window.innerHeight)
      );
    };

    window.addEventListener('resize', handleViewportChange);
    window.addEventListener('orientationchange', handleViewportChange);
    return () => {
      window.removeEventListener('resize', handleViewportChange);
      window.removeEventListener('orientationchange', handleViewportChange);
    };
  }, []);

  // Sync body dataset state for accessibility & automated verification
  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (gameState === GameState.PLAYING) {
      document.body.dataset.state = 'playing';
    } else if (gameState === GameState.PAUSED) {
      document.body.dataset.state = 'paused';
    } else {
      document.body.dataset.state = 'title';
    }
    document.body.dataset.gamestate = gameState;
    document.body.dataset.orientation = viewportOrientation.isPortrait ? 'portrait' : 'landscape';
  }, [gameState, viewportOrientation.isPortrait]);

  // Prevent browser scrolling on touchmove or wheel while playing
  useEffect(() => {
    const preventScroll = (e: Event) => {
      if (
        (gameState === GameState.PLAYING && !isInGameShopOpen && !isCustomizingControls) ||
        viewportOrientation.shouldShowRotateOverlay
      ) {
        e.preventDefault();
      }
    };
    window.addEventListener('touchmove', preventScroll, { passive: false });
    window.addEventListener('wheel', preventScroll, { passive: false });
    return () => {
      window.removeEventListener('touchmove', preventScroll);
      window.removeEventListener('wheel', preventScroll);
    };
  }, [gameState, isInGameShopOpen, isCustomizingControls, viewportOrientation.shouldShowRotateOverlay]);

  const handleUpdateSettings = useCallback((next: GameSettings) => {
    const saved = saveGameSettings(next);
    writeVersionedSaveBundle({ settings: saved });
    setSettings(saved);
    soundManager.updateSettings(saved);
  }, []);

  const handleStartGame = useCallback(() => {
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    inputController.clearAllInputs();
    saveGameProgress(foodPrepRef.current);
    foodPrepRef.current = createInitialFoodPrepState(undefined, undefined, {
      loadFromStorage: true,
    });
    syncFoodPrepUI();
    setIsInGameShopOpen(false);
    setIsCustomizingControls(false);
    setResetSignal((n) => n + 1);
    setGameState(GameState.PLAYING);

    // Attempt to lock landscape orientation on mobile browsers after user gesture
    const isMobileTouch =
      typeof window !== 'undefined' &&
      ('ontouchstart' in window || navigator.maxTouchPoints > 0) &&
      window.innerWidth <= 1024;

    if (isMobileTouch) {
      tryLockLandscapeOrientation().then((res) => {
        if (!res.locked && window.innerHeight > window.innerWidth) {
          setOrientationNotice('Rotate your device horizontally for the best landscape experience.');
        }
      });
    }
  }, [inputController, syncFoodPrepUI]);

  const handleResumeGame = useCallback(() => {
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    inputController.clearAllInputs();
    setIsInGameShopOpen(false);
    setIsCustomizingControls(false);
    setGameState(GameState.PLAYING);
  }, [inputController]);

  const handleReturnToMainMenu = useCallback(() => {
    inputController.clearAllInputs();
    stopIngredientPour(foodPrepRef.current);
    saveGameProgress(foodPrepRef.current);
    syncFoodPrepUI();
    setIsInGameShopOpen(false);
    setIsCustomizingControls(false);
    if (document.pointerLockElement) {
      document.exitPointerLock?.();
    }
    setGameState(GameState.MAIN_MENU);
  }, [inputController, syncFoodPrepUI]);

  // --- Phase 2.5 Control Customization Handlers ---
  const handleOpenCustomizeControls = useCallback(() => {
    inputController.clearAllInputs();
    stopIngredientPour(foodPrepRef.current);
    syncFoodPrepUI();
    setDraftControlLayout(cloneControlLayout(controlLayout));
    setSavedLayoutFeedback(null);
    setIsInGameShopOpen(false);
    setIsCustomizingControls(true);
    setGameState(GameState.PLAYING);
  }, [controlLayout, inputController, syncFoodPrepUI]);

  const handleMoveDraftControl = useCallback(
    (id: ControlId, xPercent: number, yPercent: number) => {
      setDraftControlLayout((prev) => {
        const w = typeof window !== 'undefined' ? window.innerWidth : 844;
        const h = typeof window !== 'undefined' ? window.innerHeight : 390;
        const clamped = clampControlPlacement(
          id,
          { xPercent, yPercent, scale: prev[id].scale },
          w,
          h
        );
        return {
          ...prev,
          [id]: clamped,
        };
      });
      setSavedLayoutFeedback(null);
    },
    []
  );

  const handleResizeDraftControl = useCallback((id: ControlId, scale: number) => {
    setDraftControlLayout((prev) => {
      const w = typeof window !== 'undefined' ? window.innerWidth : 844;
      const h = typeof window !== 'undefined' ? window.innerHeight : 390;
      const clamped = clampControlPlacement(
        id,
        { xPercent: prev[id].xPercent, yPercent: prev[id].yPercent, scale },
        w,
        h
      );
      return {
        ...prev,
        [id]: clamped,
      };
    });
    setSavedLayoutFeedback(null);
  }, []);

  const handleResetSelectedControl = useCallback(() => {
    setDraftControlLayout((prev) => resetSingleControlInLayout(prev, selectedControlId));
    setSavedLayoutFeedback(`Reset ${selectedControlId} to default position & Medium (100%) size.`);
  }, [selectedControlId]);

  const handleResetAllControls = useCallback(() => {
    setDraftControlLayout(resetAllControlsInLayout());
    setSavedLayoutFeedback('All controls reset to default positions & Medium (100%) size.');
  }, []);

  const handleSaveControlLayout = useCallback(() => {
    const w = typeof window !== 'undefined' ? window.innerWidth : 844;
    const h = typeof window !== 'undefined' ? window.innerHeight : 390;
    const saved = saveControlLayout(draftControlLayout, w, h);
    writeVersionedSaveBundle({ controlLayout: saved }, w, h);
    setControlLayout(saved);
    setDraftControlLayout(cloneControlLayout(saved));
    setSavedLayoutFeedback('Control layout saved!');
  }, [draftControlLayout]);

  const handleDoneCustomizeControls = useCallback(() => {
    const w = typeof window !== 'undefined' ? window.innerWidth : 844;
    const h = typeof window !== 'undefined' ? window.innerHeight : 390;
    const saved = saveControlLayout(draftControlLayout, w, h);
    writeVersionedSaveBundle({ controlLayout: saved }, w, h);
    setControlLayout(saved);
    setDraftControlLayout(cloneControlLayout(saved));
    setSavedLayoutFeedback(null);
    setIsCustomizingControls(false);
  }, [draftControlLayout]);

  const handleCancelCustomizeControls = useCallback(() => {
    setDraftControlLayout(cloneControlLayout(controlLayout));
    setSavedLayoutFeedback(null);
    setIsCustomizingControls(false);
  }, [controlLayout]);

  // --- Phase 2.5 In-Game Shop Handlers ---
  const handleOpenInGameShop = useCallback(() => {
    inputController.clearAllInputs();
    stopIngredientPour(foodPrepRef.current);
    syncFoodPrepUI();
    setIsCustomizingControls(false);
    setIsInGameShopOpen(true);
    setGameState(GameState.PLAYING);
  }, [inputController, syncFoodPrepUI]);

  const handleCloseInGameShop = useCallback(() => {
    inputController.clearAllInputs();
    setIsInGameShopOpen(false);
  }, [inputController]);

  const handleBuyShopItem = useCallback(
    (itemId: ShopItemId) => {
      const res = purchaseShopItem(foodPrepRef.current, itemId);
      if (res.soundCue) {
        soundManager.playFoodPrepCue(res.soundCue);
      }
      syncFoodPrepUI();
    },
    [syncFoodPrepUI]
  );

  const handleBuyShopUpgrade = useCallback(
    (upgradeId: ShopUpgradeId) => {
      const res = purchaseShopUpgrade(foodPrepRef.current, upgradeId);
      if (res.soundCue) {
        soundManager.playFoodPrepCue(res.soundCue);
      }
      syncFoodPrepUI();
    },
    [syncFoodPrepUI]
  );

  const triggerServingSoundSequence = useCallback((stars: number = 5) => {
    soundManager.playFoodPrepCue('serving');
    window.setTimeout(() => {
      soundManager.playEating();
    }, 180);
    window.setTimeout(() => {
      soundManager.playStarRating(stars);
      soundManager.playCoinReward();
    }, 420);
  }, []);

  // --- Phase 2 Food Preparation Callbacks ---
  const handlePickOrDrop = useCallback(() => {
    const p = playerStateRef.current;
    const res = performPickOrDrop(foodPrepRef.current, p.x, p.z, p.yaw);
    if (res.soundCue === 'recipe_complete') {
      const stars = foodPrepRef.current.lastServedPlate?.starRating ?? 5;
      triggerServingSoundSequence(stars);
    } else if (res.soundCue) {
      soundManager.playFoodPrepCue(res.soundCue);
    }
    if (res.changed) {
      syncFoodPrepUI();
    }
  }, [syncFoodPrepUI, triggerServingSoundSequence]);

  const handlePutDownContainer = useCallback(() => {
    const p = playerStateRef.current;
    const res = returnOrDropHeldContainer(foodPrepRef.current, p.x, p.z, p.yaw);
    if (res.soundCue) {
      soundManager.playFoodPrepCue(res.soundCue);
    }
    if (res.changed) {
      syncFoodPrepUI();
    }
  }, [syncFoodPrepUI]);

  const handlePourStart = useCallback(() => {
    const res = startIngredientPour(foodPrepRef.current);
    if (res.soundCue) {
      soundManager.playFoodPrepCue(res.soundCue);
    }
    if (res.changed) {
      syncFoodPrepUI();
    }
  }, [syncFoodPrepUI]);

  const handlePourEnd = useCallback(() => {
    if (stopIngredientPour(foodPrepRef.current)) {
      saveGameProgress(foodPrepRef.current);
      syncFoodPrepUI();
    }
  }, [syncFoodPrepUI]);

  const handleSelectRecipe = useCallback(
    (recipeId: RecipeId) => {
      const res = requestRecipeSelection(foodPrepRef.current, recipeId);
      if (res.soundCue) {
        soundManager.playFoodPrepCue(res.soundCue);
      }
      if (res.changed) {
        syncFoodPrepUI();
      }
    },
    [syncFoodPrepUI]
  );

  const handleDiscardPlate = useCallback(
    (confirmed: boolean = false) => {
      const res = discardActivePlate(foodPrepRef.current, confirmed);
      if (res.soundCue) {
        soundManager.playFoodPrepCue(res.soundCue);
      }
      if (res.changed) {
        syncFoodPrepUI();
      }
    },
    [syncFoodPrepUI]
  );

  const handleCancelDiscard = useCallback(() => {
    foodPrepRef.current.discardConfirmOpen = false;
    foodPrepRef.current.pendingRecipeSwitch = null;
    soundManager.playUiClick();
    syncFoodPrepUI();
  }, [syncFoodPrepUI]);

  const handleCompletePlate = useCallback(() => {
    const res = completeActivePlate(foodPrepRef.current);
    if (res.soundCue === 'recipe_complete') {
      const stars = res.serveResult?.starRating ?? 5;
      triggerServingSoundSequence(stars);
    } else if (res.soundCue) {
      soundManager.playFoodPrepCue(res.soundCue);
    }
    if (res.changed) {
      syncFoodPrepUI();
    }
  }, [syncFoodPrepUI, triggerServingSoundSequence]);

  const handleDismissStatusBanner = useCallback(() => {
    foodPrepRef.current.statusBanner = null;
    syncFoodPrepUI();
  }, [syncFoodPrepUI]);

  const isPortraitBlocked = viewportOrientation.shouldShowRotateOverlay;
  const activeControlLayout = isCustomizingControls ? draftControlLayout : controlLayout;
  const isOverlayPaused = isInGameShopOpen || isCustomizingControls;

  const currentOverlaps = useMemo(
    () =>
      detectControlOverlaps(
        activeControlLayout,
        viewportOrientation.width,
        viewportOrientation.height
      ),
    [activeControlLayout, viewportOrientation.width, viewportOrientation.height]
  );

  const overlappingIdSet = useMemo(() => {
    const set = new Set<ControlId>();
    for (const pair of currentOverlaps) {
      set.add(pair.firstId);
      set.add(pair.secondId);
    }
    return set;
  }, [currentOverlaps]);

  return (
    <div
      className="relative h-full w-full overflow-hidden select-none bg-stone-950"
      data-testid="game-shell"
      data-player-x={telemetry.x}
      data-player-y={telemetry.y}
      data-player-z={telemetry.z}
      data-player-sprinting={telemetry.isSprinting}
      data-player-grounded={telemetry.isGrounded}
      data-portrait-blocked={isPortraitBlocked}
    >
      {/* Persistent 3D City & Stall Scene (never unmounts on orientation change) */}
      <CityScene
        gameState={gameState}
        isPortraitBlocked={isPortraitBlocked}
        isOverlayPaused={isOverlayPaused}
        settings={settings}
        inputController={inputController}
        playerStateRef={playerStateRef}
        foodPrepRef={foodPrepRef}
        resetSignal={resetSignal}
        onTelemetryUpdate={setTelemetry}
        onFoodPrepSync={syncFoodPrepUI}
        onPointerLockChange={setIsPointerLocked}
      />

      {/* Portrait Device Orientation Screen (Hides Gameplay HUD & Menus when in mobile portrait) */}
      {isPortraitBlocked ? (
        <OrientationOverlay />
      ) : (
        <>
          {gameState === GameState.MAIN_MENU && (
            <MainMenu
              onStartGame={handleStartGame}
              onOpenShop={() => setGameState(GameState.SHOP_PREVIEW)}
              onOpenConnect={() => setGameState(GameState.CONNECT_PANEL)}
            />
          )}

          {gameState === GameState.SHOP_PREVIEW && (
            <ShopPreview
              foodPrep={foodPrepUI}
              isInGame={false}
              onBuyItem={handleBuyShopItem}
              onBuyUpgrade={handleBuyShopUpgrade}
              onBack={() => setGameState(GameState.MAIN_MENU)}
            />
          )}

          {gameState === GameState.CONNECT_PANEL && (
            <ConnectPanel onBack={() => setGameState(GameState.MAIN_MENU)} />
          )}

          {gameState === GameState.PLAYING && (
            <>
              <GameHUD
                telemetry={telemetry}
                foodPrep={foodPrepUI}
                isPointerLocked={isPointerLocked}
                inputController={inputController}
                controlLayout={activeControlLayout}
                isCustomizing={isCustomizingControls}
                selectedControlId={selectedControlId}
                overlappingIds={overlappingIdSet}
                onSelectControl={setSelectedControlId}
                onMoveControl={handleMoveDraftControl}
                orientationNotice={orientationNotice}
                onDismissOrientationNotice={() => setOrientationNotice(null)}
                onDismissStatusBanner={handleDismissStatusBanner}
                onPickOrDrop={handlePickOrDrop}
                onPutDownContainer={handlePutDownContainer}
                onPourStart={handlePourStart}
                onPourEnd={handlePourEnd}
                onSelectRecipe={handleSelectRecipe}
                onDiscardPlate={handleDiscardPlate}
                onCancelDiscard={handleCancelDiscard}
                onCompletePlate={handleCompletePlate}
                onOpenShop={handleOpenInGameShop}
                onOpenCustomizeControls={handleOpenCustomizeControls}
                onPause={() => {
                  setIsInGameShopOpen(false);
                  setIsCustomizingControls(false);
                  setGameState(GameState.PAUSED);
                }}
                onReturnToMenu={handleReturnToMainMenu}
              />

              {isCustomizingControls && (
                <ControlCustomizerModal
                  draftLayout={draftControlLayout}
                  selectedControlId={selectedControlId}
                  overlaps={currentOverlaps}
                  savedFeedbackMessage={savedLayoutFeedback}
                  onSelectControl={setSelectedControlId}
                  onResizeControl={handleResizeDraftControl}
                  onResetSelected={handleResetSelectedControl}
                  onResetAll={handleResetAllControls}
                  onSaveLayout={handleSaveControlLayout}
                  onCancel={handleCancelCustomizeControls}
                  onDone={handleDoneCustomizeControls}
                />
              )}

              {isInGameShopOpen && (
                <ShopPreview
                  foodPrep={foodPrepUI}
                  isInGame={true}
                  onBuyItem={handleBuyShopItem}
                  onBuyUpgrade={handleBuyShopUpgrade}
                  onBack={handleCloseInGameShop}
                />
              )}
            </>
          )}

          {gameState === GameState.PAUSED && (
            <PauseMenu
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onResume={handleResumeGame}
              onOpenCustomizeControls={handleOpenCustomizeControls}
              onOpenShop={handleOpenInGameShop}
              onReturnToMainMenu={handleReturnToMainMenu}
            />
          )}
        </>
      )}
    </div>
  );
}
