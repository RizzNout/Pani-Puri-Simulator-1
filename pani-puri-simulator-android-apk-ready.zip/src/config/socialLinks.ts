export interface SocialLinkConfig {
  id: 'youtube' | 'instagram';
  label: string;
  handle: string;
  /**
   * Replace empty string "" with your real channel or profile URL when ready,
   * e.g., "https://www.youtube.com/@YourChannel"
   */
  url: string;
  description: string;
}

/**
 * Configurable social account links for Pani Puri Simulator 3D.
 * Leave `url` empty ("") or starting with "YOUR_" until real social pages are live.
 */
export const SOCIAL_LINKS: Record<'youtube' | 'instagram', SocialLinkConfig> = {
  youtube: {
    id: 'youtube',
    label: 'YouTube',
    handle: '@PaniPuriSimulator3D (Placeholder)',
    url: '', // Replace with real YouTube URL when ready
    description: 'Devlogs, Phase 2 cooking gameplay previews, and behind-the-scenes updates.',
  },
  instagram: {
    id: 'instagram',
    label: 'Instagram',
    handle: '@panipurisim3d (Placeholder)',
    url: '', // Replace with real Instagram URL when ready
    description: '3D street food renders, stall customization previews, and community polls.',
  },
};

export function isSocialUrlConfigured(url: string): boolean {
  const trimmed = url.trim();
  if (!trimmed) return false;
  if (trimmed.startsWith('YOUR_') || trimmed.includes('example.com') || trimmed === '#') {
    return false;
  }
  return /^https?:\/\/.+/i.test(trimmed);
}
