export enum GameState {
  MAIN_MENU = 'MAIN_MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  SHOP_PREVIEW = 'SHOP_PREVIEW',
  CONNECT_PANEL = 'CONNECT_PANEL',
}

export type GraphicsQuality = 'low' | 'medium' | 'high';

export interface GameSettings {
  volume: number; // 0 to 100
  muted: boolean;
  sfxEnabled?: boolean; // Sound effects toggle (default true)
  lookSensitivity: number; // 0.2 to 2.0, default 1.0
  invertY: boolean;
  graphicsQuality?: GraphicsQuality; // 'low' | 'medium' | 'high' (default 'medium')
}

export interface ColliderBox {
  id: string;
  label: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
}

export interface PlayerState {
  x: number;
  y: number; // feet height above ground (0 = on ground)
  z: number;
  vx: number;
  vy: number;
  vz: number;
  yaw: number;   // radians around Y axis
  pitch: number; // radians around X axis
  isGrounded: boolean;
  isSprinting: boolean;
  coyoteTimer: number;
  jumpBufferTimer: number;
  walkCycle: number;
}

export interface InputState {
  moveX: number; // -1 (left) to +1 (right)
  moveZ: number; // -1 (backward) to +1 (forward)
  sprintHeld: boolean;
  jumpHeld: boolean;
  jumpJustPressed: boolean;
  lookDeltaX: number;
  lookDeltaY: number;
}

export interface PlayerTelemetry {
  x: number;
  y: number;
  z: number;
  isSprinting: boolean;
  isGrounded: boolean;
  nearStall: boolean;
  distanceToStall: number;
  zoneName: string;
}
