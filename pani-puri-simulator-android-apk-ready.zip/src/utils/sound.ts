import { GameSettings } from '../types/game';
import { loadGameSettings } from './settings';

export type SoundCueType =
  | 'pickup'
  | 'drop'
  | 'add_puri'
  | 'pour_tick'
  | 'target_reached'
  | 'empty_stock'
  | 'recipe_complete'
  | 'serving'
  | 'eating'
  | 'rating'
  | 'purchase'
  | 'coin_reward'
  | 'discard'
  | 'notice';

class SoundManager {
  private ctx: AudioContext | null = null;
  private settings: GameSettings = loadGameSettings();

  public updateSettings(settings: GameSettings) {
    this.settings = settings;
  }

  public getSettings(): GameSettings {
    return this.settings;
  }

  private getEffectiveGain(): number {
    if (
      this.settings.muted ||
      this.settings.sfxEnabled === false ||
      this.settings.volume <= 0
    ) {
      return 0;
    }
    return (this.settings.volume / 100) * 0.25;
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        try {
          this.ctx = new AudioCtx();
        } catch {
          return null;
        }
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playUiClick() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(680, now + 0.045);

    gain.gain.setValueAtTime(baseGain * 0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.055);
  }

  public playNotice() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.setValueAtTime(554.37, now + 0.06);

    gain.gain.setValueAtTime(baseGain * 0.65, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playJump() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    const pitchVar = 0.96 + Math.random() * 0.08;
    osc.frequency.setValueAtTime(190 * pitchVar, now);
    osc.frequency.exponentialRampToValueAtTime(380 * pitchVar, now + 0.12);

    gain.gain.setValueAtTime(baseGain * 0.7, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playLand() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(135, now);
    osc.frequency.exponentialRampToValueAtTime(58, now + 0.09);

    gain.gain.setValueAtTime(baseGain * 0.8, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  public playFootstep(sprinting: boolean) {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    const baseFreq = sprinting ? 140 : 110;
    const pitchVar = 0.92 + Math.random() * 0.16;
    osc.frequency.setValueAtTime(baseFreq * pitchVar, now);
    osc.frequency.exponentialRampToValueAtTime(45, now + 0.045);

    gain.gain.setValueAtTime(baseGain * (sprinting ? 0.38 : 0.24), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.055);
  }

  public playStarRating(stars: number = 5) {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const scaleNotes = [523.25, 587.33, 659.25, 783.99, 1046.5];
    const count = Math.max(1, Math.min(5, Math.round(stars)));
    for (let i = 0; i < count; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + i * 0.055;
      osc.frequency.setValueAtTime(scaleNotes[i], t);
      gain.gain.setValueAtTime(baseGain * 0.65, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.15);
    }
  }

  public playCoinReward() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Classic bright two-tone coin chime (B5 -> E6)
    const freqs = [987.77, 1318.51];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      const t = now + idx * 0.06;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(baseGain * 0.72, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.23);
    });
  }

  public playEating() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Two light crispy puri crunch pulses
    [0, 0.12].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + offset;
      osc.frequency.setValueAtTime(idx === 0 ? 410 : 470, t);
      osc.frequency.exponentialRampToValueAtTime(210, t + 0.06);
      gain.gain.setValueAtTime(baseGain * 0.55, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.065);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.07);
    });
  }

  public playPurchase() {
    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Crisp cash-register / shop chime (G5 -> D6)
    [783.99, 1174.66].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + idx * 0.055;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(baseGain * 0.68, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.16);
    });
  }

  private lastPourSoundTime = 0;

  public playFoodPrepCue(cue: SoundCueType) {
    if (cue === 'notice') {
      this.playNotice();
      return;
    }
    if (cue === 'purchase') {
      this.playPurchase();
      return;
    }
    if (cue === 'coin_reward') {
      this.playCoinReward();
      return;
    }
    if (cue === 'eating') {
      this.playEating();
      return;
    }
    if (cue === 'rating') {
      this.playStarRating(5);
      return;
    }

    const baseGain = this.getEffectiveGain();
    if (baseGain <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    if (cue === 'pour_tick') {
      if (now - this.lastPourSoundTime < 0.075) return;
      this.lastPourSoundTime = now;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(340 + Math.random() * 120, now);
      osc.frequency.exponentialRampToValueAtTime(520, now + 0.045);
      gain.gain.setValueAtTime(baseGain * 0.32, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.055);
      return;
    }

    if (cue === 'pickup') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(360, now);
      osc.frequency.exponentialRampToValueAtTime(640, now + 0.07);
      gain.gain.setValueAtTime(baseGain * 0.65, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.085);
      return;
    }

    if (cue === 'drop') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(170, now + 0.075);
      gain.gain.setValueAtTime(baseGain * 0.65, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.09);
      return;
    }

    if (cue === 'add_puri') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(480, now);
      osc.frequency.exponentialRampToValueAtTime(760, now + 0.055);
      gain.gain.setValueAtTime(baseGain * 0.7, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.07);
      return;
    }

    if (cue === 'target_reached') {
      const notes = [587.33, 880]; // D5 -> A5
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const t = now + idx * 0.065;
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(baseGain * 0.7, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.15);
      });
      return;
    }

    if (cue === 'recipe_complete' || cue === 'serving') {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const t = now + idx * 0.065;
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(baseGain * 0.75, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.19);
      });
      return;
    }

    if (cue === 'empty_stock' || cue === 'discard') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(110, now + 0.14);
      gain.gain.setValueAtTime(baseGain * 0.5, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.16);
    }
  }
}

export const soundManager = new SoundManager();

