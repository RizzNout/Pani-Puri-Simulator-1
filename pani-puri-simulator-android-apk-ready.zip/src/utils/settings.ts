import { GameSettings, GraphicsQuality } from '../types/game';

export const SETTINGS_STORAGE_KEY = 'pani_puri_sim_3d_settings_v1';

export const DEFAULT_SETTINGS: GameSettings = {
  volume: 75,
  muted: false,
  sfxEnabled: true,
  lookSensitivity: 1.0,
  invertY: false,
  graphicsQuality: 'medium',
};

export function sanitizeSettings(raw: Partial<GameSettings> | null | undefined): GameSettings {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ...DEFAULT_SETTINGS };
  }
  const volume =
    typeof raw.volume === 'number' && Number.isFinite(raw.volume)
      ? Math.max(0, Math.min(100, Math.round(raw.volume)))
      : DEFAULT_SETTINGS.volume;
  const muted = typeof raw.muted === 'boolean' ? raw.muted : DEFAULT_SETTINGS.muted;
  const sfxEnabled =
    typeof raw.sfxEnabled === 'boolean'
      ? raw.sfxEnabled
      : !muted;
  const lookSensitivity =
    typeof raw.lookSensitivity === 'number' && Number.isFinite(raw.lookSensitivity)
      ? Math.max(0.2, Math.min(2.5, Number(raw.lookSensitivity.toFixed(2))))
      : DEFAULT_SETTINGS.lookSensitivity;
  const invertY = typeof raw.invertY === 'boolean' ? raw.invertY : DEFAULT_SETTINGS.invertY;
  const graphicsQuality: GraphicsQuality =
    raw.graphicsQuality === 'low' || raw.graphicsQuality === 'medium' || raw.graphicsQuality === 'high'
      ? raw.graphicsQuality
      : 'medium';

  return {
    volume,
    muted,
    sfxEnabled,
    lookSensitivity,
    invertY,
    graphicsQuality,
  };
}

export function loadGameSettings(): GameSettings {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return { ...DEFAULT_SETTINGS };
    }
    const stored = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!stored) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(stored) as Partial<GameSettings>;
    return sanitizeSettings(parsed);
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveGameSettings(settings: GameSettings): GameSettings {
  const clean = sanitizeSettings(settings);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(clean));
    }
  } catch {
    // Ignore storage quota / privacy mode errors gracefully
  }
  return clean;
}
