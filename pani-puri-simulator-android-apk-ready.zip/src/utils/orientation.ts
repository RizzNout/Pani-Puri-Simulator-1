/**
 * Orientation utilities for landscape-first mobile gameplay.
 */

export interface ViewportOrientationState {
  width: number;
  height: number;
  isPortrait: boolean;
  shouldShowRotateOverlay: boolean;
}

/**
 * Determines whether the "PLEASE ROTATE YOUR DEVICE" overlay should be shown.
 * Triggers when the viewport is in portrait orientation (height > width) on mobile/tablet
 * widths (<= 900px), while never blocking standard desktop monitors.
 */
export function evaluateViewportOrientation(
  width: number,
  height: number
): ViewportOrientationState {
  const safeW = Math.max(1, width);
  const safeH = Math.max(1, height);
  const isPortrait = safeH > safeW;
  const shouldShowRotateOverlay = isPortrait && safeW <= 900;

  return {
    width: safeW,
    height: safeH,
    isPortrait,
    shouldShowRotateOverlay,
  };
}

export interface LockOrientationResult {
  locked: boolean;
  reason?: string;
}

/**
 * Attempts to request landscape orientation lock on supported mobile browsers
 * after an explicit user interaction (e.g. clicking START).
 * Never throws if the browser, OS, or iframe sandbox denies or lacks support.
 */
export async function tryLockLandscapeOrientation(): Promise<LockOrientationResult> {
  if (typeof window === 'undefined' || typeof screen === 'undefined') {
    return { locked: false, reason: 'Screen API unavailable' };
  }

  try {
    const orientationApi = screen.orientation as ScreenOrientation & {
      lock?: (orientation: string) => Promise<void>;
    };

    if (orientationApi && typeof orientationApi.lock === 'function') {
      await orientationApi.lock('landscape');
      return { locked: true };
    }
    return {
      locked: false,
      reason: 'Screen Orientation lock API is not supported on this browser.',
    };
  } catch {
    return {
      locked: false,
      reason: 'Landscape lock requires fullscreen or manual device rotation on this browser.',
    };
  }
}
